# CaterEase: local Express/MySQL migration

## Audit findings
- CaterEase already has the requested HTML, CSS, JavaScript and Bootstrap screens, shared business logic, bcrypt passwords and business-isolated APIs.
- The working hosted app still relies on Lovable Cloud for data. Its hosting framework cannot be replaced by Express/MySQL inside Lovable.
- The previously described downloadable backend is not available in the current saved files. The current source has no Express server, `mysql2` adapter or MySQL schema.
- **41 existing tests passed**, but they use an in-memory database and do not verify MySQL.
- Existing login roles are business owner/administrator and manager. Staff are records, not a separate login role. There is no separate orders module.
- The detailed source audit is saved in the project as `migration-audit.md`; it inventories configuration names, APIs, database operations, security risks and verification gaps without exposing secret values.

## Result to deliver
A separate downloadable CaterEase application using exactly HTML/CSS/JavaScript/Bootstrap, Node.js, Express.js and MySQL, with MacBook/VS Code setup instructions. Preserve the current interface, college logo, branding, registration, business details, dashboards and management features. Keep the hosted preview and its existing records intact while the local application is verified.

## Stages
### 1. Preserve and establish the local project
- Capture the current UI and feature inventory; copy only necessary frontend assets and shared business logic into a clean local submission.
- Recover the previous backend if supplied; otherwise reconstruct it from the audited current source.
- Create Express startup, environment validation, `.env.example`, npm scripts and a health check. Never include real environment files or credentials.

### 2. Implement MySQL storage
- Create versioned schema/migrations for all existing tables, preserving business isolation, foreign keys, identifiers and unique constraints.
- Build the `mysql2` adapter with parameterized values, allowlisted identifiers, pooled connections and real transactions.
- Replace provisioning RPCs with atomic transactions. Verify rollback, duplicate email handling, concurrent setup and payment limits.
- Prepare a private export/import process for existing records and password hashes; validate row counts and relationships before any cutover. No deletion or reset of live records.

### 3. Migrate authentication and frontend connections
- Retain bcrypt and existing membership-based permissions, including legacy username login and email login.
- Use MySQL-backed server sessions with HttpOnly cookies, revocable logout, expiry, rate limiting and CSRF protection.
- Change only request/session plumbing in the local frontend. Preserve registration → business details → dashboard for new businesses and direct dashboard access for completed businesses.
- Serve screens and `/api` from Express on the same origin by default. Document an optional separate frontend service with narrowly configured credentialed CORS.

### 4. Verify all existing features
- Exercise actual Express/MySQL registration, login, logout, protected access and cross-business/role attacks.
- Run browser workflows for customers, events, menus, bookings, guests, staff, assignments, payments, feedback, settings, receipts and all six reports.
- Test real MySQL constraints, rollback and persistence after restarting the server. Do not substitute fake responses or in-memory results for these checks.
- Compare screens with the preserved original and check navigation and phone layouts.

### 5. Package and hand over
- Package only the verified standalone source, schema/migrations, example configuration, scripts and installation guide, without Cloud SDKs or unconfigured Cloud dependencies.
- Supply separate schema-only setup and private existing-data migration instructions; exclude live records, password hashes, secrets, dependencies and generated output from the public archive.
- Document Node/MySQL requirements, database creation, environment setup, startup, tests, backups and troubleshooting on macOS.
- Report every completed check and any remaining limitation. Actual MacBook verification requires running the final package there; do not claim it was tested on the user's computer.

## Technical approach
- Keep the hosted TanStack project unchanged; the exact capstone stack belongs in a separate local package.
- Reuse the audited API contract and shared plain-JavaScript business logic, introducing only the adapter/session boundary needed by Express.
- Preserve owner/admin/manager authorization; do not invent staff accounts or order features.
- Use exact decimal/date mappings, tenant-aware composite foreign keys and transactional writes in MySQL.
- Remove Cloud dependencies only from the standalone package after successful migration tests. Generated hosted integration files remain untouched.

## Limitations to resolve during implementation
- No current MySQL migration or live-data import has been verified.
- A private, authorized data export is needed to preserve the actual existing records locally; never distribute it as public source.
- Inquiry emails still need sender configuration and the owner's recipient address; this previously pending feature is not enabled by migration.
- Completion depends on successful real MySQL and browser tests, not the existing passing unit tests alone.