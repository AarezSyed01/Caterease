CREATE FUNCTION public.setup_catering_admin(details jsonb,hashed_password text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE u public.users; BEGIN
 PERFORM pg_advisory_xact_lock(829451);
 IF EXISTS(SELECT 1 FROM public.users) THEN RAISE EXCEPTION 'An administrator already exists' USING ERRCODE='23505'; END IF;
 INSERT INTO public.users(username,full_name,password_hash,business_id) VALUES(details->>'username',details->>'full_name',hashed_password,'00000000-0000-4000-8000-000000000001') RETURNING * INTO u;
 INSERT INTO public.business_roles(user_id,business_id,role) VALUES(u.user_id,u.business_id,'admin');
 RETURN jsonb_build_object('user_id',u.user_id,'username',u.username,'full_name',u.full_name,'business_id',u.business_id,'role','admin');
END $$;
REVOKE ALL ON FUNCTION public.setup_catering_admin(jsonb,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.setup_catering_admin(jsonb,text) TO service_role;
CREATE FUNCTION public.create_catering_manager(details jsonb,hashed_password text,tenant uuid) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE u public.users; BEGIN
 INSERT INTO public.users(username,email,full_name,password_hash,business_id) VALUES(details->>'username',NULLIF(details->>'email',''),details->>'full_name',hashed_password,tenant) RETURNING * INTO u;
 INSERT INTO public.business_roles(user_id,business_id,role) VALUES(u.user_id,u.business_id,'manager');
 RETURN jsonb_build_object('user_id',u.user_id,'username',u.username,'email',u.email,'full_name',u.full_name,'business_id',u.business_id,'role','manager');
END $$;
REVOKE ALL ON FUNCTION public.create_catering_manager(jsonb,text,uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.create_catering_manager(jsonb,text,uuid) TO service_role;