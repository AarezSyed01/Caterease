CREATE OR REPLACE FUNCTION public.register_catering_business(details jsonb, hashed_password text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE bid uuid; u public.users; BEGIN
 IF length(hashed_password)>255 OR hashed_password NOT LIKE '$2%' THEN RAISE EXCEPTION 'Invalid password hash'; END IF;
 INSERT INTO public.businesses(business_name,owner_name,email,mobile,address,city,state,business_type,gst_number)
 VALUES(details->>'business_name',details->>'full_name',details->>'email',COALESCE(details->>'mobile',''),COALESCE(details->>'address',''),COALESCE(details->>'city',''),COALESCE(details->>'state',''),NULLIF(details->>'business_type',''),NULLIF(details->>'gst_number','')) RETURNING business_id INTO bid;
 INSERT INTO public.users(username,email,full_name,password_hash,business_id) VALUES('owner_'||replace(bid::text,'-',''),details->>'email',details->>'full_name',hashed_password,bid) RETURNING * INTO u;
 INSERT INTO public.business_roles(user_id,business_id,role) VALUES(u.user_id,bid,'owner');
 INSERT INTO public.business_settings(business_id,setting_key,setting_value) VALUES
 (bid,'business_name',details->>'business_name'),(bid,'business_email',details->>'email'),(bid,'business_phone',COALESCE(details->>'mobile','')),(bid,'business_address',COALESCE(details->>'address','')),
 (bid,'city',COALESCE(details->>'city','')),(bid,'state',COALESCE(details->>'state','')),(bid,'business_type',COALESCE(details->>'business_type','')),(bid,'gst_number',COALESCE(details->>'gst_number','')),
 (bid,'details_complete','false');
 RETURN jsonb_build_object('user_id',u.user_id,'username',u.username,'email',u.email,'full_name',u.full_name,'business_id',bid,'role','owner');
END $$;
REVOKE ALL ON FUNCTION public.register_catering_business(jsonb,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.register_catering_business(jsonb,text) TO service_role;