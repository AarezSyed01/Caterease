/* CaterEase — manager application (vanilla JS + Bootstrap 5) */
(function () {
  "use strict";
  const API = window.CMS_API_BASE || "/api";
  const root = document.getElementById("root");
  const state = { user: null, settings: null, charts: [] };

  /* ------------ utilities ------------ */
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (v) => "₹" + Number(v || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fdate = (d) => { if (!d) return "—"; const [y, m, dd] = String(d).slice(0, 10).split("-"); return `${dd}-${m}-${y}`; };
  const ftime = (t) => { if (!t) return ""; const [h, m] = String(t).split(":"); const H = Number(h); return `${((H + 11) % 12) + 1}:${m} ${H < 12 ? "AM" : "PM"}`; };
  const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const badge = (s) => s ? `<span class="badge st-${String(s).replace(/\s+/g, "")}">${esc(s)}</span>` : "";
  const stars = (n) => `<span class="stars" aria-label="${n} of 5">${"★".repeat(n)}${"☆".repeat(5 - n)}</span>`;
  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2));
  const qs = (o) => { const p = new URLSearchParams(); Object.entries(o || {}).forEach(([k, v]) => { if (v !== "" && v != null) p.set(k, v); }); const s = p.toString(); return s ? "?" + s : ""; };

  const token = { get: () => sessionStorage.getItem("cms_token"), set: (t) => sessionStorage.setItem("cms_token", t), clear: () => sessionStorage.removeItem("cms_token") };

  async function api(method, path, body) {
    const headers = { "Content-Type": "application/json" };
    if (token.get()) headers.Authorization = "Bearer " + token.get();
    let res, json;
    try {
      res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
      json = await res.json();
    } catch {
      throw Object.assign(new Error("Cannot reach the server. Check that the backend is running."), { status: 0 });
    }
    if (res.status === 401 && !path.startsWith("/auth/")) { token.clear(); state.user = null; renderLogin("Your session has ended. Please sign in again."); throw Object.assign(new Error(json.message), { status: 401, silent: true }); }
    if (!json.success) throw Object.assign(new Error(json.message || "Request failed"), { status: res.status, errors: json.errors });
    return json.data;
  }

  function toast(msg, type = "success") {
    const el = document.createElement("div");
    el.className = `toast align-items-center text-bg-${type === "error" ? "danger" : type === "warning" ? "warning" : "success"} border-0`;
    el.setAttribute("role", "alert");
    el.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(msg)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
    $("#toasts").appendChild(el);
    const t = new bootstrap.Toast(el, { delay: type === "error" ? 6000 : 3500 });
    t.show();
    el.addEventListener("hidden.bs.toast", () => el.remove());
  }
  const showError = (e) => { if (!e.silent) toast(e.message, "error"); };

  function confirmDialog(message, { title = "Please confirm", ok = "Confirm", danger = true } = {}) {
    return new Promise((resolve) => {
      const el = document.createElement("div");
      el.className = "modal fade";
      el.innerHTML = `<div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${esc(title)}</h5><button class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body">${esc(message)}</div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn ${danger ? "btn-danger" : "btn-primary"}" data-ok>${esc(ok)}</button></div></div></div>`;
      document.body.appendChild(el);
      const m = new bootstrap.Modal(el);
      let result = false;
      $("[data-ok]", el).onclick = () => { result = true; m.hide(); };
      el.addEventListener("hidden.bs.modal", () => { el.remove(); resolve(result); });
      m.show();
    });
  }

  /* ------------ forms ------------ */
  function fieldHtml(f, v) {
    const id = "f_" + f.name, req = f.required ? " required" : "", val = v ?? f.default ?? "";
    const label = `<label class="form-label" for="${id}">${esc(f.label)}${f.required ? ' <span class="text-danger">*</span>' : ""}</label>`;
    let input;
    if (f.type === "select") input = `<select class="form-select" id="${id}" name="${f.name}"${req}>${f.placeholder !== false ? `<option value="">${esc(f.placeholder || "Select…")}</option>` : ""}${(f.options || []).map(([ov, ol]) => `<option value="${esc(ov)}"${String(ov) === String(val) ? " selected" : ""}>${esc(ol)}</option>`).join("")}</select>`;
    else if (f.type === "textarea") input = `<textarea class="form-control" id="${id}" name="${f.name}" rows="${f.rows || 3}" maxlength="${f.max || 1000}"${req}>${esc(val)}</textarea>`;
    else if (f.type === "checkbox") return `<div class="${f.col || "col-12"}"><div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" role="switch" id="${id}" name="${f.name}"${val === true || val === undefined && f.default !== false ? " checked" : ""}><label class="form-check-label" for="${id}">${esc(f.label)}</label></div><div class="invalid-feedback d-block" data-err="${f.name}"></div></div>`;
    else input = `<input class="form-control" id="${id}" name="${f.name}" type="${f.type || "text"}" value="${esc(val)}"${f.step ? ` step="${f.step}"` : ""}${f.min !== undefined ? ` min="${f.min}"` : ""}${f.maxlength ? ` maxlength="${f.maxlength}"` : ""}${f.placeholderText ? ` placeholder="${esc(f.placeholderText)}"` : ""}${req}>`;
    return `<div class="${f.col || "col-12"}">${label}${input}<div class="invalid-feedback" data-err="${f.name}"></div>${f.help ? `<div class="form-text">${esc(f.help)}</div>` : ""}</div>`;
  }
  function readForm(form, fields) {
    const out = {};
    for (const f of fields) {
      const el = form.elements[f.name];
      if (!el) continue;
      out[f.name] = f.type === "checkbox" ? el.checked : el.value.trim();
    }
    return out;
  }
  function clientValidate(form, fields, data) {
    const errs = {};
    for (const f of fields) if (f.required && f.type !== "checkbox" && !data[f.name]) errs[f.name] = `${f.label} is required`;
    showFieldErrors(form, errs);
    return !Object.keys(errs).length;
  }
  function showFieldErrors(form, errs = {}) {
    $$(".is-invalid", form).forEach((e) => e.classList.remove("is-invalid"));
    $$("[data-err]", form).forEach((e) => (e.textContent = ""));
    for (const [k, msg] of Object.entries(errs || {})) {
      const el = form.elements[k];
      if (el) el.classList.add("is-invalid");
      const fb = $(`[data-err="${k}"]`, form);
      if (fb) fb.textContent = msg;
    }
  }
  /** Modal form; onSubmit must call the API and resolve, the modal closes only on success. */
  function formModal({ title, fields, values = {}, submitLabel = "Save", onSubmit, size = "" }) {
    const el = document.createElement("div");
    el.className = "modal fade";
    el.innerHTML = `<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable ${size}"><form class="modal-content" novalidate><div class="modal-header"><h5 class="modal-title">${esc(title)}</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="alert alert-danger d-none" data-form-error></div><div class="row g-3">${fields.map((f) => fieldHtml(f, values[f.name])).join("")}</div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary"><span class="spinner-border spinner-border-sm me-1 d-none"></span>${esc(submitLabel)}</button></div></form></div>`;
    document.body.appendChild(el);
    const m = new bootstrap.Modal(el);
    const form = $("form", el);
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      const data = readForm(form, fields);
      if (!clientValidate(form, fields, data)) return;
      const btn = $("[type=submit]", form), sp = $(".spinner-border", btn), alertEl = $("[data-form-error]", form);
      btn.disabled = true; sp.classList.remove("d-none"); alertEl.classList.add("d-none");
      try {
        await onSubmit(data);
        m.hide();
      } catch (e) {
        if (e.silent) { m.hide(); return; }
        showFieldErrors(form, e.errors);
        alertEl.textContent = e.message; alertEl.classList.remove("d-none");
      } finally { btn.disabled = false; sp.classList.add("d-none"); }
    });
    el.addEventListener("hidden.bs.modal", () => el.remove());
    m.show();
    return { el, form };
  }

  /* ------------ data table ------------ */
  function dataTable(container, { columns, rows, pageSize = 10, sort, onRow, actions, empty = "No records found", exportName }) {
    let page = 1, sortKey = sort?.[0], sortDir = sort?.[1] || "asc";
    const render = () => {
      let data = [...rows];
      if (sortKey) {
        const col = columns.find((c) => c.key === sortKey);
        data.sort((a, b) => {
          const va = col?.sortValue ? col.sortValue(a) : a[sortKey], vb = col?.sortValue ? col.sortValue(b) : b[sortKey];
          const r = typeof va === "number" && typeof vb === "number" ? va - vb : String(va ?? "").localeCompare(String(vb ?? ""), undefined, { numeric: true });
          return sortDir === "asc" ? r : -r;
        });
      }
      const pages = Math.max(1, Math.ceil(data.length / pageSize));
      page = Math.min(page, pages);
      const slice = data.slice((page - 1) * pageSize, page * pageSize);
      container.innerHTML = `
        <div class="table-responsive"><table class="table table-hover align-middle"><thead><tr>
          ${columns.map((c) => `<th class="${c.sortable === false ? "" : "sortable"} ${c.align === "end" ? "text-end" : ""}" data-key="${c.key}" scope="col">${esc(c.label)}${sortKey === c.key ? ` <i class="bi bi-caret-${sortDir === "asc" ? "up" : "down"}-fill"></i>` : ""}</th>`).join("")}
          ${actions ? '<th class="text-end no-print">Actions</th>' : ""}
        </tr></thead><tbody>
          ${slice.length ? slice.map((r, i) => `<tr class="${onRow ? "clickable" : ""}" data-i="${(page - 1) * pageSize + i}">${columns.map((c) => `<td class="${c.align === "end" ? "text-end" : ""}">${c.render ? c.render(r) : esc(r[c.key] ?? "—")}</td>`).join("")}${actions ? `<td class="text-end text-nowrap no-print">${actions(r)}</td>` : ""}</tr>`).join("")
          : `<tr><td colspan="${columns.length + (actions ? 1 : 0)}"><div class="empty-state"><i class="bi bi-inbox"></i>${esc(empty)}</div></td></tr>`}
        </tbody></table></div>
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 p-3 border-top no-print">
          <div class="small text-muted">${data.length ? `Showing ${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, data.length)} of ${data.length}` : "0 records"}</div>
          <div class="d-flex gap-2 align-items-center">
            ${exportName && data.length ? `<button class="btn btn-sm btn-outline-secondary" data-export><i class="bi bi-file-earmark-spreadsheet"></i> Export Excel</button>` : ""}
            <nav aria-label="Pagination"><ul class="pagination pagination-sm mb-0">
              <li class="page-item ${page <= 1 ? "disabled" : ""}"><button class="page-link" data-page="${page - 1}" aria-label="Previous">‹</button></li>
              <li class="page-item active"><span class="page-link">${page} / ${pages}</span></li>
              <li class="page-item ${page >= pages ? "disabled" : ""}"><button class="page-link" data-page="${page + 1}" aria-label="Next">›</button></li>
            </ul></nav>
          </div>
        </div>`;
      $$("th.sortable", container).forEach((th) => (th.onclick = () => { const k = th.dataset.key; sortDir = sortKey === k && sortDir === "asc" ? "desc" : "asc"; sortKey = k; render(); }));
      $$("[data-page]", container).forEach((b) => (b.onclick = () => { page = Number(b.dataset.page); render(); }));
      if (onRow) $$("tbody tr.clickable", container).forEach((tr) => tr.addEventListener("click", (e) => { if (!e.target.closest("button,a")) onRow(data[Number(tr.dataset.i)]); }));
      const ex = $("[data-export]", container);
      if (ex) ex.onclick = () => exportXlsx(exportName, columns.filter((c) => c.export !== false).map((c) => [c.exportKey || c.key, c.label]), data);
    };
    render();
    return { update: (r) => { rows = r; render(); } };
  }

  /* ------------ exports ------------ */
  const safeCell = (v) => (typeof v === "string" && /^[=+\-@\t\r]/.test(v) ? "'" + v : v); // formula-injection guard
  function exportXlsx(name, cols, rows, meta) {
    const aoa = [];
    if (meta) { aoa.push([meta.title]); aoa.push([`Generated: ${new Date().toLocaleString("en-IN")}`]); if (meta.filters) aoa.push([`Filters: ${meta.filters}`]); aoa.push([]); }
    aoa.push(cols.map((c) => c[1]));
    rows.forEach((r) => aoa.push(cols.map((c) => safeCell(r[c[0]] ?? ""))));
    if (meta?.summary?.length) { aoa.push([]); meta.summary.forEach((s) => aoa.push([s[0], s[1]])); }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    XLSX.writeFile(wb, `${name}-${today()}.xlsx`);
  }
  function exportPdf(rep, filtersText) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: rep.columns.length > 6 ? "landscape" : "portrait", unit: "pt", format: "a4" });
    const s = state.settings || {};
    doc.setFontSize(14); doc.setTextColor(13, 92, 75); doc.text(s.business_name || "CaterEase", 40, 40);
    doc.setFontSize(12); doc.setTextColor(30); doc.text(rep.title, 40, 60);
    doc.setFontSize(8.5); doc.setTextColor(100);
    doc.text(`Generated: ${new Date().toLocaleString("en-IN")}   ·   Date basis: ${rep.date_basis}`, 40, 76);
    doc.text(`Filters: ${filtersText}`, 40, 88, { maxWidth: doc.internal.pageSize.getWidth() - 80 });
    const fmt = (c, r) => (c[2] === "money" ? Number(r[c[0]] || 0).toLocaleString("en-IN", { minimumFractionDigits: 2 }) : /date/.test(c[0]) && r[c[0]] ? fdate(r[c[0]]) : String(r[c[0]] ?? ""));
    doc.autoTable({ startY: 100, head: [rep.columns.map((c) => c[1].replace("₹", "Rs."))], body: rep.rows.map((r) => rep.columns.map((c) => fmt(c, r))), styles: { fontSize: 8 }, headStyles: { fillColor: [13, 92, 75] }, alternateRowStyles: { fillColor: [246, 247, 245] } });
    let y = doc.lastAutoTable.finalY + 20;
    doc.setFontSize(9.5); doc.setTextColor(30);
    rep.summary.forEach((sm) => { doc.text(`${sm[0].replace("₹", "Rs.")}: ${sm[2] === "money" ? Number(sm[1]).toLocaleString("en-IN", { minimumFractionDigits: 2 }) : sm[1]}`, 40, y); y += 14; });
    doc.setFontSize(7.5); doc.setTextColor(130); doc.text(s.report_footer || "", 40, doc.internal.pageSize.getHeight() - 20);
    doc.save(`${rep.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-${today()}.pdf`);
  }

  /* ------------ navigation ------------ */
  const NAV = [
    ["dashboard", "Dashboard", "speedometer2"], ["customers", "Customers", "people"], ["events", "Events", "calendar-event"],
    ["menus", "Menu Management", "journal-richtext"], ["bookings", "Bookings", "clipboard-check"], ["guests", "Guest Management", "person-lines-fill"],
    ["staff", "Staff Management", "person-badge"], ["assignments", "Staff Assignments", "diagram-3"], ["payments", "Payments", "cash-coin"],
    ["feedback", "Feedback", "chat-square-heart"], ["reports", "Reports", "bar-chart-line"], ["settings", "Settings", "gear"],
  ];

  function shell() {
    root.innerHTML = `
      <aside class="sidebar" aria-label="Main navigation">
        <div class="brand d-flex align-items-center gap-2"><i class="bi bi-egg-fried fs-3 text-gold"></i><div><div class="name">${esc((state.settings?.business_name || "CaterEase").replace(/\s*\(Demo\)/gi, "").trim())}</div><div class="sub">CaterEase</div></div></div>
        <nav>${NAV.map(([k, l, i]) => `<a href="#/${k}" data-nav="${k}"><i class="bi bi-${i}"></i>${l}</a>`).join("")}
          <a href="#" data-logout><i class="bi bi-box-arrow-left"></i>Logout</a></nav>
        <div class="p-3 small" style="color:#9fbdb4">Customer inquiry form: <a href="inquiry.html?business_id=${encodeURIComponent(state.user.business_id)}" target="_blank" class="text-gold">open</a></div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="btn btn-light d-lg-none" data-toggle-sidebar aria-label="Toggle navigation"><i class="bi bi-list"></i></button>
          <div class="me-auto"><div class="crumb" id="crumb"></div><div class="title" id="pageTitle"></div></div>
          <div class="position-relative d-none d-md-block" style="width:280px">
            <input class="form-control form-control-sm" id="globalSearch" placeholder="Search customers, bookings, events…" aria-label="Global search" autocomplete="off">
            <div class="list-group shadow search-results d-none" id="searchResults"></div>
          </div>
          <div class="dropdown">
            <button class="btn btn-light position-relative" data-bs-toggle="dropdown" aria-label="Notifications"><i class="bi bi-bell"></i><span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" id="notifCount"></span></button>
            <div class="dropdown-menu dropdown-menu-end p-0" style="width:300px" id="notifMenu"></div>
          </div>
          <div class="dropdown">
            <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-person-circle me-1"></i><span class="d-none d-sm-inline">${esc(state.user.full_name)}</span></button>
            <ul class="dropdown-menu dropdown-menu-end"><li><span class="dropdown-item-text small text-muted">Signed in as ${esc(state.user.username)} (${esc(state.user.role)})</span></li><li><a class="dropdown-item" href="#/settings">Settings</a></li><li><hr class="dropdown-divider"></li><li><a class="dropdown-item" href="#" data-logout>Logout</a></li></ul>
          </div>
        </header>
        <main class="content" id="view" tabindex="-1"></main>
        <footer class="page-footer">Developed by <strong>Aarez, Raiyan &amp; Sahil</strong><span class="page-footer-note">Bachelor of Computer Application '27 · Capstone Project</span></footer>
      </div>`;
    $$("[data-logout]").forEach((a) => (a.onclick = async (e) => { e.preventDefault(); try { await api("POST", "/auth/logout"); } catch {} token.clear(); state.user = null; location.hash = ""; renderLogin("You have been signed out."); }));
    $("[data-toggle-sidebar]").onclick = () => document.body.classList.toggle("sidebar-open");
    const gs = $("#globalSearch"), sr = $("#searchResults");
    let timer;
    gs.oninput = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        if (gs.value.trim().length < 2) { sr.classList.add("d-none"); return; }
        try {
          const res = await api("GET", "/search" + qs({ q: gs.value.trim() }));
          sr.innerHTML = res.length ? res.map((r) => `<a class="list-group-item list-group-item-action small" href="${r.href}"><span class="badge bg-primary-soft text-primary me-1">${r.type}</span>${esc(r.label)}</a>`).join("") : '<div class="list-group-item small text-muted">No matches</div>';
          sr.classList.remove("d-none");
        } catch (e) { showError(e); }
      }, 250);
    };
    gs.onblur = () => setTimeout(() => sr.classList.add("d-none"), 200);
    sr.onclick = () => { gs.value = ""; sr.classList.add("d-none"); };
    refreshNotifications();
  }

  async function refreshNotifications() {
    try {
      const d = await api("GET", "/dashboard");
      const n = d.notifications;
      const items = [
        [n.new_inquiries, "new customer inquiries awaiting review", "#/bookings?status=Pending"],
        [n.pending_bookings, "bookings pending confirmation", "#/bookings?status=Pending"],
        [n.events_next_7_days, "events in the next 7 days", "#/events"],
        [n.unpaid_bookings, "active bookings with no payment", "#/payments"],
      ].filter((x) => x[0] > 0);
      const total = n.pending_bookings + n.events_next_7_days + n.unpaid_bookings;
      const c = $("#notifCount");
      if (c) { c.textContent = total; c.classList.toggle("d-none", !total); }
      const menu = $("#notifMenu");
      if (menu) menu.innerHTML = `<div class="p-2 px-3 border-bottom fw-semibold small">Pending tasks</div>` + (items.length ? items.map(([v, t, h]) => `<a class="dropdown-item small py-2" href="${h}"><strong>${v}</strong> ${t}</a>`).join("") : '<div class="p-3 small text-muted">Nothing pending.</div>');
    } catch {}
  }

  function setPage(title, crumbs = []) {
    $("#pageTitle").textContent = title;
    $("#crumb").innerHTML = ["Home", ...crumbs].map(esc).join(' <i class="bi bi-chevron-right" style="font-size:.6rem"></i> ');
    document.title = `${title} · CaterEase`;
  }
  const loading = () => `<div class="d-flex justify-content-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading…</span></div></div>`;
  const errorBox = (e) => `<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-1"></i>${esc(e.message)}</div>`;

  /* ------------ auth screens ------------ */
  async function renderLogin(notice) {
    let needsSetup = false;
    try { needsSetup = (await api("GET", "/auth/status")).needs_setup; } catch (e) { notice = e.message; }
    document.title = `${needsSetup ? "Administrator setup" : "Sign in"} · CaterEase`;
    root.innerHTML = `<main class="auth-wrap">
      <section class="auth-story" aria-label="CaterEase">
        <img class="auth-photo" src="login-table.jpg" width="1536" height="1024" alt="An elegantly set catering table with fresh flowers and plated appetizers" fetchpriority="high">
        <div class="auth-brand"><div class="auth-brand-mark"><span class="auth-brand-dot" aria-hidden="true"></span><span>HOSPITALITY · EVENTS · CATERING</span></div><h1 class="auth-brand-name">CaterEase</h1><p class="auth-brand-title">Catering Management System</p><div class="auth-brand-line" aria-hidden="true"></div><p class="auth-brand-tagline">Every event, beautifully served.</p></div>
      </section>
      <section class="auth-panel" aria-labelledby="authTitle">
      <header class="auth-institution">
        <img class="auth-institution-logo" src="college-logo.png" width="542" height="339" alt="" loading="eager">
        <div class="auth-institution-text">
          <span class="auth-institution-name">College of Computer Science and Information Technology.</span>
          <span class="auth-institution-city">Latur</span>
        </div>
      </header>
      <div class="auth-card">
      <div class="crest"><i class="bi bi-person" aria-hidden="true"></i></div>
      <div class="auth-eyebrow">${needsSetup ? "GETTING STARTED" : "MANAGER SIGN IN"}</div>
      <h2 id="authTitle">${needsSetup ? "Create your account" : "Welcome to CaterEase."}</h2>
      <p class="auth-subtitle">${needsSetup ? "Set up your administrator account." : "Sign in to your catering workspace."}</p>
      ${notice ? `<div class="alert alert-info small py-2" role="status">${esc(notice)}</div>` : ""}
      <form novalidate id="authForm"><div class="alert alert-danger d-none small" role="alert" data-form-error></div><div class="row g-4">
        ${needsSetup ? fieldHtml({ name: "full_name", label: "Full name", required: true }) : ""}
        ${fieldHtml({ name: "username", label: needsSetup ? "Username" : "Email address or username", required: true })}
        <div class="col-12"><label class="form-label" for="f_password">Password <span class="text-danger">*</span></label><div class="auth-password"><input class="form-control" id="f_password" name="password" type="password" autocomplete="${needsSetup ? "new-password" : "current-password"}" placeholder="Enter your password" required><button class="btn auth-password-toggle" type="button" aria-label="Show password" title="Show password" aria-pressed="false"><i class="bi bi-eye" aria-hidden="true"></i></button></div><div class="invalid-feedback" data-err="password"></div>${needsSetup ? '<div class="form-text">At least 8 characters with letters and numbers.</div>' : ""}</div>
        ${needsSetup ? fieldHtml({ name: "setup_key", label: "Setup key (only if configured on the server)", type: "password" }) : ""}
      </div><button class="btn btn-primary auth-submit w-100 mt-4" type="submit"><span class="auth-submit-label">${needsSetup ? "Create administrator" : "Sign in"}</span><span class="spinner-border spinner-border-sm d-none" aria-hidden="true"></span><i class="bi bi-arrow-right" aria-hidden="true"></i></button></form>
      <div class="auth-register mt-3 text-center"><p class="small text-muted mb-2">New catering business?</p><a class="btn btn-outline-primary w-100 py-3" href="register.html"><i class="bi bi-person-plus me-2" aria-hidden="true"></i>Register Your Business</a></div>
      </div><footer class="auth-footer"><span class="auth-footer-note">DEVELOPED BY AAREZ, RAIYAN &amp; SAHIL</span><span class="auth-footer-note">BACHELOR OF COMPUTER APPLICATION '27 CAPSTONE PROJECT</span><span class="auth-copyright">© 2026 CaterEase. All rights reserved.</span></footer></section></main>`;
    const form = $("#authForm");
    form.elements.username.autocomplete = "username";
    form.elements.username.placeholder = needsSetup ? "Enter your username" : "Enter email or existing username";
    $(".auth-password-toggle", form).onclick = (e) => {
      const button = e.currentTarget;
      const show = form.elements.password.type === "password";
      form.elements.password.type = show ? "text" : "password";
      button.setAttribute("aria-label", show ? "Hide password" : "Show password");
      button.setAttribute("title", show ? "Hide password" : "Show password");
      button.setAttribute("aria-pressed", String(show));
      button.innerHTML = `<i class="bi bi-${show ? "eye-slash" : "eye"}" aria-hidden="true"></i>`;
    };
    form.onsubmit = async (e) => {
      e.preventDefault();
      const fields = needsSetup ? [{ name: "full_name", label: "Full name", required: true }, { name: "username", label: "Username", required: true }, { name: "password", label: "Password", required: true }, { name: "setup_key", label: "Setup key" }] : [{ name: "username", label: "Username", required: true }, { name: "password", label: "Password", required: true }];
      const data = readForm(form, fields);
      if (!clientValidate(form, fields, data)) return;
      const btn = $("button[type=submit]", form); btn.disabled = true;
      $(".spinner-border", btn).classList.remove("d-none");
      btn.setAttribute("aria-busy", "true");
      try {
        const res = await api("POST", needsSetup ? "/auth/setup" : "/auth/login", data);
        token.set(res.token); state.user = res.user;
        if (res.user.details_complete === false) { location.assign("details.html"); return; }
        await boot();
      } catch (err) {
        showFieldErrors(form, err.errors);
        const a = $("[data-form-error]", form); a.textContent = err.message; a.classList.remove("d-none");
      } finally { btn.disabled = false; $(".spinner-border", btn).classList.add("d-none"); btn.removeAttribute("aria-busy"); }
    };
  }

  /* ------------ reference data ------------ */
  async function refs(...which) {
    const map = { customers: "/customers", events: "/events", menus: "/menus", staff: "/staff", bookings: "/bookings" };
    const res = await Promise.all(which.map((w) => api("GET", map[w])));
    return Object.fromEntries(which.map((w, i) => [w, res[i]]));
  }
  const EVENT_TYPES = ["Wedding", "Engagement", "Birthday", "Anniversary", "Corporate", "Party", "Religious Function", "Other"];
  const MENU_CATEGORIES = ["Vegetarian", "Non-Vegetarian", "Wedding", "Corporate", "Party", "Snacks", "Desserts", "Other"];
  const STAFF_ROLES = ["Head Chef", "Cook", "Event Supervisor", "Waiter", "Driver", "Decorator", "Helper", "Other"];
  const STATUSES = ["Pending", "Confirmed", "In Progress", "Completed", "Cancelled"];
  const PAY_STATUSES = ["Unpaid", "Partially Paid", "Paid", "Cancelled"];

  function filterBar(fields, values, onChange) {
    const html = `<form class="row g-2 align-items-end p-3 border-bottom no-print" data-filters>${fields.map((f) => `<div class="${f.col || "col-6 col-md-3 col-lg-2"}"><label class="form-label small mb-1" for="flt_${f.name}">${esc(f.label)}</label>${f.type === "select" ? `<select class="form-select form-select-sm" id="flt_${f.name}" name="${f.name}"><option value="">All</option>${f.options.map(([v, l]) => `<option value="${esc(v)}"${String(values[f.name] ?? "") === String(v) ? " selected" : ""}>${esc(l)}</option>`).join("")}</select>` : `<input class="form-control form-control-sm" id="flt_${f.name}" name="${f.name}" type="${f.type || "search"}" value="${esc(values[f.name] || "")}" placeholder="${esc(f.placeholder || "")}">`}</div>`).join("")}<div class="col-auto"><button type="reset" class="btn btn-sm btn-light">Clear</button></div></form>`;
    return { html, bind(container) {
      const form = $("[data-filters]", container);
      let t;
      const fire = () => { const o = {}; fields.forEach((f) => (o[f.name] = form.elements[f.name].value)); onChange(o); };
      form.oninput = () => { clearTimeout(t); t = setTimeout(fire, 300); };
      form.onchange = fire;
      form.onreset = () => setTimeout(fire, 0);
      form.onsubmit = (e) => { e.preventDefault(); fire(); };
    } };
  }

  /** Generic list page: header + filters + table backed by an API list endpoint. */
  async function listPage({ title, crumbs, endpoint, filters, columns, sort, addLabel, onAdd, onRow, actions, exportName, initial = {}, extraHeader = "" }) {
    setPage(title, crumbs || [title]);
    const view = $("#view");
    let values = { ...initial };
    const fb = filterBar(filters, values, (v) => { values = v; load(); });
    view.innerHTML = `<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><h1 class="h4 mb-0">${esc(title)}</h1><div class="d-flex gap-2">${extraHeader}${addLabel ? `<button class="btn btn-primary" data-add><i class="bi bi-plus-lg me-1"></i>${esc(addLabel)}</button>` : ""}</div></div>
      <div class="card">${fb.html}<div data-table>${loading()}</div></div>`;
    fb.bind(view);
    if (addLabel) $("[data-add]", view).onclick = () => onAdd(load);
    const tableEl = $("[data-table]", view);
    let table;
    async function load() {
      try {
        const rows = await api("GET", endpoint + qs(values));
        if (!table) table = dataTable(tableEl, { columns, rows, sort, onRow, actions: actions && ((r) => actions(r)), exportName });
        else table.update(rows);
        bindActions();
      } catch (e) { tableEl.innerHTML = errorBox(e); }
    }
    function bindActions() { tableEl.onclick = (e) => { const b = e.target.closest("[data-act]"); if (b && listPage.handlers[b.dataset.act]) listPage.handlers[b.dataset.act](b.dataset.id, load); }; }
    await load();
    return load;
  }
  listPage.handlers = {};
  const actBtn = (act, id, icon, label, cls = "btn-light") => `<button class="btn btn-sm ${cls} ms-1" data-act="${act}" data-id="${id}" title="${label}" aria-label="${label}"><i class="bi bi-${icon}"></i></button>`;

  async function del(path, label, reload) {
    if (!(await confirmDialog(`Delete ${label}? This cannot be undone. Records with history will be archived instead.`, { ok: "Delete" }))) return;
    try { const r = await api("DELETE", path); toast(r.message || `${label} deleted`, r.archived ? "warning" : "success"); reload(); } catch (e) { showError(e); }
  }

  /* ------------ dashboard ------------ */
  async function pageDashboard() {
    setPage("Dashboard", ["Dashboard"]);
    const view = $("#view");
    view.innerHTML = loading();
    let d;
    try { d = await api("GET", "/dashboard"); } catch (e) { view.innerHTML = errorBox(e); return; }
    const c = d.cards;
    const card = (label, value, icon, gold) => `<div class="col-6 col-xl-3"><div class="card stat-card h-100"><div class="card-body d-flex justify-content-between"><div><div class="label">${label}</div><div class="value">${value}</div></div><div class="icon ${gold ? "gold" : ""}"><i class="bi bi-${icon}"></i></div></div></div></div>`;
    const qa = [["#/customers?add=1", "person-plus", "Add Customer"], ["#/events?add=1", "calendar-plus", "Create Event"], ["#/menus?add=1", "journal-plus", "Add Menu"], ["#/bookings/new", "clipboard-plus", "Create Booking"], ["#/payments?add=1", "cash-stack", "Record Payment"], ["#/reports", "file-earmark-bar-graph", "Generate Report"]];
    view.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-3"><div><h1 class="h4 mb-0">Welcome back, ${esc(state.user.full_name.split(" ")[0])}</h1><div class="text-muted small">Today is ${fdate(d.today)}</div></div></div>
      <div class="row g-3 mb-3">
        ${card("Total customers", c.total_customers, "people")}${card("Total events", c.total_events, "calendar-event")}
        ${card("Total bookings", c.total_bookings, "clipboard-check")}${card("Upcoming events", c.upcoming_events, "calendar2-week")}
        ${card("Total booking value", money(c.total_booking_value), "graph-up", true)}${card("Amount collected", money(c.amount_collected), "cash-coin", true)}
        ${card("Outstanding balance", money(c.outstanding_balance), "hourglass-split", true)}${card("Completed bookings", c.completed_bookings, "check2-circle")}
      </div>
      <div class="card mb-3"><div class="card-body"><div class="row g-2">${qa.map(([h, i, l]) => `<div class="col-4 col-md-2"><a class="quick-action" href="${h}"><i class="bi bi-${i}"></i>${l}</a></div>`).join("")}</div></div></div>
      <div class="row g-3 mb-3">
        <div class="col-lg-6"><div class="card h-100"><div class="card-header">Monthly bookings</div><div class="card-body"><canvas id="chBookings" height="200"></canvas></div></div></div>
        <div class="col-lg-6"><div class="card h-100"><div class="card-header">Monthly collections (₹)</div><div class="card-body"><canvas id="chCollections" height="200"></canvas></div></div></div>
        <div class="col-md-6 col-lg-3"><div class="card h-100"><div class="card-header">Booking status</div><div class="card-body"><canvas id="chStatus" height="220"></canvas></div></div></div>
        <div class="col-md-6 col-lg-3"><div class="card h-100"><div class="card-header">Payment status</div><div class="card-body"><canvas id="chPay" height="220"></canvas></div></div></div>
        <div class="col-lg-6"><div class="card h-100"><div class="card-header d-flex justify-content-between">Upcoming event schedule <a href="#/events" class="small">View all</a></div><div class="list-group list-group-flush">
          ${d.upcoming.length ? d.upcoming.map((b) => `<a href="#/bookings/${b.booking_id}" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><div><div class="fw-semibold">${esc(b.event_type)} · ${esc(b.customer_name)}</div><div class="small text-muted"><i class="bi bi-geo-alt"></i> ${esc(b.venue)} · ${b.guest_count} guests</div></div><div class="text-end"><div class="small fw-semibold">${fdate(b.event_date)}</div><div class="small text-muted">${ftime(b.event_time)}</div>${badge(b.booking_status)}</div></a>`).join("") : '<div class="empty-state"><i class="bi bi-calendar-x"></i>No upcoming events</div>'}
        </div></div></div>
      </div>
      <div class="row g-3">
        <div class="col-lg-7"><div class="card h-100"><div class="card-header d-flex justify-content-between">Recent bookings <a href="#/bookings" class="small">View all</a></div><div data-recent></div></div></div>
        <div class="col-lg-5"><div class="card h-100"><div class="card-header d-flex justify-content-between">Pending payments <a href="#/payments" class="small">View all</a></div><div data-pending></div></div></div>
      </div>
      ${c.total_bookings ? '<p class="small text-muted mt-3 mb-0"><i class="bi bi-info-circle"></i> Sample records shipped with this project are fictional demonstration data.</p>' : ""}`;
    dataTable($("[data-recent]", view), { rows: d.recent_bookings, pageSize: 6, onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`), empty: "No bookings yet", columns: [
      { key: "booking_id", label: "ID", render: (r) => `#${r.booking_id}` }, { key: "customer_name", label: "Customer" }, { key: "event_date", label: "Event date", render: (r) => fdate(r.event_date) },
      { key: "total_amount", label: "Total", align: "end", render: (r) => money(r.total_amount) }, { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }] });
    dataTable($("[data-pending]", view), { rows: d.pending_payments, pageSize: 6, onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`), empty: "No outstanding balances", columns: [
      { key: "booking_id", label: "Booking", render: (r) => `#${r.booking_id} · ${esc(r.customer_name)}` }, { key: "balance", label: "Balance", align: "end", render: (r) => money(r.balance) }, { key: "payment_status", label: "Status", render: (r) => badge(r.payment_status) }] });

    state.charts.forEach((ch) => ch.destroy()); state.charts = [];
    if (window.Chart) {
      const green = "#0d5c4b", gold = "#b8892b";
      const labels = d.charts.months.map((m) => new Date(m + "-01").toLocaleString("en-IN", { month: "short", year: "2-digit" }));
      const opts = { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } };
      state.charts.push(new Chart($("#chBookings"), { type: "bar", data: { labels, datasets: [{ data: d.charts.monthly_bookings, backgroundColor: green, borderRadius: 4 }] }, options: opts }));
      state.charts.push(new Chart($("#chCollections"), { type: "line", data: { labels, datasets: [{ data: d.charts.monthly_collections, borderColor: gold, backgroundColor: "rgba(184,137,43,.15)", fill: true, tension: .3 }] }, options: { ...opts, scales: { y: { beginAtZero: true } } } }));
      const pie = (el, obj, colors) => state.charts.push(new Chart(el, { type: "doughnut", data: { labels: Object.keys(obj), datasets: [{ data: Object.values(obj), backgroundColor: colors }] }, options: { plugins: { legend: { position: "bottom", labels: { boxWidth: 10, font: { size: 11 } } } } } }));
      pie($("#chStatus"), d.charts.status_distribution, ["#e0b54a", "#3b82c4", "#7a5fc4", green, "#a3a3a3"]);
      pie($("#chPay"), d.charts.payment_distribution, d.charts && Object.keys(d.charts.payment_distribution).map((k) => ({ Unpaid: "#d64545", "Partially Paid": gold, Paid: green, Cancelled: "#a3a3a3" }[k])));
    }
  }

  /* ------------ customers ------------ */
  const customerFields = [
    { name: "name", label: "Full name", required: true, col: "col-md-6", maxlength: 100 },
    { name: "contact_no", label: "Contact number", required: true, col: "col-md-6", type: "tel", placeholderText: "10-digit mobile" },
    { name: "email", label: "Email (optional)", type: "email", col: "col-md-6" },
    { name: "address", label: "Address", type: "textarea", rows: 2, max: 255 },
  ];
  function customerForm(values, reload) {
    formModal({ title: values ? "Edit customer" : "Add customer", fields: values ? [...customerFields, { name: "is_active", label: "Active", type: "checkbox" }] : customerFields, values: values || {},
      onSubmit: async (data) => { const r = await api(values ? "PUT" : "POST", values ? `/customers/${values.customer_id}` : "/customers", data); toast(values ? "Customer updated" : `Customer #${r.customer_id} added`); reload(r); } });
  }
  listPage.handlers.editCustomer = async (id, reload) => { try { customerForm(await api("GET", `/customers/${id}`), reload); } catch (e) { showError(e); } };
  listPage.handlers.delCustomer = (id, reload) => del(`/customers/${id}`, `customer #${id}`, reload);
  async function pageCustomers(params) {
    await listPage({ title: "Customers", endpoint: "/customers", exportName: "customers", sort: ["customer_id", "desc"],
      filters: [{ name: "q", label: "Search", placeholder: "Name, ID or contact", col: "col-12 col-md-4" }, { name: "status", label: "Status", type: "select", options: [["active", "Active"], ["archived", "Archived"]] }],
      columns: [{ key: "customer_id", label: "ID", render: (r) => `#${r.customer_id}` }, { key: "name", label: "Name", render: (r) => `<span class="fw-semibold">${esc(r.name)}</span>` }, { key: "contact_no", label: "Contact" }, { key: "address", label: "Address" }, { key: "booking_count", label: "Bookings", align: "end" }, { key: "is_active", label: "Status", render: (r) => badge(r.is_active ? "Active" : "Inactive"), exportKey: "is_active" }],
      onRow: (r) => (location.hash = `#/customers/${r.customer_id}`), addLabel: "Add customer", onAdd: (reload) => customerForm(null, reload),
      actions: (r) => actBtn("editCustomer", r.customer_id, "pencil", "Edit") + actBtn("delCustomer", r.customer_id, "trash", "Delete", "btn-outline-danger") });
    if (params.get("add")) customerForm(null, () => route());
  }
  async function pageCustomer(id) {
    setPage("Customer details", ["Customers", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    try {
      const c = await api("GET", `/customers/${id}`);
      view.innerHTML = `<a href="#/customers" class="small no-print"><i class="bi bi-arrow-left"></i> Customers</a>
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 my-2"><h1 class="h4 mb-0">${esc(c.name)} ${badge(c.is_active ? "Active" : "Inactive")}</h1><div class="d-flex gap-2"><a class="btn btn-outline-primary" href="#/bookings/new?customer_id=${c.customer_id}"><i class="bi bi-clipboard-plus"></i> New booking</a><button class="btn btn-primary" data-edit><i class="bi bi-pencil"></i> Edit</button></div></div>
      <div class="row g-3"><div class="col-lg-4"><div class="card"><div class="card-body"><dl class="dl-grid mb-0"><dt>Customer ID</dt><dd>#${c.customer_id}</dd><dt>Contact</dt><dd>${esc(c.contact_no)}</dd><dt>Email</dt><dd>${esc(c.email || "—")}</dd><dt>Address</dt><dd>${esc(c.address || "—")}</dd><dt>Since</dt><dd>${fdate(c.created_at)}</dd></dl></div></div></div>
      <div class="col-lg-8"><div class="card mb-3"><div class="card-header">Bookings</div><div data-b></div></div><div class="card mb-3"><div class="card-header">Events</div><div data-e></div></div><div class="card"><div class="card-header">Feedback</div><div data-f></div></div></div></div>`;
      $("[data-edit]", view).onclick = () => customerForm(c, () => pageCustomer(id));
      dataTable($("[data-b]", view), { rows: c.bookings, pageSize: 5, onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`), empty: "No bookings", columns: [{ key: "booking_id", label: "ID", render: (r) => `#${r.booking_id}` }, { key: "event_type", label: "Event" }, { key: "event_date", label: "Date", render: (r) => fdate(r.event_date) }, { key: "total_amount", label: "Total", align: "end", render: (r) => money(r.total_amount) }, { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }, { key: "payment_status", label: "Payment", render: (r) => badge(r.payment_status) }] });
      dataTable($("[data-e]", view), { rows: c.events, pageSize: 5, onRow: (r) => (location.hash = `#/events/${r.event_id}`), empty: "No events", columns: [{ key: "event_id", label: "ID", render: (r) => `#${r.event_id}` }, { key: "event_type", label: "Type" }, { key: "event_date", label: "Date", render: (r) => `${fdate(r.event_date)} ${ftime(r.event_time)}` }, { key: "venue", label: "Venue" }] });
      dataTable($("[data-f]", view), { rows: c.feedback, pageSize: 5, empty: "No feedback", columns: [{ key: "booking_id", label: "Booking", render: (r) => `#${r.booking_id}` }, { key: "rating", label: "Rating", render: (r) => stars(r.rating) }, { key: "comments", label: "Comments" }] });
    } catch (e) { view.innerHTML = errorBox(e); }
  }

  /* ------------ events ------------ */
  async function eventForm(values, reload) {
    let customers; try { customers = await api("GET", "/customers?status=active"); } catch (e) { return showError(e); }
    const fields = [
      { name: "customer_id", label: "Customer", type: "select", required: true, options: customers.map((c) => [c.customer_id, `${c.name} (${c.contact_no})`]) },
      { name: "event_type", label: "Event type", type: "select", required: true, col: "col-md-6", options: EVENT_TYPES.map((t) => [t, t]) },
      { name: "venue", label: "Venue", required: true, col: "col-md-6", maxlength: 200 },
      { name: "event_date", label: "Event date", type: "date", required: true, col: "col-md-6" },
      { name: "event_time", label: "Event time", type: "time", required: true, col: "col-md-6" },
      { name: "notes", label: "Notes", type: "textarea", rows: 2, max: 500 },
    ];
    formModal({ title: values?.event_id ? "Edit event" : "Create event", fields, values: values || {}, onSubmit: async (data) => {
      const r = await api(values?.event_id ? "PUT" : "POST", values?.event_id ? `/events/${values.event_id}` : "/events", data);
      toast(values?.event_id ? "Event updated" : `Event #${r.event_id} created`);
      (r.warnings || []).forEach((w) => toast("Possible conflict: " + w, "warning"));
      reload(r);
    } });
  }
  listPage.handlers.editEvent = async (id, reload) => { try { eventForm(await api("GET", `/events/${id}`), reload); } catch (e) { showError(e); } };
  listPage.handlers.delEvent = (id, reload) => del(`/events/${id}`, `event #${id}`, reload);
  async function pageEvents(params) {
    const mode = params.get("view") || "list";
    if (mode === "calendar") return pageEventCalendar(params);
    let customers = []; try { customers = await api("GET", "/customers"); } catch {}
    await listPage({ title: "Events", endpoint: "/events", exportName: "events", sort: ["event_date", "asc"],
      extraHeader: `<a class="btn btn-outline-primary" href="#/events?view=calendar"><i class="bi bi-calendar3"></i> Calendar view</a>`,
      filters: [{ name: "q", label: "Search", placeholder: "Type, venue, customer", col: "col-12 col-md-3" }, { name: "event_type", label: "Event type", type: "select", options: EVENT_TYPES.map((t) => [t, t]) },
        { name: "customer_id", label: "Customer", type: "select", options: customers.map((c) => [c.customer_id, c.name]) }, { name: "venue", label: "Venue", placeholder: "Venue" }, { name: "from", label: "From", type: "date" }, { name: "to", label: "To", type: "date" }],
      columns: [{ key: "event_id", label: "ID", render: (r) => `#${r.event_id}` }, { key: "event_type", label: "Type", render: (r) => `<span class="fw-semibold">${esc(r.event_type)}</span>` }, { key: "event_date", label: "Date & time", render: (r) => `${fdate(r.event_date)} <span class="text-muted small">${ftime(r.event_time)}</span>` },
        { key: "venue", label: "Venue" }, { key: "customer_name", label: "Customer" }, { key: "guest_count", label: "Guests", align: "end", render: (r) => r.guest_count ?? "—" }, { key: "booking_status", label: "Booking", render: (r) => r.booking_status ? badge(r.booking_status) : '<span class="text-muted small">Not booked</span>' }, { key: "staff_count", label: "Staff", align: "end" }],
      onRow: (r) => (location.hash = `#/events/${r.event_id}`), addLabel: "Create event", onAdd: (reload) => eventForm(null, reload),
      actions: (r) => actBtn("editEvent", r.event_id, "pencil", "Edit") + actBtn("delEvent", r.event_id, "trash", "Delete", "btn-outline-danger") });
    if (params.get("add")) eventForm({ customer_id: params.get("customer_id") }, () => route());
  }
  async function pageEventCalendar(params) {
    setPage("Event calendar", ["Events", "Calendar"]);
    const view = $("#view");
    const month = params.get("month") || today().slice(0, 7);
    const [y, m] = month.split("-").map(Number);
    const first = new Date(Date.UTC(y, m - 1, 1)), days = new Date(Date.UTC(y, m, 0)).getUTCDate();
    const shift = (n) => { const d = new Date(Date.UTC(y, m - 1 + n, 1)); return d.toISOString().slice(0, 7); };
    view.innerHTML = loading();
    try {
      const evs = await api("GET", "/events" + qs({ from: `${month}-01`, to: `${month}-${String(days).padStart(2, "0")}` }));
      const cells = [];
      ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].forEach((d) => cells.push(`<div class="dow">${d}</div>`));
      for (let i = 0; i < first.getUTCDay(); i++) cells.push('<div class="muted"></div>');
      for (let d = 1; d <= days; d++) {
        const ds = `${month}-${String(d).padStart(2, "0")}`;
        const list = evs.filter((e) => e.event_date === ds);
        cells.push(`<div class="${ds === today() ? "today" : ""}"><div class="fw-semibold">${d}</div>${list.map((e) => `<a class="ev" href="#/events/${e.event_id}" title="${esc(e.event_type)} – ${esc(e.venue)}">${ftime(e.event_time)} ${esc(e.event_type)} · ${esc(e.customer_name)}</a>`).join("")}</div>`);
      }
      view.innerHTML = `<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><h1 class="h4 mb-0">${first.toLocaleString("en-IN", { month: "long", year: "numeric", timeZone: "UTC" })}</h1>
        <div class="d-flex gap-2"><a class="btn btn-light" href="#/events?view=calendar&month=${shift(-1)}" aria-label="Previous month"><i class="bi bi-chevron-left"></i></a><a class="btn btn-light" href="#/events?view=calendar">Today</a><a class="btn btn-light" href="#/events?view=calendar&month=${shift(1)}" aria-label="Next month"><i class="bi bi-chevron-right"></i></a><a class="btn btn-outline-primary" href="#/events"><i class="bi bi-list-ul"></i> List view</a></div></div>
        <div class="card overflow-hidden"><div class="cal">${cells.join("")}</div></div>`;
    } catch (e) { view.innerHTML = errorBox(e); }
  }
  async function pageEvent(id) {
    setPage("Event details", ["Events", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    try {
      const e = await api("GET", `/events/${id}`);
      const active = e.bookings.find((b) => b.booking_status !== "Cancelled");
      view.innerHTML = `<a href="#/events" class="small"><i class="bi bi-arrow-left"></i> Events</a>
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 my-2"><h1 class="h4 mb-0">${esc(e.event_type)} · ${fdate(e.event_date)}</h1><div class="d-flex gap-2">${active ? "" : `<a class="btn btn-outline-primary" href="#/bookings/new?customer_id=${e.customer_id}&event_id=${e.event_id}"><i class="bi bi-clipboard-plus"></i> Create booking</a>`}<button class="btn btn-outline-primary" data-assign><i class="bi bi-person-plus"></i> Assign staff</button><button class="btn btn-primary" data-edit><i class="bi bi-pencil"></i> Edit</button></div></div>
      ${e.warnings.map((w) => `<div class="alert alert-warning py-2 small"><i class="bi bi-exclamation-triangle"></i> ${esc(w)}</div>`).join("")}
      <div class="row g-3"><div class="col-lg-4"><div class="card"><div class="card-body"><dl class="dl-grid mb-0"><dt>Event ID</dt><dd>#${e.event_id}</dd><dt>Type</dt><dd>${esc(e.event_type)}</dd><dt>Date</dt><dd>${fdate(e.event_date)}</dd><dt>Time</dt><dd>${ftime(e.event_time)}</dd><dt>Venue</dt><dd>${esc(e.venue)}</dd><dt>Customer</dt><dd><a href="#/customers/${e.customer_id}">${esc(e.customer?.name)}</a></dd><dt>Notes</dt><dd>${esc(e.notes || "—")}</dd></dl></div></div></div>
      <div class="col-lg-8"><div class="card mb-3"><div class="card-header">Bookings</div><div data-b></div></div><div class="card"><div class="card-header">Assigned staff</div><div data-a></div></div></div></div>`;
      $("[data-edit]", view).onclick = () => eventForm(e, () => pageEvent(id));
      $("[data-assign]", view).onclick = () => assignmentForm({ event_id: e.event_id }, () => pageEvent(id));
      dataTable($("[data-b]", view), { rows: e.bookings, onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`), empty: "Not booked yet", columns: [{ key: "booking_id", label: "ID", render: (r) => `#${r.booking_id}` }, { key: "menu_name_snapshot", label: "Menu" }, { key: "guest_count", label: "Guests", align: "end" }, { key: "total_amount", label: "Total", align: "end", render: (r) => money(r.total_amount) }, { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }] });
      dataTable($("[data-a]", view), { rows: e.assignments, empty: "No staff assigned", columns: [{ key: "staff_name", label: "Staff", render: (r) => `<a href="#/staff/${r.staff_id}">${esc(r.staff_name)}</a>` }, { key: "role", label: "Role" }, { key: "work_assigned", label: "Work assigned" }] });
    } catch (err) { view.innerHTML = errorBox(err); }
  }

  /* ------------ menus ------------ */
  function menuForm(values, reload) {
    formModal({ title: values ? "Edit menu" : "Add menu", values: values || { availability: true }, fields: [
      { name: "menu_name", label: "Menu / package name", required: true, maxlength: 100 },
      { name: "category", label: "Category", type: "select", required: true, col: "col-md-6", options: MENU_CATEGORIES.map((c) => [c, c]) },
      { name: "price", label: `Price (₹) ${state.settings?.pricing_model === "fixed" ? "per package" : "per person"}`, type: "number", step: "0.01", min: 0, required: true, col: "col-md-6" },
      { name: "description", label: "Description", type: "textarea", rows: 2, max: 500 },
      { name: "availability", label: "Available for new bookings", type: "checkbox" },
    ], onSubmit: async (data) => { const r = await api(values ? "PUT" : "POST", values ? `/menus/${values.menu_id}` : "/menus", data); toast(values ? "Menu updated. Existing bookings keep their agreed price." : `Menu #${r.menu_id} added`); reload(r); } });
  }
  listPage.handlers.editMenu = async (id, reload) => { try { menuForm(await api("GET", `/menus/${id}`), reload); } catch (e) { showError(e); } };
  listPage.handlers.delMenu = (id, reload) => del(`/menus/${id}`, `menu #${id}`, reload);
  async function pageMenus(params) {
    await listPage({ title: "Menu Management", endpoint: "/menus", exportName: "menus", sort: ["menu_name", "asc"],
      filters: [{ name: "q", label: "Search", placeholder: "Menu name", col: "col-12 col-md-4" }, { name: "category", label: "Category", type: "select", options: MENU_CATEGORIES.map((c) => [c, c]) }, { name: "availability", label: "Availability", type: "select", options: [["available", "Available"], ["unavailable", "Unavailable"]] }],
      columns: [{ key: "menu_id", label: "ID", render: (r) => `#${r.menu_id}` }, { key: "menu_name", label: "Menu / package", render: (r) => `<div class="fw-semibold">${esc(r.menu_name)}</div><div class="small text-muted">${esc(r.description || "")}</div>` }, { key: "category", label: "Category" }, { key: "price", label: `Price (${state.settings?.pricing_model === "fixed" ? "package" : "per person"})`, align: "end", render: (r) => money(r.price) }, { key: "availability", label: "Availability", render: (r) => r.availability ? '<span class="badge st-Active">Available</span>' : '<span class="badge st-Inactive">Unavailable</span>' }],
      onRow: (r) => (location.hash = `#/menus/${r.menu_id}`), addLabel: "Add menu", onAdd: (reload) => menuForm(null, reload),
      actions: (r) => actBtn("editMenu", r.menu_id, "pencil", "Edit") + actBtn("delMenu", r.menu_id, "trash", "Delete", "btn-outline-danger") });
    if (params.get("add")) menuForm(null, () => route());
  }
  async function pageMenu(id) {
    setPage("Menu details", ["Menu Management", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    try {
      const m = await api("GET", `/menus/${id}`);
      view.innerHTML = `<a href="#/menus" class="small"><i class="bi bi-arrow-left"></i> Menus</a><div class="d-flex justify-content-between align-items-center my-2"><h1 class="h4 mb-0">${esc(m.menu_name)}</h1><button class="btn btn-primary" data-edit><i class="bi bi-pencil"></i> Edit</button></div>
        <div class="row g-3"><div class="col-lg-4"><div class="card"><div class="card-body"><dl class="dl-grid mb-0"><dt>Menu ID</dt><dd>#${m.menu_id}</dd><dt>Category</dt><dd>${esc(m.category)}</dd><dt>Current price</dt><dd>${money(m.price)}</dd><dt>Availability</dt><dd>${m.availability ? "Available" : "Unavailable"}</dd><dt>Description</dt><dd>${esc(m.description || "—")}</dd></dl></div></div></div>
        <div class="col-lg-8"><div class="card"><div class="card-header">Bookings using this menu <span class="small text-muted fw-normal">(agreed price stored on each booking)</span></div><div data-b></div></div></div></div>`;
      $("[data-edit]", view).onclick = () => menuForm(m, () => pageMenu(id));
      dataTable($("[data-b]", view), { rows: m.bookings, onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`), empty: "No bookings", columns: [{ key: "booking_id", label: "ID", render: (r) => `#${r.booking_id}` }, { key: "customer_name", label: "Customer" }, { key: "unit_price", label: "Agreed price", align: "end", render: (r) => money(r.unit_price) }, { key: "guest_count", label: "Guests", align: "end" }, { key: "total_amount", label: "Total", align: "end", render: (r) => money(r.total_amount) }, { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }] });
    } catch (e) { view.innerHTML = errorBox(e); }
  }

  /* ------------ bookings ------------ */
  async function pageBookings(params) {
    let customers = []; try { customers = await api("GET", "/customers"); } catch {}
    await listPage({ title: "Bookings", endpoint: "/bookings", exportName: "bookings", sort: ["booking_id", "desc"], initial: { status: params.get("status") || "", payment_status: params.get("payment_status") || "" },
      extraHeader: "", addLabel: "Create booking", onAdd: () => (location.hash = "#/bookings/new"),
      filters: [{ name: "q", label: "Search", placeholder: "Booking ID or customer", col: "col-12 col-md-3" }, { name: "status", label: "Booking status", type: "select", options: STATUSES.map((s) => [s, s]) }, { name: "payment_status", label: "Payment", type: "select", options: PAY_STATUSES.map((s) => [s, s]) },
        { name: "customer_id", label: "Customer", type: "select", options: customers.map((c) => [c.customer_id, c.name]) }, { name: "event_from", label: "Event from", type: "date" }, { name: "event_to", label: "Event to", type: "date" }, { name: "booking_from", label: "Booked from", type: "date" }, { name: "booking_to", label: "Booked to", type: "date" }],
      columns: [{ key: "booking_id", label: "ID", render: (r) => `<span class="fw-semibold">#${r.booking_id}</span>${r.source === "inquiry" ? ' <span class="badge text-bg-light border" title="Submitted by customer">Inquiry</span>' : ""}` }, { key: "customer_name", label: "Customer" }, { key: "event_type", label: "Event", render: (r) => `${esc(r.event_type)}<div class="small text-muted">${fdate(r.event_date)}</div>`, sortValue: (r) => r.event_date },
        { key: "menu_name_snapshot", label: "Menu" }, { key: "guest_count", label: "Guests", align: "end" }, { key: "total_amount", label: "Total", align: "end", render: (r) => money(r.total_amount) }, { key: "balance", label: "Balance", align: "end", render: (r) => money(r.balance) },
        { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }, { key: "payment_status", label: "Payment", render: (r) => badge(r.payment_status) }],
      onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`) });
  }

  async function pageBookingNew(params) {
    setPage("Create booking", ["Bookings", "New"]);
    const view = $("#view"); view.innerHTML = loading();
    let R; try { R = await refs("customers", "events", "menus"); } catch (e) { view.innerHTML = errorBox(e); return; }
    const requestKey = uid();
    const pricing = state.settings?.pricing_model || "per_person";
    const menus = R.menus.filter((m) => m.availability);
    const customers = R.customers.filter((c) => c.is_active);
    view.innerHTML = `<a href="#/bookings" class="small"><i class="bi bi-arrow-left"></i> Bookings</a><h1 class="h4 my-2">Create booking</h1>
    <form novalidate id="bkForm"><div class="row g-3"><div class="col-lg-8"><div class="card"><div class="card-body">
      <div class="alert alert-danger d-none" data-form-error></div>
      <div class="wizard-step"><h2 class="h6"><span class="num">1</span>Customer</h2>
        <div class="btn-group btn-group-sm mb-2" role="group"><input type="radio" class="btn-check" name="cmode" id="cm1" value="existing" checked><label class="btn btn-outline-primary" for="cm1">Existing customer</label><input type="radio" class="btn-check" name="cmode" id="cm2" value="new"><label class="btn btn-outline-primary" for="cm2">New customer</label></div>
        <div data-cexisting><div class="row g-2">${fieldHtml({ name: "customer_id", label: "Select customer", type: "select", options: customers.map((c) => [c.customer_id, `${c.name} · ${c.contact_no}`]) }, params.get("customer_id"))}</div></div>
        <div data-cnew class="d-none"><div class="row g-2">${fieldHtml({ name: "nc_name", label: "Full name", col: "col-md-4" })}${fieldHtml({ name: "nc_contact_no", label: "Contact number", col: "col-md-4", type: "tel" })}${fieldHtml({ name: "nc_address", label: "Address", col: "col-md-4" })}</div></div>
      </div>
      <div class="wizard-step"><h2 class="h6"><span class="num">2</span>Event</h2>
        <div class="btn-group btn-group-sm mb-2" role="group"><input type="radio" class="btn-check" name="emode" id="em1" value="existing" checked><label class="btn btn-outline-primary" for="em1">Customer's existing event</label><input type="radio" class="btn-check" name="emode" id="em2" value="new"><label class="btn btn-outline-primary" for="em2">New event</label></div>
        <div data-eexisting><div class="row g-2"><div class="col-12"><label class="form-label" for="f_event_id">Select event</label><select class="form-select" id="f_event_id" name="event_id"></select><div class="invalid-feedback" data-err="event_id"></div></div></div></div>
        <div data-enew class="d-none"><div class="row g-2">${fieldHtml({ name: "ne_event_type", label: "Event type", type: "select", col: "col-md-6", options: EVENT_TYPES.map((t) => [t, t]) })}${fieldHtml({ name: "ne_venue", label: "Venue", col: "col-md-6" })}${fieldHtml({ name: "ne_event_date", label: "Date", type: "date", col: "col-md-6" })}${fieldHtml({ name: "ne_event_time", label: "Time", type: "time", col: "col-md-6" })}</div></div>
      </div>
      <div class="wizard-step"><h2 class="h6"><span class="num">3</span>Menu, guests and status</h2><div class="row g-2">
        ${fieldHtml({ name: "menu_id", label: "Menu / package (available only)", type: "select", col: "col-md-6", options: menus.map((m) => [m.menu_id, `${m.menu_name} — ${money(m.price)}${pricing === "fixed" ? "" : " / person"}`]) })}
        ${fieldHtml({ name: "guest_count", label: "Expected guests", type: "number", min: 1, step: 1, col: "col-md-3" })}
        ${fieldHtml({ name: "booking_date", label: "Booking date", type: "date", col: "col-md-3" }, today())}
        ${fieldHtml({ name: "booking_status", label: "Initial status", type: "select", col: "col-md-6", placeholder: false, options: [["Pending", "Pending"], ["Confirmed", "Confirmed"]] })}
        ${fieldHtml({ name: "notes", label: "Notes", col: "col-md-6" })}
      </div></div>
    </div></div></div>
    <div class="col-lg-4"><div class="card position-sticky" style="top:80px"><div class="card-header">Review</div><div class="card-body" data-review></div><div class="card-footer bg-white"><button class="btn btn-primary w-100" type="submit"><span class="spinner-border spinner-border-sm me-1 d-none"></span>Save booking</button></div></div></div></div></form>`;
    const form = $("#bkForm");
    const evSel = form.elements.event_id;
    const fillEvents = () => {
      const cid = form.elements.customer_id.value;
      const list = R.events.filter((e) => String(e.customer_id) === cid && !(e.booking_id && e.booking_status !== "Cancelled"));
      evSel.innerHTML = `<option value="">${cid ? (list.length ? "Select…" : "No unbooked events — create a new one") : "Select a customer first"}</option>` + list.map((e) => `<option value="${e.event_id}">${esc(e.event_type)} · ${fdate(e.event_date)} ${ftime(e.event_time)} · ${esc(e.venue)}</option>`).join("");
      if (params.get("event_id")) evSel.value = params.get("event_id");
    };
    const mode = (n) => form.querySelector(`[name=${n}]:checked`).value;
    const review = () => {
      const cm = mode("cmode"), em = mode("emode");
      $("[data-cexisting]", form).classList.toggle("d-none", cm !== "existing"); $("[data-cnew]", form).classList.toggle("d-none", cm !== "new");
      if (cm === "new") { $("#em2").checked = true; $("#em1").disabled = true; } else $("#em1").disabled = false;
      $("[data-eexisting]", form).classList.toggle("d-none", mode("emode") !== "existing"); $("[data-enew]", form).classList.toggle("d-none", mode("emode") !== "new");
      const c = cm === "existing" ? customers.find((x) => String(x.customer_id) === form.elements.customer_id.value) : { name: form.elements.nc_name.value };
      const e = mode("emode") === "existing" ? R.events.find((x) => String(x.event_id) === evSel.value) : { event_type: form.elements.ne_event_type.value, event_date: form.elements.ne_event_date.value, venue: form.elements.ne_venue.value };
      const m = menus.find((x) => String(x.menu_id) === form.elements.menu_id.value);
      const g = parseInt(form.elements.guest_count.value, 10);
      const total = m && g > 0 ? (pricing === "fixed" ? Number(m.price) : Math.round(Number(m.price) * 100 * g) / 100) : null;
      $("[data-review]", form).innerHTML = `<dl class="dl-grid small mb-3"><dt>Customer</dt><dd>${esc(c?.name || "—")}</dd><dt>Event</dt><dd>${e?.event_type ? `${esc(e.event_type)} · ${fdate(e.event_date)}` : "—"}</dd><dt>Venue</dt><dd>${esc(e?.venue || "—")}</dd><dt>Menu</dt><dd>${esc(m?.menu_name || "—")}</dd><dt>Guests</dt><dd>${g > 0 ? g : "—"}</dd><dt>Pricing</dt><dd>${pricing === "fixed" ? "Fixed package price" : "Price × guests"}</dd></dl>
        <div class="d-flex justify-content-between align-items-baseline border-top pt-2"><span class="text-muted">Proposed total</span><span class="fs-5 fw-bold text-primary">${total !== null ? money(total) : "—"}</span></div>`;
    };
    form.elements.customer_id.onchange = () => { fillEvents(); review(); };
    form.oninput = review; form.onchange = review;
    fillEvents(); review();
    form.onsubmit = async (ev) => {
      ev.preventDefault();
      const cm = mode("cmode"), em = mode("emode"), f = form.elements;
      const errs = {};
      if (cm === "existing" && !f.customer_id.value) errs.customer_id = "Select a customer";
      if (cm === "new") { if (!f.nc_name.value.trim()) errs.nc_name = "Name is required"; if (!f.nc_contact_no.value.trim()) errs.nc_contact_no = "Contact is required"; }
      if (em === "existing" && !evSel.value) errs.event_id = "Select an event";
      if (em === "new") { if (!f.ne_event_type.value) errs.ne_event_type = "Required"; if (!f.ne_venue.value.trim()) errs.ne_venue = "Required"; if (!f.ne_event_date.value) errs.ne_event_date = "Required"; if (!f.ne_event_time.value) errs.ne_event_time = "Required"; }
      if (!f.menu_id.value) errs.menu_id = "Select a menu";
      if (!(parseInt(f.guest_count.value, 10) > 0) || String(parseInt(f.guest_count.value, 10)) !== f.guest_count.value.trim()) errs.guest_count = "Enter a positive whole number";
      showFieldErrors(form, errs);
      if (Object.keys(errs).length) return;
      const body = { menu_id: f.menu_id.value, guest_count: f.guest_count.value, booking_date: f.booking_date.value, booking_status: f.booking_status.value, notes: f.notes.value, request_key: requestKey };
      if (cm === "existing") body.customer_id = f.customer_id.value; else body.new_customer = { name: f.nc_name.value, contact_no: f.nc_contact_no.value, address: f.nc_address.value };
      if (em === "existing") body.event_id = evSel.value; else body.new_event = { event_type: f.ne_event_type.value, venue: f.ne_venue.value, event_date: f.ne_event_date.value, event_time: f.ne_event_time.value };
      const btn = $("[type=submit]", form), alertEl = $("[data-form-error]", form);
      btn.disabled = true; $(".spinner-border", btn).classList.remove("d-none"); alertEl.classList.add("d-none");
      try {
        const b = await api("POST", "/bookings", body);
        toast(b.duplicate ? `Booking #${b.booking_id} was already saved` : `Booking #${b.booking_id} saved`);
        location.hash = `#/bookings/${b.booking_id}?created=1`;
      } catch (e) {
        const map = { name: "nc_name", contact_no: "nc_contact_no", event_type: "ne_event_type", venue: "ne_venue", event_date: "ne_event_date", event_time: "ne_event_time" };
        const fe = {}; Object.entries(e.errors || {}).forEach(([k, v]) => (fe[(cm === "new" && ["name", "contact_no"].includes(k)) || (em === "new" && k.startsWith("event_") && k !== "event_id") || (em === "new" && k === "venue") ? map[k] : k] = v));
        showFieldErrors(form, fe);
        alertEl.textContent = e.message; alertEl.classList.remove("d-none"); window.scrollTo({ top: 0, behavior: "smooth" });
      } finally { btn.disabled = false; $(".spinner-border", btn).classList.add("d-none"); }
    };
  }

  async function pageBooking(id, params) {
    setPage(`Booking #${id}`, ["Bookings", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    let b; try { b = await api("GET", `/bookings/${id}`); } catch (e) { view.innerHTML = errorBox(e); return; }
    const s = state.settings || {};
    const editable = !["Completed", "Cancelled"].includes(b.booking_status);
    view.innerHTML = `<a href="#/bookings" class="small no-print"><i class="bi bi-arrow-left"></i> Bookings</a>
      ${params.get("created") ? `<div class="alert alert-success mt-2 no-print"><i class="bi bi-check-circle"></i> Booking <strong>#${b.booking_id}</strong> has been saved with status <strong>${esc(b.booking_status)}</strong>. The confirmation below shows the saved record.</div>` : ""}
      <div class="print-only mb-3"><h2 class="h5 mb-0">${esc(s.business_name)}</h2><div class="small">${esc(s.business_address)} · ${esc(s.business_phone)}</div><hr><h3 class="h5">Booking ${b.booking_status === "Confirmed" ? "Confirmation" : "Summary"} #${b.booking_id}</h3></div>
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 my-2 no-print"><h1 class="h4 mb-0">Booking #${b.booking_id} ${badge(b.booking_status)} ${badge(b.payment_status)}</h1>
        <div class="d-flex flex-wrap gap-2">
          ${b.allowed_statuses.filter((x) => x !== b.booking_status).map((x) => `<button class="btn btn-sm ${x === "Cancelled" ? "btn-outline-danger" : "btn-outline-primary"}" data-status="${x}">Mark ${x}</button>`).join("")}
          ${editable ? '<button class="btn btn-sm btn-light" data-edit><i class="bi bi-pencil"></i> Edit</button>' : ""}
          <button class="btn btn-sm btn-light" onclick="window.print()"><i class="bi bi-printer"></i> Print summary</button>
        </div></div>
      <div class="row g-3">
        <div class="col-lg-6"><div class="card h-100"><div class="card-header">Booking details</div><div class="card-body"><dl class="dl-grid mb-0">
          <dt>Booking ID</dt><dd>#${b.booking_id}</dd><dt>Booking date</dt><dd>${fdate(b.booking_date)}</dd><dt>Customer</dt><dd><a href="#/customers/${b.customer_id}">${esc(b.customer_name)}</a> · ${esc(b.contact_no)}</dd>
          <dt>Event</dt><dd><a href="#/events/${b.event_id}">${esc(b.event_type)}</a></dd><dt>Date & time</dt><dd>${fdate(b.event_date)} at ${ftime(b.event_time)}</dd><dt>Venue</dt><dd>${esc(b.venue)}</dd>
          <dt>Menu / package</dt><dd>${esc(b.menu_name_snapshot)}</dd><dt>Agreed price</dt><dd>${money(b.unit_price)} ${b.pricing_model === "fixed" ? "(fixed package)" : "per person"}</dd>
          <dt>Expected guests</dt><dd>${b.guest_count} ${editable ? '<button class="btn btn-link btn-sm p-0 ms-1 no-print" data-guests>Update</button>' : ""}</dd><dt>Source</dt><dd>${b.source === "inquiry" ? "Customer inquiry form" : "Manager"}</dd><dt>Notes</dt><dd>${esc(b.notes || "—")}</dd>
        </dl></div></div></div>
        <div class="col-lg-6"><div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center">Payment summary ${b.booking_status !== "Cancelled" && b.balance > 0 ? '<button class="btn btn-sm btn-gold no-print" data-pay><i class="bi bi-cash-coin"></i> Record payment</button>' : ""}</div><div class="card-body">
          <div class="row text-center g-2 mb-3"><div class="col-4"><div class="small text-muted">Total</div><div class="fw-bold">${money(b.total_amount)}</div></div><div class="col-4"><div class="small text-muted">Received</div><div class="fw-bold text-primary">${money(b.amount_paid)}</div></div><div class="col-4"><div class="small text-muted">Balance</div><div class="fw-bold text-danger">${money(b.balance)}</div></div></div>
          <div data-pays></div></div></div></div>
        <div class="col-lg-6"><div class="card"><div class="card-header d-flex justify-content-between align-items-center">Staff assigned to this event <button class="btn btn-sm btn-light no-print" data-assign><i class="bi bi-person-plus"></i> Assign</button></div><div data-staff></div></div></div>
        <div class="col-lg-6"><div class="card"><div class="card-header d-flex justify-content-between align-items-center">Feedback ${!b.feedback && b.booking_status !== "Cancelled" ? '<button class="btn btn-sm btn-light no-print" data-fb><i class="bi bi-star"></i> Add feedback</button>' : ""}</div><div class="card-body">${b.feedback ? `${stars(b.feedback.rating)}<p class="mb-0 mt-1">${esc(b.feedback.comments || "")}</p>` : '<span class="text-muted small">No feedback recorded.</span>'}</div></div></div>
      </div>
      <p class="print-only small mt-4">${esc(s.report_footer)}. Printed ${new Date().toLocaleString("en-IN")}.</p>`;
    dataTable($("[data-pays]", view), { rows: b.payments, pageSize: 20, empty: "No payments recorded", onRow: (r) => (location.hash = `#/payments/${r.payment_id}`), columns: [{ key: "payment_id", label: "Receipt", render: (r) => `#${r.payment_id}` }, { key: "payment_date", label: "Date", render: (r) => fdate(r.payment_date) }, { key: "payment_mode", label: "Mode" }, { key: "advance_payment", label: "Amount", align: "end", render: (r) => money(r.advance_payment) }, { key: "remaining_balance", label: "Balance after", align: "end", render: (r) => money(r.remaining_balance) }] });
    dataTable($("[data-staff]", view), { rows: b.assignments, empty: "No staff assigned yet", columns: [{ key: "staff_name", label: "Staff" }, { key: "role", label: "Role" }, { key: "work_assigned", label: "Work" }] });
    const reload = () => pageBooking(id, new URLSearchParams());
    $$("[data-status]", view).forEach((btn) => (btn.onclick = async () => {
      const to = btn.dataset.status;
      if (!(await confirmDialog(`Change booking #${b.booking_id} from ${b.booking_status} to ${to}?${to === "Cancelled" ? " Payment history will be kept." : ""}`, { ok: `Mark ${to}`, danger: to === "Cancelled" }))) return;
      try { await api("PATCH", `/bookings/${b.booking_id}/status`, { booking_status: to }); toast(`Booking marked ${to}`); refreshNotifications(); reload(); } catch (e) { showError(e); }
    }));
    const g = $("[data-guests]", view); if (g) g.onclick = () => guestForm(b, reload);
    const p = $("[data-pay]", view); if (p) p.onclick = () => paymentForm({ booking_id: b.booking_id }, (r) => (location.hash = `#/payments/${r.payment_id}`));
    $("[data-assign]", view).onclick = () => assignmentForm({ event_id: b.event_id }, reload);
    const fbb = $("[data-fb]", view); if (fbb) fbb.onclick = () => feedbackForm({ booking_id: b.booking_id }, reload);
    const ed = $("[data-edit]", view);
    if (ed) ed.onclick = async () => {
      let menus = []; try { menus = (await api("GET", "/menus")).filter((m) => m.availability || m.menu_id === b.menu_id); } catch (e) { return showError(e); }
      formModal({ title: `Edit booking #${b.booking_id}`, values: b, fields: [
        { name: "menu_id", label: "Menu / package", type: "select", required: true, options: menus.map((m) => [m.menu_id, m.menu_id === b.menu_id ? `${b.menu_name_snapshot} — agreed ${money(b.unit_price)}` : `${m.menu_name} — ${money(m.price)}`]), help: "Changing the menu applies the selected menu's current price." },
        { name: "guest_count", label: "Expected guests", type: "number", min: 1, required: true, col: "col-md-6" },
        { name: "booking_date", label: "Booking date", type: "date", required: true, col: "col-md-6" },
        { name: "notes", label: "Notes", type: "textarea", rows: 2, max: 500 },
      ], onSubmit: async (data) => { await api("PUT", `/bookings/${b.booking_id}`, data); toast("Booking updated"); reload(); } });
    };
  }

  /* ------------ guests ------------ */
  function guestForm(b, reload) {
    formModal({ title: `Guest count · booking #${b.booking_id}`, values: { guest_count: b.guest_count, remarks: b.remarks || b.guest?.remarks || "" }, fields: [
      { name: "guest_count", label: "Expected guests", type: "number", min: 1, step: 1, required: true, help: "The booking total is recalculated using the agreed price." },
      { name: "remarks", label: "Planning remarks", type: "textarea", rows: 2, max: 255 },
    ], onSubmit: async (data) => { const r = await api("PUT", `/guests/${b.booking_id}`, data); toast(`Guest count updated. New total ${money(r.total_amount)}`); reload(); } });
  }
  listPage.handlers.editGuests = async (id, reload) => { try { guestForm(await api("GET", `/bookings/${id}`), reload); } catch (e) { showError(e); } };
  async function pageGuests() {
    await listPage({ title: "Guest Management", endpoint: "/guests", exportName: "guest-counts", sort: ["event_date", "asc"],
      filters: [{ name: "q", label: "Search", placeholder: "Booking ID or customer", col: "col-12 col-md-4" }, { name: "status", label: "Booking status", type: "select", options: STATUSES.map((s) => [s, s]) }, { name: "from", label: "Event from", type: "date" }, { name: "to", label: "Event to", type: "date" }],
      columns: [{ key: "booking_id", label: "Booking", render: (r) => `#${r.booking_id}` }, { key: "customer_name", label: "Customer" }, { key: "event_type", label: "Event" }, { key: "event_date", label: "Event date", render: (r) => fdate(r.event_date) }, { key: "menu_name_snapshot", label: "Menu" },
        { key: "guest_count", label: "Expected guests", align: "end", render: (r) => `<span class="fw-bold">${r.guest_count}</span>` }, { key: "remarks", label: "Remarks" }, { key: "booking_status", label: "Status", render: (r) => badge(r.booking_status) }],
      onRow: (r) => (location.hash = `#/bookings/${r.booking_id}`),
      actions: (r) => !["Completed", "Cancelled"].includes(r.booking_status) ? actBtn("editGuests", r.booking_id, "pencil", "Update guest count") : "" });
  }

  /* ------------ staff ------------ */
  function staffForm(values, reload) {
    formModal({ title: values ? "Edit staff member" : "Add staff member", values: values || { is_active: true }, fields: [
      { name: "staff_name", label: "Full name", required: true, maxlength: 100 },
      { name: "role", label: "Role", type: "select", required: true, col: "col-md-6", options: STAFF_ROLES.map((r) => [r, r]) },
      { name: "contact_no", label: "Contact number", type: "tel", col: "col-md-6" },
      { name: "is_active", label: "Active (can receive new assignments)", type: "checkbox" },
    ], onSubmit: async (data) => { const r = await api(values ? "PUT" : "POST", values ? `/staff/${values.staff_id}` : "/staff", data); toast(values ? "Staff updated" : `Staff #${r.staff_id} added`); reload(r); } });
  }
  listPage.handlers.editStaff = async (id, reload) => { try { staffForm(await api("GET", `/staff/${id}`), reload); } catch (e) { showError(e); } };
  listPage.handlers.delStaff = (id, reload) => del(`/staff/${id}`, `staff #${id}`, reload);
  async function pageStaffList() {
    await listPage({ title: "Staff Management", endpoint: "/staff", exportName: "staff", sort: ["staff_name", "asc"],
      filters: [{ name: "q", label: "Search", placeholder: "Name or staff ID", col: "col-12 col-md-4" }, { name: "role", label: "Role", type: "select", options: STAFF_ROLES.map((r) => [r, r]) }, { name: "status", label: "Status", type: "select", options: [["active", "Active"], ["inactive", "Inactive"]] }],
      columns: [{ key: "staff_id", label: "ID", render: (r) => `#${r.staff_id}` }, { key: "staff_name", label: "Name", render: (r) => `<span class="fw-semibold">${esc(r.staff_name)}</span>` }, { key: "role", label: "Role" }, { key: "contact_no", label: "Contact" }, { key: "assignment_count", label: "Assignments", align: "end" }, { key: "is_active", label: "Status", render: (r) => badge(r.is_active ? "Active" : "Inactive") }],
      onRow: (r) => (location.hash = `#/staff/${r.staff_id}`), addLabel: "Add staff", onAdd: (reload) => staffForm(null, reload),
      actions: (r) => actBtn("editStaff", r.staff_id, "pencil", "Edit") + actBtn("delStaff", r.staff_id, "trash", "Delete", "btn-outline-danger") });
  }
  async function pageStaff(id) {
    setPage("Staff details", ["Staff Management", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    try {
      const s = await api("GET", `/staff/${id}`);
      view.innerHTML = `<a href="#/staff" class="small"><i class="bi bi-arrow-left"></i> Staff</a><div class="d-flex justify-content-between align-items-center my-2"><h1 class="h4 mb-0">${esc(s.staff_name)} ${badge(s.is_active ? "Active" : "Inactive")}</h1><div class="d-flex gap-2">${s.is_active ? '<button class="btn btn-outline-primary" data-assign><i class="bi bi-person-plus"></i> Assign to event</button>' : ""}<button class="btn btn-primary" data-edit><i class="bi bi-pencil"></i> Edit</button></div></div>
        <div class="row g-3"><div class="col-lg-4"><div class="card"><div class="card-body"><dl class="dl-grid mb-0"><dt>Staff ID</dt><dd>#${s.staff_id}</dd><dt>Role</dt><dd>${esc(s.role)}</dd><dt>Contact</dt><dd>${esc(s.contact_no || "—")}</dd></dl></div></div></div>
        <div class="col-lg-8"><div class="card"><div class="card-header">Assigned events and tasks</div><div data-a></div></div></div></div>`;
      $("[data-edit]", view).onclick = () => staffForm(s, () => pageStaff(id));
      const as = $("[data-assign]", view); if (as) as.onclick = () => assignmentForm({ staff_id: s.staff_id }, () => pageStaff(id));
      dataTable($("[data-a]", view), { rows: s.assignments, empty: "No assignments", onRow: (r) => (location.hash = `#/events/${r.event_id}`), columns: [{ key: "event_type", label: "Event" }, { key: "event_date", label: "Date", render: (r) => `${fdate(r.event_date)} ${ftime(r.event_time)}` }, { key: "venue", label: "Venue" }, { key: "work_assigned", label: "Work assigned" }] });
    } catch (e) { view.innerHTML = errorBox(e); }
  }

  /* ------------ assignments ------------ */
  async function assignmentForm(values, reload) {
    let R; try { R = await refs("events", "staff"); } catch (e) { return showError(e); }
    const staff = R.staff.filter((s) => s.is_active || String(s.staff_id) === String(values?.staff_id));
    formModal({ title: values?.assignment_id ? "Edit assignment" : "Assign staff to event", values: values || {}, fields: [
      { name: "event_id", label: "Event", type: "select", required: true, options: R.events.map((e) => [e.event_id, `#${e.event_id} ${e.event_type} · ${fdate(e.event_date)} · ${e.customer_name}`]) },
      { name: "staff_id", label: "Staff member", type: "select", required: true, options: staff.map((s) => [s.staff_id, `${s.staff_name} (${s.role})`]) },
      { name: "work_assigned", label: "Work assigned", required: true, maxlength: 255, placeholderText: "e.g. Buffet service" },
    ], onSubmit: async (data) => { await api(values?.assignment_id ? "PUT" : "POST", values?.assignment_id ? `/assignments/${values.assignment_id}` : "/assignments", data); toast(values?.assignment_id ? "Assignment updated" : "Staff assigned"); reload(); } });
  }
  async function pageAssignments() {
    let R = { staff: [], events: [] }; try { R = await refs("staff", "events"); } catch {}
    let rowsCache = [];
    listPage.handlers.editAssign = (id, reload) => { const a = rowsCache.find((x) => String(x.assignment_id) === String(id)); assignmentForm(a, reload); };
    listPage.handlers.delAssign = async (id, reload) => { if (!(await confirmDialog("Remove this staff assignment?", { ok: "Remove" }))) return; try { await api("DELETE", `/assignments/${id}`); toast("Assignment removed"); reload(); } catch (e) { showError(e); } };
    const origApi = api;
    await listPage({ title: "Staff Assignments", endpoint: "/assignments", exportName: "staff-assignments", sort: ["event_date", "asc"],
      filters: [{ name: "q", label: "Search", placeholder: "Staff, task, venue", col: "col-12 col-md-3" }, { name: "event_id", label: "Event", type: "select", options: R.events.map((e) => [e.event_id, `#${e.event_id} ${e.event_type} ${fdate(e.event_date)}`]) }, { name: "staff_id", label: "Staff", type: "select", options: R.staff.map((s) => [s.staff_id, s.staff_name]) }, { name: "role", label: "Role", type: "select", options: STAFF_ROLES.map((r) => [r, r]) }, { name: "from", label: "From", type: "date" }, { name: "to", label: "To", type: "date" }],
      columns: [{ key: "assignment_id", label: "ID", render: (r) => { rowsCache.push(r); return `#${r.assignment_id}`; } }, { key: "staff_name", label: "Staff", render: (r) => `<a href="#/staff/${r.staff_id}">${esc(r.staff_name)}</a><div class="small text-muted">${esc(r.role)}</div>` }, { key: "event_type", label: "Event", render: (r) => `<a href="#/events/${r.event_id}">#${r.event_id} ${esc(r.event_type)}</a><div class="small text-muted">${esc(r.customer_name)}</div>` }, { key: "event_date", label: "Date", render: (r) => fdate(r.event_date) }, { key: "venue", label: "Venue" }, { key: "work_assigned", label: "Work assigned" }],
      addLabel: "Assign staff", onAdd: (reload) => assignmentForm(null, reload),
      actions: (r) => actBtn("editAssign", r.assignment_id, "pencil", "Edit") + actBtn("delAssign", r.assignment_id, "trash", "Remove", "btn-outline-danger") });
    void origApi;
  }

  /* ------------ payments ------------ */
  async function paymentForm(values, reload) {
    let bookings; try { bookings = await api("GET", "/bookings?outstanding=1"); } catch (e) { return showError(e); }
    if (!bookings.length) return toast("There are no bookings with an outstanding balance.", "warning");
    const fields = [
      { name: "booking_id", label: "Booking", type: "select", required: true, options: bookings.map((b) => [b.booking_id, `#${b.booking_id} · ${b.customer_name} · balance ${money(b.balance)}`]) },
      { name: "amount", label: "Amount received (₹)", type: "number", step: "0.01", min: 0.01, required: true, col: "col-md-6" },
      { name: "payment_date", label: "Payment date", type: "date", required: true, col: "col-md-6", default: today() },
      { name: "payment_mode", label: "Mode", type: "select", required: true, col: "col-md-6", placeholder: false, options: ["Cash", "UPI", "Bank Transfer", "Cheque", "Card"].map((m) => [m, m]) },
      { name: "reference_note", label: "Reference / note", col: "col-md-6", maxlength: 255 },
    ];
    const { form } = formModal({ title: "Record payment", values: values || {}, fields, submitLabel: "Save payment", onSubmit: async (data) => { const r = await api("POST", "/payments", data); toast(`Payment #${r.payment_id} recorded. Status: ${r.booking.payment_status}`); refreshNotifications(); reload(r); } });
    const hint = document.createElement("div"); hint.className = "col-12 small text-muted"; form.querySelector(".row").appendChild(hint);
    const upd = () => { const b = bookings.find((x) => String(x.booking_id) === form.elements.booking_id.value); hint.innerHTML = b ? `Total ${money(b.total_amount)} · received ${money(b.amount_paid)} · <strong>outstanding ${money(b.balance)}</strong>. Amount cannot exceed the outstanding balance.` : ""; };
    form.elements.booking_id.onchange = upd; upd();
  }
  async function pagePayments(params) {
    await listPage({ title: "Payments", endpoint: "/payments", exportName: "payments", sort: ["payment_id", "desc"],
      filters: [{ name: "q", label: "Search", placeholder: "Payment ID, booking ID, customer", col: "col-12 col-md-4" }, { name: "payment_status", label: "Booking payment status", type: "select", options: PAY_STATUSES.map((s) => [s, s]) }, { name: "from", label: "From", type: "date" }, { name: "to", label: "To", type: "date" }],
      extraHeader: '<a class="btn btn-outline-primary" href="#/bookings?payment_status=Unpaid">Unpaid bookings</a><a class="btn btn-outline-primary" href="#/bookings?payment_status=Partially Paid">Partially paid</a>',
      columns: [{ key: "payment_id", label: "Receipt", render: (r) => `<span class="fw-semibold">#${r.payment_id}</span>` }, { key: "booking_id", label: "Booking", render: (r) => `<a href="#/bookings/${r.booking_id}">#${r.booking_id}</a>` }, { key: "customer_name", label: "Customer" }, { key: "payment_date", label: "Date", render: (r) => fdate(r.payment_date) }, { key: "payment_mode", label: "Mode" },
        { key: "total_amount", label: "Booking total", align: "end", render: (r) => money(r.total_amount) }, { key: "advance_payment", label: "Received", align: "end", render: (r) => `<span class="fw-semibold">${money(r.advance_payment)}</span>` }, { key: "remaining_balance", label: "Balance after", align: "end", render: (r) => money(r.remaining_balance) }, { key: "booking_payment_status", label: "Current status", render: (r) => badge(r.booking_payment_status) }],
      onRow: (r) => (location.hash = `#/payments/${r.payment_id}`), addLabel: "Record payment", onAdd: (reload) => paymentForm(null, reload) });
    if (params.get("add")) paymentForm(null, (r) => (location.hash = `#/payments/${r.payment_id}`));
  }
  async function pagePayment(id) {
    setPage(`Receipt #${id}`, ["Payments", `#${id}`]);
    const view = $("#view"); view.innerHTML = loading();
    try {
      const p = await api("GET", `/payments/${id}`);
      const s = p.business, b = p.booking;
      view.innerHTML = `<div class="d-flex justify-content-between align-items-center mb-3 no-print"><a href="#/payments" class="small"><i class="bi bi-arrow-left"></i> Payments</a><button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer"></i> Print receipt</button></div>
      <div class="card mx-auto" style="max-width:720px"><div class="card-body p-4 p-md-5">
        <div class="d-flex justify-content-between border-bottom pb-3 mb-3"><div><h2 class="h5 mb-1 text-primary">${esc(s.business_name)}</h2><div class="small text-muted">${esc(s.business_address)}<br>${esc(s.business_phone)} · ${esc(s.business_email)}</div></div><div class="text-end"><div class="text-uppercase small text-muted fw-semibold">Payment receipt</div><div class="fs-5 fw-bold">#${p.payment_id}</div><div class="small">${fdate(p.payment_date)}</div></div></div>
        <dl class="dl-grid mb-4"><dt>Received from</dt><dd>${esc(b.customer_name)} (${esc(b.contact_no)})</dd><dt>Booking</dt><dd>#${b.booking_id} · ${esc(b.event_type)} on ${fdate(b.event_date)}</dd><dt>Venue</dt><dd>${esc(b.venue)}</dd><dt>Menu / guests</dt><dd>${esc(b.menu_name_snapshot)} · ${b.guest_count} guests</dd><dt>Payment mode</dt><dd>${esc(p.payment_mode)}${p.reference_note ? ` · ${esc(p.reference_note)}` : ""}</dd></dl>
        <table class="table table-sm"><tbody><tr><td>Total booking amount</td><td class="text-end">${money(p.total_amount)}</td></tr><tr class="fw-bold"><td>Amount received in this receipt</td><td class="text-end text-primary">${money(p.advance_payment)}</td></tr><tr><td>Total received up to this receipt</td><td class="text-end">${money(p.received_to_date)}</td></tr><tr><td>Balance after this receipt</td><td class="text-end">${money(p.remaining_balance)}</td></tr><tr><td>Payment status at this receipt</td><td class="text-end">${badge(p.payment_status)}</td></tr></tbody></table>
        <p class="small text-muted mt-4 mb-0">This receipt records a payment entered into CaterEase. It does not represent an electronic funds transfer. Current outstanding balance for the booking: ${money(b.balance)}.</p>
      </div></div>`;
    } catch (e) { view.innerHTML = errorBox(e); }
  }

  /* ------------ feedback ------------ */
  async function feedbackForm(values, reload) {
    let bookings; try { bookings = (await api("GET", "/bookings")).filter((b) => b.booking_status !== "Cancelled"); } catch (e) { return showError(e); }
    formModal({ title: values?.feedback_id ? "Edit feedback" : "Add feedback", values: values || {}, fields: [
      { name: "booking_id", label: "Booking", type: "select", required: true, options: bookings.map((b) => [b.booking_id, `#${b.booking_id} · ${b.customer_name} · ${b.event_type}`]), help: "Feedback is linked to the customer of the selected booking." },
      { name: "rating", label: "Rating", type: "select", required: true, options: [5, 4, 3, 2, 1].map((n) => [n, "★".repeat(n) + "☆".repeat(5 - n) + ` (${n})`]) },
      { name: "comments", label: "Comments", type: "textarea", rows: 3, max: 1000 },
    ], onSubmit: async (data) => { await api(values?.feedback_id ? "PUT" : "POST", values?.feedback_id ? `/feedback/${values.feedback_id}` : "/feedback", data); toast("Feedback saved"); reload(); } });
  }
  async function pageFeedback() {
    let cache = {};
    listPage.handlers.editFb = (id, reload) => feedbackForm(cache[id], reload);
    listPage.handlers.delFb = async (id, reload) => { if (!(await confirmDialog("Delete this feedback?", { ok: "Delete" }))) return; try { await api("DELETE", `/feedback/${id}`); toast("Feedback deleted"); reload(); } catch (e) { showError(e); } };
    await listPage({ title: "Feedback", endpoint: "/feedback", exportName: "feedback", sort: ["feedback_id", "desc"],
      filters: [{ name: "q", label: "Search", placeholder: "Customer, comment, booking ID", col: "col-12 col-md-4" }, { name: "rating", label: "Rating", type: "select", options: [5, 4, 3, 2, 1].map((n) => [n, `${n} star${n > 1 ? "s" : ""}`]) }, { name: "booking_id", label: "Booking ID", type: "number" }],
      columns: [{ key: "feedback_id", label: "ID", render: (r) => { cache[r.feedback_id] = r; return `#${r.feedback_id}`; } }, { key: "booking_id", label: "Booking", render: (r) => `<a href="#/bookings/${r.booking_id}">#${r.booking_id}</a>` }, { key: "customer_name", label: "Customer" }, { key: "event_type", label: "Event" }, { key: "rating", label: "Rating", render: (r) => stars(r.rating) }, { key: "comments", label: "Comments" }],
      addLabel: "Add feedback", onAdd: (reload) => feedbackForm(null, reload),
      actions: (r) => actBtn("editFb", r.feedback_id, "pencil", "Edit") + actBtn("delFb", r.feedback_id, "trash", "Delete", "btn-outline-danger") });
  }

  /* ------------ reports ------------ */
  async function pageReports(params) {
    setPage("Reports", ["Reports"]);
    const view = $("#view");
    let R = { customers: [], menus: [] }; try { R = await refs("customers", "menus"); } catch {}
    const types = [["booking", "Booking"], ["order", "Order"], ["payment", "Payment"], ["revenue", "Revenue"], ["customer", "Customer"], ["event", "Event"]];
    let type = params.get("type") || "booking";
    view.innerHTML = `<h1 class="h4 mb-3 no-print">Reports</h1>
      <ul class="nav nav-pills mb-3 no-print">${types.map(([k, l]) => `<li class="nav-item"><a class="nav-link ${k === type ? "active" : ""}" href="#/reports?type=${k}">${l} report</a></li>`).join("")}</ul>
      <div class="card mb-3 no-print"><form class="card-body row g-2 align-items-end" id="repForm">
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_from">From</label><input type="date" class="form-control form-control-sm" id="r_from" name="from"></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_to">To</label><input type="date" class="form-control form-control-sm" id="r_to" name="to"></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_status">Booking status</label><select class="form-select form-select-sm" id="r_status" name="status"><option value="">All</option>${STATUSES.map((s) => `<option>${s}</option>`).join("")}</select></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_pay">Payment status</label><select class="form-select form-select-sm" id="r_pay" name="payment_status"><option value="">All</option>${PAY_STATUSES.map((s) => `<option>${s}</option>`).join("")}</select></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_type">Event type</label><select class="form-select form-select-sm" id="r_type" name="event_type"><option value="">All</option>${EVENT_TYPES.map((s) => `<option>${s}</option>`).join("")}</select></div>
        <div class="col-6 col-md-2"><label class="form-label small mb-1" for="r_cust">Customer</label><select class="form-select form-select-sm" id="r_cust" name="customer_id"><option value="">All</option>${R.customers.map((c) => `<option value="${c.customer_id}">${esc(c.name)}</option>`).join("")}</select></div>
        <div class="col-6 col-md-3"><label class="form-label small mb-1" for="r_menu">Menu / package</label><select class="form-select form-select-sm" id="r_menu" name="menu_id"><option value="">All</option>${R.menus.map((m) => `<option value="${m.menu_id}">${esc(m.menu_name)}</option>`).join("")}</select></div>
        <div class="col-auto"><button class="btn btn-primary btn-sm" type="submit"><i class="bi bi-funnel"></i> Generate</button></div>
        <div class="col-auto ms-auto d-flex gap-2"><button type="button" class="btn btn-sm btn-outline-secondary" data-pdf disabled><i class="bi bi-file-earmark-pdf"></i> PDF</button><button type="button" class="btn btn-sm btn-outline-secondary" data-xlsx disabled><i class="bi bi-file-earmark-excel"></i> Excel</button><button type="button" class="btn btn-sm btn-outline-secondary" data-print disabled><i class="bi bi-printer"></i> Print</button></div>
      </form></div>
      <div id="repOut"></div>`;
    const form = $("#repForm"), out = $("#repOut");
    let rep, filtersText;
    const filterLabels = { from: "From", to: "To", status: "Booking status", payment_status: "Payment status", event_type: "Event type", customer_id: "Customer", menu_id: "Menu" };
    async function run() {
      const q = Object.fromEntries(new FormData(form));
      if (q.from && q.to && q.from > q.to) return toast("'From' date must be before 'To' date", "error");
      filtersText = Object.entries(q).filter(([, v]) => v).map(([k, v]) => `${filterLabels[k]}: ${k === "customer_id" ? R.customers.find((c) => String(c.customer_id) === v)?.name : k === "menu_id" ? R.menus.find((m) => String(m.menu_id) === v)?.menu_name : /from|to/.test(k) ? fdate(v) : v}`).join("; ") || "None (all records)";
      out.innerHTML = loading();
      try {
        rep = await api("GET", `/reports/${type}` + qs(q));
        const s = state.settings || {};
        out.innerHTML = `<div class="card"><div class="card-body border-bottom"><div class="print-only"><h2 class="h5 mb-0">${esc(s.business_name)}</h2></div><h2 class="h5 mb-1">${esc(rep.title)}</h2><div class="small text-muted">Generated ${new Date().toLocaleString("en-IN")} · Date basis: ${esc(rep.date_basis)} · Filters: ${esc(filtersText)}</div>
          <div class="d-flex flex-wrap gap-4 mt-3">${rep.summary.map((x) => `<div><div class="small text-muted">${esc(x[0])}</div><div class="fw-bold fs-6">${x[2] === "money" ? money(x[1]) : esc(x[1])}</div></div>`).join("")}</div></div><div data-t></div></div>`;
        dataTable($("[data-t]", out), { rows: rep.rows, pageSize: 25, empty: "No records match these filters", columns: rep.columns.map(([k, l, kind]) => ({ key: k, label: l, align: kind === "money" ? "end" : undefined, render: (r) => kind === "money" ? money(r[k]).replace("₹", "") : /status/.test(k) ? badge(r[k]) : /date/.test(k) ? fdate(r[k]) : k === "event_time" ? ftime(r[k]) : esc(r[k] ?? "—") })) });
        ["[data-pdf]", "[data-xlsx]", "[data-print]"].forEach((s2) => ($(s2, form).disabled = !rep.rows.length));
      } catch (e) { out.innerHTML = errorBox(e); }
    }
    form.onsubmit = (e) => { e.preventDefault(); run(); };
    $("[data-pdf]", form).onclick = () => exportPdf(rep, filtersText);
    $("[data-xlsx]", form).onclick = () => exportXlsx(rep.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase(), rep.columns, rep.rows, { title: rep.title, filters: filtersText, summary: rep.summary });
    $("[data-print]", form).onclick = () => window.print();
    run();
  }

  /* ------------ settings ------------ */
  async function pageSettings() {
    setPage("Settings", ["Settings"]);
    const view = $("#view"); view.innerHTML = loading();
    let s, users = [];
    try { [s, users] = await Promise.all([api("GET", "/settings"), api("GET", "/users")]); } catch (e) { view.innerHTML = errorBox(e); return; }
    const isAdmin = state.user.role === "admin";
    const fields = [
      { name: "business_name", label: "Business name", required: true, col: "col-md-6" }, { name: "business_phone", label: "Phone", col: "col-md-6" },
      { name: "business_email", label: "Email", col: "col-md-6" }, { name: "business_address", label: "Address", col: "col-md-6" },
      { name: "city", label: "City", col: "col-md-6" }, { name: "state", label: "State", col: "col-md-6" },
      { name: "business_type", label: "Business type", col: "col-md-6" }, { name: "gst_number", label: "GST number", col: "col-md-6" },
      { name: "currency_symbol", label: "Currency display", col: "col-md-3", type: "select", placeholder: false, options: [["₹", "₹ Indian Rupee"]] },
      { name: "pricing_model", label: "Booking pricing model", col: "col-md-5", type: "select", placeholder: false, options: [["per_person", "Per person (menu price × guests)"], ["fixed", "Fixed package price"]], help: "Applies to new bookings. Existing bookings keep the model they were created with." },
      { name: "contact_pattern", label: "Contact number validation rule (regular expression)", col: "col-md-4" },
      { name: "report_footer", label: "Report footer text", col: "col-12" },
    ];
    view.innerHTML = `<h1 class="h4 mb-3">Settings</h1><div class="row g-3"><div class="col-lg-8"><div class="card"><div class="card-header">Business & application settings</div><form class="card-body" novalidate id="setForm"><div class="alert alert-danger d-none" data-form-error></div><div class="row g-3">${fields.map((f) => fieldHtml(f, s[f.name])).join("")}</div>${isAdmin ? '<button class="btn btn-primary mt-3" type="submit">Save settings</button>' : '<p class="small text-muted mt-3 mb-0">Only administrators can change settings.</p>'}</form></div></div>
      <div class="col-lg-4"><div class="card mb-3"><div class="card-header">Change password</div><form class="card-body" novalidate id="pwForm"><div class="alert alert-danger d-none" data-form-error></div><div class="row g-2">${fieldHtml({ name: "current_password", label: "Current password", type: "password", required: true })}${fieldHtml({ name: "new_password", label: "New password", type: "password", required: true, help: "At least 8 characters with letters and numbers." })}</div><button class="btn btn-outline-primary mt-3" type="submit">Update password</button></form></div>
      <div class="card"><div class="card-header d-flex justify-content-between align-items-center">Manager accounts ${isAdmin ? '<button class="btn btn-sm btn-light" data-adduser><i class="bi bi-plus"></i> Add</button>' : ""}</div><ul class="list-group list-group-flush">${users.map((u) => `<li class="list-group-item d-flex justify-content-between"><span>${esc(u.full_name)} <span class="text-muted small">@${esc(u.username)}</span></span><span class="badge text-bg-light border">${esc(u.role)}</span></li>`).join("")}</ul></div></div></div>`;
    const sf = $("#setForm");
    sf.onsubmit = async (e) => { e.preventDefault(); const data = readForm(sf, fields); if (!clientValidate(sf, fields, data)) return; try { state.settings = await api("PUT", "/settings", data); toast("Settings saved"); showFieldErrors(sf, {}); $("[data-form-error]", sf).classList.add("d-none"); } catch (err) { showFieldErrors(sf, err.errors); const a = $("[data-form-error]", sf); a.textContent = err.message; a.classList.remove("d-none"); } };
    const pf = $("#pwForm");
    pf.onsubmit = async (e) => { e.preventDefault(); const f = [{ name: "current_password", label: "Current password", required: true }, { name: "new_password", label: "New password", required: true }]; const data = readForm(pf, f); if (!clientValidate(pf, f, data)) return; try { await api("POST", "/auth/change-password", data); toast("Password updated"); pf.reset(); $("[data-form-error]", pf).classList.add("d-none"); } catch (err) { showFieldErrors(pf, err.errors); const a = $("[data-form-error]", pf); a.textContent = err.message; a.classList.remove("d-none"); } };
    const au = $("[data-adduser]", view);
    if (au) au.onclick = () => formModal({ title: "Add manager account", fields: [{ name: "full_name", label: "Full name", required: true }, { name: "username", label: "Username", required: true }, { name: "email", label: "Email address", type: "email", required: true }, { name: "password", label: "Temporary password", type: "password", required: true }], onSubmit: async (data) => { await api("POST", "/users", data); toast("Manager account created"); pageSettings(); } });
  }

  /* ------------ router ------------ */
  async function route() {
    if (!state.user) return;
    const [path, query] = (location.hash.slice(1) || "/dashboard").split("?");
    const params = new URLSearchParams(query || "");
    const parts = path.split("/").filter(Boolean);
    const [section, id] = parts;
    $$("[data-nav]").forEach((a) => a.classList.toggle("active", a.dataset.nav === section));
    document.body.classList.remove("sidebar-open");
    state.charts.forEach((ch) => ch.destroy()); state.charts = [];
    window.scrollTo(0, 0);
    const pages = {
      dashboard: () => pageDashboard(), customers: () => (id ? pageCustomer(id) : pageCustomers(params)), events: () => (id ? pageEvent(id) : pageEvents(params)),
      menus: () => (id ? pageMenu(id) : pageMenus(params)), bookings: () => (id === "new" ? pageBookingNew(params) : id ? pageBooking(id, params) : pageBookings(params)),
      guests: () => pageGuests(), staff: () => (id ? pageStaff(id) : pageStaffList()), assignments: () => pageAssignments(),
      payments: () => (id ? pagePayment(id) : pagePayments(params)), feedback: () => pageFeedback(), reports: () => pageReports(params), settings: () => pageSettings(),
    };
    try { await (pages[section] || pages.dashboard)(); } catch (e) { showError(e); }
  }

  async function boot() {
    if (!token.get()) return renderLogin();
    try {
      state.user = await api("GET", "/auth/me");
      if (state.user.details_complete === false) { location.assign("details.html"); return; }
      state.settings = await api("GET", "/settings");
    } catch (e) { token.clear(); return renderLogin(e.status === 0 ? e.message : undefined); }
    shell();
    route();
  }
  window.addEventListener("hashchange", route);
  boot();
})();
