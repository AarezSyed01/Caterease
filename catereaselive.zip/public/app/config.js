// Base URL of the REST API. In the downloadable project the Express server serves this
// frontend and the API from the same origin, so this is "/api".
window.CMS_API_BASE = "/api/public";
