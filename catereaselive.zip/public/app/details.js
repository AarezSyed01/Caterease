/* CaterEase business details page: shown once after registration, before the dashboard. */
(function () {
  'use strict';
  const API = window.CMS_API_BASE || '/api';
  const token = sessionStorage.getItem('cms_token');
  if (!token) { location.assign('index.html'); return; }
  const form = document.getElementById('detailsForm');
  const error = document.getElementById('detailsError');
  const required = ['business_name','mobile','address','city','state'];
  const fields = [...required,'business_type','gst_number'];

  async function api(method, path, body) {
    const response = await fetch(API + path, {
      method,
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: body ? JSON.stringify(body) : undefined,
    });
    const json = await response.json().catch(() => ({ success: false, message: 'Cannot reach the server. Please try again.' }));
    if (response.status === 401) { sessionStorage.removeItem('cms_token'); location.assign('index.html'); throw new Error('signed out'); }
    return json;
  }

  // Already-registered businesses skip this page and go straight to the dashboard.
  api('GET', '/auth/me').then(function (json) {
    if (json.success && json.data.details_complete !== false) location.assign('index.html#/dashboard');
  }).catch(function () {});

  function errors(messages) {
    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    form.querySelectorAll('[data-err]').forEach(el => el.textContent = '');
    Object.entries(messages || {}).forEach(([key,message]) => {
      const input = form.elements[key];
      if (input) input.classList.add('is-invalid');
      const label = form.querySelector('[data-err="'+key+'"]');
      if (label) label.textContent = message;
    });
  }
  form.onsubmit = async function (event) {
    event.preventDefault(); error.classList.add('d-none');
    const data = Object.fromEntries(fields.map(key => [key, form.elements[key].value.trim()]));
    const invalid = {};
    required.forEach(key => { if (!data[key]) invalid[key] = 'Required'; });
    if (data.mobile && !/^(\+91[- ]?)?[6-9][0-9]{9}$/.test(data.mobile)) invalid.mobile = 'Enter a valid Indian mobile number';
    if (data.gst_number && !/^[0-9A-Za-z]{15}$/.test(data.gst_number)) invalid.gst_number = 'Enter a 15-character GST number';
    errors(invalid);
    if (Object.keys(invalid).length) { form.querySelector('.is-invalid')?.focus(); return; }
    const submit = form.querySelector('[type=submit]'), spinner = submit.querySelector('.spinner-border');
    submit.disabled = true; submit.setAttribute('aria-busy','true'); spinner.classList.remove('d-none');
    try {
      const json = await api('PUT', '/business/details', data);
      if (!json.success) { errors(json.errors); throw new Error(json.message || 'Could not save. Please try again.'); }
      location.assign('index.html#/dashboard');
    } catch (err) {
      if (err.message !== 'signed out') { error.textContent = err.message; error.classList.remove('d-none'); }
    } finally { submit.disabled = false; submit.removeAttribute('aria-busy'); spinner.classList.add('d-none'); }
  };
})();
