/* Customer-facing inquiry and booking-status page */
(function () {
  "use strict";
  const API = window.CMS_API_BASE || "/api";
  const businessId = new URLSearchParams(location.search).get('business_id');
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (v) => "₹" + Number(v || 0).toLocaleString("en-IN", { minimumFractionDigits: 2 });
  const fdate = (d) => (d ? String(d).slice(0, 10).split("-").reverse().join("-") : "—");
  const requestKey = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));
  let info = { menus: [] };

  async function call(method, path, body) {
    let res, json;
    const scopedPath = path + (businessId ? '?business_id=' + encodeURIComponent(businessId) : '');
    try { res = await fetch(API + scopedPath, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined }); json = await res.json(); }
    catch { throw new Error("Cannot reach the server right now. Please try again later."); }
    if (!json.success) throw Object.assign(new Error(json.message), { errors: json.errors });
    return json.data;
  }
  function showErrors(form, errs = {}) {
    form.querySelectorAll(".is-invalid").forEach((e) => e.classList.remove("is-invalid"));
    form.querySelectorAll("[data-err]").forEach((e) => (e.textContent = ""));
    Object.entries(errs).forEach(([k, m]) => { const el = form.elements[k]; if (el) el.classList.add("is-invalid"); const fb = form.querySelector(`[data-err="${k}"]`); if (fb) fb.textContent = m; });
  }

  const form = document.getElementById("inqForm");
  document.getElementById("event_date").min = new Date().toISOString().slice(0, 10);
  const estimate = () => {
    const m = info.menus.find((x) => String(x.menu_id) === form.elements.menu_id.value), g = parseInt(form.elements.guest_count.value, 10);
    document.getElementById("estimate").textContent = m && g > 0 ? money(info.pricing_model === "fixed" ? m.price : (Math.round(m.price * 100) * g) / 100) : "—";
  };
  form.oninput = estimate;

  call("GET", "/public/info").then((d) => {
    info = d;
    form.elements.menu_id.innerHTML = '<option value="">Select…</option>' + d.menus.map((m) => `<option value="${m.menu_id}">${esc(m.menu_name)} (${esc(m.category)}) — ${money(m.price)}${d.pricing_model === "fixed" ? "" : " per person"}</option>`).join("");
  }).catch((e) => { form.querySelector("[data-form-error]").textContent = e.message; form.querySelector("[data-form-error]").classList.remove("d-none"); });

  form.onsubmit = async (e) => {
    e.preventDefault();
    const f = form.elements, errs = {};
    ["name", "contact_no", "event_type", "event_date", "event_time", "venue", "menu_id", "guest_count"].forEach((k) => { if (!f[k].value.trim()) errs[k] = "Required"; });
    if (f.guest_count.value && !(parseInt(f.guest_count.value, 10) > 0)) errs.guest_count = "Enter a positive number";
    showErrors(form, errs);
    if (Object.keys(errs).length) return;
    const btn = form.querySelector("[type=submit]"), alertEl = form.querySelector("[data-form-error]");
    btn.disabled = true; alertEl.classList.add("d-none");
    try {
      const r = await call("POST", "/public/inquiries", {
        website: f.website.value, request_key: requestKey,
        customer: { name: f.name.value, contact_no: f.contact_no.value, address: f.address.value },
        event: { event_type: f.event_type.value, event_date: f.event_date.value, event_time: f.event_time.value, venue: f.venue.value },
        menu_id: f.menu_id.value, guest_count: f.guest_count.value, notes: f.notes.value,
      });
      form.classList.add("d-none");
      document.getElementById("inqResult").innerHTML = `<div class="alert alert-success"><h2 class="h5"><i class="bi bi-check-circle"></i> Inquiry received</h2><p class="mb-1">Your reference number is <strong>#${r.reference}</strong> (status: <strong>${esc(r.status)}</strong>). Estimated amount: <strong>${money(r.estimated_total)}</strong>.</p><p class="mb-0 small">${esc(r.message)} Use “Check my booking” with this reference and your mobile number to see updates.</p></div>`;
    } catch (err) {
      const map = { name: "name", contact_no: "contact_no", event_type: "event_type", event_date: "event_date", event_time: "event_time", venue: "venue", menu_id: "menu_id", guest_count: "guest_count" };
      const fe = {}; Object.entries(err.errors || {}).forEach(([k, v]) => { if (map[k]) fe[map[k]] = v; });
      showErrors(form, fe);
      alertEl.textContent = err.message; alertEl.classList.remove("d-none");
    } finally { btn.disabled = false; }
  };

  const st = document.getElementById("stForm");
  st.onsubmit = async (e) => {
    e.preventDefault();
    const out = document.getElementById("stResult");
    if (!st.elements.booking_id.value || !st.elements.contact_no.value) { out.innerHTML = '<div class="alert alert-warning">Enter both fields.</div>'; return; }
    out.innerHTML = '<div class="spinner-border text-primary"></div>';
    try {
      const b = await call("POST", "/public/booking-status", { booking_id: st.elements.booking_id.value, contact_no: st.elements.contact_no.value });
      out.innerHTML = `<div class="border rounded p-3"><div class="d-flex justify-content-between flex-wrap gap-2"><h2 class="h5 mb-0">Booking #${b.booking_id}</h2><div><span class="badge st-${b.booking_status.replace(/\s/g, "")}">${esc(b.booking_status)}</span> <span class="badge st-${b.payment_status.replace(/\s/g, "")}">${esc(b.payment_status)}</span></div></div>
        <p class="small mt-2 mb-3">${b.confirmed ? "Your booking is confirmed." : b.booking_status === "Cancelled" ? "This booking has been cancelled." : "Your booking is awaiting confirmation by our manager."}</p>
        <dl class="dl-grid small"><dt>Name</dt><dd>${esc(b.customer_name)}</dd><dt>Event</dt><dd>${esc(b.event_type)} on ${fdate(b.event_date)} at ${esc(b.event_time)}</dd><dt>Venue</dt><dd>${esc(b.venue)}</dd><dt>Menu</dt><dd>${esc(b.menu)} · ${b.guest_count} guests</dd><dt>Total</dt><dd>${money(b.total_amount)}</dd><dt>Paid</dt><dd>${money(b.amount_paid)}</dd><dt>Balance</dt><dd>${money(b.balance)}</dd></dl>
        ${b.payments.length ? `<h3 class="h6 mt-3">Payment receipts</h3><table class="table table-sm"><thead><tr><th>Receipt</th><th>Date</th><th>Mode</th><th class="text-end">Amount</th><th class="text-end">Balance after</th></tr></thead><tbody>${b.payments.map((p) => `<tr><td>#${p.payment_id}</td><td>${fdate(p.payment_date)}</td><td>${esc(p.payment_mode)}</td><td class="text-end">${money(p.amount)}</td><td class="text-end">${money(p.remaining_balance)}</td></tr>`).join("")}</tbody></table><button class="btn btn-sm btn-light" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>` : ""}</div>`;
    } catch (err) { out.innerHTML = `<div class="alert alert-danger">${esc(err.message)}</div>`; }
  };
})();
