/* CaterEase account registration: name, email and password only.
   Business details are collected on details.html right after registration. */
(function () {
  'use strict';
  const form = document.getElementById('registerForm');
  const error = document.getElementById('registerError');
  const required = ['full_name','email','password','confirm_password'];
  function errors(messages) {
    form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
    form.querySelectorAll('[data-err]').forEach(el => el.textContent = '');
    Object.entries(messages || {}).forEach(([key,message]) => {
      const input = form.elements[key];
      if (input) input.classList.add('is-invalid');
      const label = form.querySelector('[data-err="'+key+'"]');
      if (label) label.textContent = message;
    });
  }
  form.onsubmit = async function (event) {
    event.preventDefault(); error.classList.add('d-none');
    const data = Object.fromEntries(required.map(key => [key,key.includes('password') ? form.elements[key].value : form.elements[key].value.trim()]));
    const invalid = {};
    required.forEach(key => { if (!data[key]) invalid[key] = 'Required'; });
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) invalid.email = 'Enter a valid email address';
    if (data.password && (data.password.length < 8 || !/[A-Za-z]/.test(data.password) || !/\d/.test(data.password))) invalid.password = 'Use at least 8 characters with letters and numbers';
    if (data.password !== data.confirm_password) invalid.confirm_password = 'Passwords must match';
    errors(invalid);
    if (Object.keys(invalid).length) { form.querySelector('.is-invalid')?.focus(); return; }
    const submit = form.querySelector('[type=submit]'), spinner = submit.querySelector('.spinner-border');
    submit.disabled = true; submit.setAttribute('aria-busy','true'); spinner.classList.remove('d-none');
    try {
      const response = await fetch((window.CMS_API_BASE || '/api')+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
      const json = await response.json();
      if (!json.success) {
        errors(json.errors);
        throw new Error(response.status === 409 ? 'This email is already registered. Please sign in.' : json.message || 'Registration failed. Please try again.');
      }
      sessionStorage.setItem('cms_token',json.data.token);
      location.assign('details.html');
    } catch (err) {
      error.textContent = err instanceof TypeError ? 'Cannot reach the server. Please try again.' : err.message;
      error.classList.remove('d-none');
    } finally { submit.disabled = false; submit.removeAttribute('aria-busy'); spinner.classList.add('d-none'); }
  };
})();
