// Authentication: bcrypt password hashes + signed JWT bearer tokens.
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { HttpError, bad, str, validate } from "./util.js";
import { LEGACY_BUSINESS } from "./tenant.js";

const key = (secret) => {
  if (!secret || secret.length < 16) throw new HttpError(500, "Server authentication secret is not configured");
  return new TextEncoder().encode(secret);
};
const publicUser = (u) => ({ user_id: u.user_id, username: u.username, email: u.email, full_name: u.full_name, role: u.role, business_id: u.business_id });

async function membership(db,u) {
  const r = (await db.all('business_roles',{ user_id:u.user_id, business_id:u.business_id }))[0];
  if (!r) throw new HttpError(403,'Business membership is missing');
  return { ...u, role:r.role === 'owner' ? 'admin' : r.role };
}

async function issue(user, secret) {
  const token = await new SignJWT({ username: user.username, role: user.role })
    .setProtectedHeader({ alg: "HS256" }).setSubject(String(user.user_id)).setIssuedAt().setExpirationTime("8h").sign(key(secret));
  return { token, user: publicUser(user) };
}

export async function authStatus(db) {
  return { needs_setup: (await db.all("users")).length === 0 };
}

function passwordRules(password) {
  return !password || password.length < 8 ? "At least 8 characters" : !/[A-Za-z]/.test(password) || !/\d/.test(password) ? "Use letters and numbers" : null;
}

/** First-run setup: only allowed while no user exists (and, if configured, with the setup key). */
export async function setupAdmin(db, body, env) {
  if ((await db.all("users")).length) throw new HttpError(403, "An administrator already exists. Please sign in.");
  if (env.ADMIN_SETUP_KEY && body.setup_key !== env.ADMIN_SETUP_KEY) throw new HttpError(403, "Invalid setup key", { setup_key: "Invalid setup key" });
  const username = str(body.username).toLowerCase(), full_name = str(body.full_name), password = String(body.password || "");
  validate([
    ["username", !/^[a-z0-9_.]{3,50}$/.test(username) ? "3-50 letters, numbers, dot or underscore" : null],
    ["full_name", !full_name ? "Name is required" : null],
    ["password", passwordRules(password)],
  ]);
  key(env.JWT_SECRET);
  const hash = await bcrypt.hash(password,10);
  if (db.setupAdmin) return issue(await db.setupAdmin({username,full_name},hash),env.JWT_SECRET);
  const user = await db.insert("users", { username, full_name, password_hash: hash, business_id: LEGACY_BUSINESS });
  await db.insert('business_roles',{user_id:user.user_id,business_id:user.business_id,role:'admin'});
  return issue(await membership(db,user), env.JWT_SECRET);
}

export async function login(db, body, env) {
  const identifier = str(body.email || body.username).toLowerCase(), password = String(body.password || "");
  if (!identifier || !password) throw bad("Email address or username and password are required");
  const user = (await db.all("users", identifier.includes('@') ? {email:identifier} : {username:identifier}))[0];
  const ok = user ? await bcrypt.compare(password, user.password_hash) : await bcrypt.compare(password, "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinva");
  if (!user || !ok) throw new HttpError(401, "Invalid email, username or password");
  const member = await membership(db,user);
  const issued = await issue(member, env.JWT_SECRET);
  issued.user.details_complete = await detailsComplete(db, user.business_id);
  return issued;
}

export async function verifyRequest(db, authHeader, env) {
  const m = /^Bearer (.+)$/.exec(authHeader || "");
  if (!m) throw new HttpError(401, "Please sign in");
  let payload;
  try { ({ payload } = await jwtVerify(m[1], key(env.JWT_SECRET))); } catch { throw new HttpError(401, "Session expired. Please sign in again."); }
  const user = await db.get("users", Number(payload.sub));
  if (!user) throw new HttpError(401, "Account no longer exists");
  const member = publicUser(await membership(db,user));
  member.details_complete = await detailsComplete(db, user.business_id);
  return member;
}

export async function changePassword(db, user, body) {
  const u = await db.get("users", user.user_id);
  if (!(await bcrypt.compare(String(body.current_password || ""), u.password_hash))) throw bad("Current password is incorrect", { current_password: "Incorrect password" });
  validate([["new_password", passwordRules(String(body.new_password || ""))]]);
  await db.update("users", u.user_id, { password_hash: await bcrypt.hash(String(body.new_password), 10) });
  return { changed: true };
}

export async function createUser(db, body) {
  const username = str(body.username).toLowerCase(), full_name = str(body.full_name), password = String(body.password || ""), email = str(body.email).toLowerCase();
  validate([
    ["username", !/^[a-z0-9_.]{3,50}$/.test(username) ? "3-50 letters, numbers, dot or underscore" : null],
    ["full_name", !full_name ? "Name is required" : null],
    ["password", passwordRules(password)],
    ["email", email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? 'Enter a valid email' : null],
  ]);
  if ((await db.all("users", { username })).length) throw new HttpError(409, "Username already taken", { username: "Already taken" });
  const hash = await bcrypt.hash(password,10);
  if (db.createManager) return publicUser(await db.createManager({username,full_name,email},hash));
  return db.tx(async (t) => {
    const u = await t.insert("users", { username, full_name, email:email || null, password_hash:hash });
    await t.insert('business_roles',{user_id:u.user_id,role:'manager'});
    return publicUser({...u,role:'manager'});
  });
}
export const listUsers = async (db) => Promise.all((await db.all("users")).map(async (u) => publicUser(await membership(db,u))));

async function detailsComplete(db, businessId) {
  const row = (await db.all('business_settings', { business_id: businessId, setting_key: 'details_complete' }))[0];
  return row ? row.setting_value === 'true' : true;
}

export async function registerBusiness(db,body,env) {
  // Account-only registration: business details are collected on the details page afterwards.
  const data = { full_name: str(body.full_name), email: str(body.email).toLowerCase() };
  const password = String(body.password || '');
  validate([
    ['full_name', !data.full_name ? 'Required' : data.full_name.length > 100 ? 'Maximum 100 characters' : null],
    ['email', !data.email ? 'Required' : data.email.length > 254 ? 'Maximum 254 characters' : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email) ? 'Enter a valid email address' : null],
    ['password',passwordRules(password) || (password.length>72 ? 'Maximum 72 characters' : null)],
    ['confirm_password',password !== String(body.confirm_password || '') ? 'Passwords must match' : null],
  ]);
  // Validate server configuration before creating any durable account.
  key(env.JWT_SECRET);
  if ((await db.all('users',{email:data.email})).length || (await db.all('businesses',{email:data.email})).length) throw new HttpError(409,'This email is already registered',{email:'Already registered. Please sign in.'});
  const hash = await bcrypt.hash(password,10);
  // Placeholder business record; the details page replaces these values before the dashboard opens.
  const details = { business_name: `${data.full_name}'s Catering`, full_name: data.full_name, email: data.email, mobile: '', address: '', city: '', state: '', business_type: '', gst_number: '' };
  let u;
  if (db.registerBusiness) u = await db.registerBusiness(details,hash);
  else u = await db.tx(async t => {
    const b = await t.insert('businesses',{business_id:crypto.randomUUID(),business_name:details.business_name,owner_name:data.full_name,email:data.email,mobile:'',address:'',city:'',state:'',business_type:null,gst_number:null});
    const account = await t.insert('users',{username:'owner_'+b.business_id.replace(/-/g,''),email:data.email,full_name:data.full_name,password_hash:hash,business_id:b.business_id});
    await t.insert('business_roles',{user_id:account.user_id,business_id:b.business_id,role:'owner'});
    const settings = {business_name:details.business_name,business_email:data.email,business_phone:'',business_address:'',city:'',state:'',business_type:'',gst_number:'',details_complete:'false'};
    for (const [setting_key,setting_value] of Object.entries(settings)) await t.insert('business_settings',{business_id:b.business_id,setting_key,setting_value});
    return account;
  });
  const issued = await issue({...u,role:'admin'},env.JWT_SECRET);
  issued.user.details_complete = false;
  return issued;
}
