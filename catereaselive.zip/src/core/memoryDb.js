// In-memory adapter used by automated tests (same interface as the MySQL adapter).
import { PK } from "./util.js";

export function memoryDb(seed = {}) {
  const tables = {};
  const seq = {};
  for (const t of Object.keys(PK)) { tables[t] = (seed[t] || []).map((r) => ({ ...r })); seq[t] = Math.max(0, ...tables[t].map((r) => Number(r[PK[t]]) || 0)); }
  const db = {
    async all(t, where = {}) { return tables[t].filter((r) => Object.entries(where).every(([k, v]) => String(r[k]) === String(v))).map((r) => ({ ...r })); },
    async get(t, id) { const r = tables[t].find((x) => String(x[PK[t]]) === String(id)); return r ? { ...r } : null; },
    async insert(t, row) { const r = { ...row }; if (r[PK[t]] === undefined) r[PK[t]] = ++seq[t]; tables[t].push(r); return { ...r }; },
    async update(t, id, row) { const r = tables[t].find((x) => String(x[PK[t]]) === String(id)); Object.assign(r, row); return { ...r }; },
    async remove(t, id) { tables[t] = tables[t].filter((x) => String(x[PK[t]]) !== String(id)); },
    async tx(fn) { const snap = JSON.stringify(tables); try { return await fn(db); } catch (e) { Object.assign(tables, JSON.parse(snap)); throw e; } },
    tables,
  };
  return db;
}
