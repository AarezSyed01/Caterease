// REST route table shared by the Express app (backend/) and the preview server route.
import * as S from "./services.js";
import * as A from "./auth.js";
import { HttpError } from "./util.js";
import { tenantDb, publicBusinessDb } from "./tenant.js";

const crud = (base, list, get, create, update, remove) => [
  ["GET", `/${base}`, (c) => list(c.db, c.query)],
  ["GET", `/${base}/:id`, (c) => get(c.db, c.params.id)],
  ["POST", `/${base}`, (c) => create(c.db, c.body), 201],
  ["PUT", `/${base}/:id`, (c) => update(c.db, c.params.id, c.body)],
  ["DELETE", `/${base}/:id`, (c) => remove(c.db, c.params.id)],
];

const adminOnly = (c) => { if (c.user.role !== "admin") throw new HttpError(403, "Only administrators can do this"); };

// [method, path, handler, successStatus?, isPublic?]
export const routes = [
  // public
  ["GET", "/auth/status", (c) => A.authStatus(c.db), 200, true],
  ["POST", "/auth/setup", (c) => A.setupAdmin(c.db, c.body, c.env), 201, true],
  ["POST", "/auth/login", (c) => A.login(c.db, c.body, c.env), 200, true],
  ["POST", "/auth/register", (c) => A.registerBusiness(c.db,c.body,c.env), 201, true],
  ["GET", "/public/info", (c) => S.publicInfo(c.db), 200, true],
  ["POST", "/public/inquiries", (c) => S.submitInquiry(c.db, c.body), 201, true],
  ["POST", "/public/booking-status", (c) => S.publicBookingStatus(c.db, c.body), 200, true],
  // protected
  ["GET", "/auth/me", (c) => c.user],
  ["POST", "/auth/logout", () => ({ logged_out: true })],
  ["POST", "/auth/change-password", (c) => A.changePassword(c.db, c.user, c.body)],
  ["GET", "/users", (c) => A.listUsers(c.db)],
  ["POST", "/users", (c) => { adminOnly(c); return A.createUser(c.db, c.body); }, 201],
  ["GET", "/dashboard", (c) => S.dashboard(c.db)],
  ["GET", "/search", (c) => S.search(c.db, c.query)],
  ["GET", "/settings", (c) => S.getSettings(c.db)],
  ["PUT", "/business/details", (c) => S.saveBusinessDetails(c.db, c.body)],
  ["PUT", "/settings", (c) => { adminOnly(c); return S.updateSettings(c.db, c.body); }],
  ...crud("customers", S.listCustomers, S.getCustomer, S.createCustomer, S.updateCustomer, S.deleteCustomer),
  ...crud("events", S.listEvents, S.getEvent, S.createEvent, S.updateEvent, S.deleteEvent),
  ...crud("menus", S.listMenus, S.getMenu, S.createMenu, S.updateMenu, S.deleteMenu),
  ["GET", "/bookings", (c) => S.listBookings(c.db, c.query)],
  ["GET", "/bookings/:id", (c) => S.getBooking(c.db, c.params.id)],
  ["POST", "/bookings", (c) => S.createBooking(c.db, c.body), 201],
  ["PUT", "/bookings/:id", (c) => S.updateBooking(c.db, c.params.id, c.body)],
  ["PATCH", "/bookings/:id/status", (c) => S.setBookingStatus(c.db, c.params.id, c.body)],
  ["GET", "/guests", (c) => S.listGuests(c.db, c.query)],
  ["PUT", "/guests/:id", (c) => S.updateGuests(c.db, c.params.id, c.body)],
  ...crud("staff", S.listStaff, S.getStaff, S.createStaff, S.updateStaff, S.deleteStaff),
  ["GET", "/assignments", (c) => S.listAssignments(c.db, c.query)],
  ["POST", "/assignments", (c) => S.createAssignment(c.db, c.body), 201],
  ["PUT", "/assignments/:id", (c) => S.updateAssignment(c.db, c.params.id, c.body)],
  ["DELETE", "/assignments/:id", (c) => S.deleteAssignment(c.db, c.params.id)],
  ["GET", "/payments", (c) => S.listPayments(c.db, c.query)],
  ["GET", "/payments/:id", (c) => S.getPayment(c.db, c.params.id)],
  ["POST", "/payments", (c) => S.recordPayment(c.db, c.body), 201],
  ["GET", "/feedback", (c) => S.listFeedback(c.db, c.query)],
  ["POST", "/feedback", (c) => S.createFeedback(c.db, c.body), 201],
  ["PUT", "/feedback/:id", (c) => S.updateFeedback(c.db, c.params.id, c.body)],
  ["DELETE", "/feedback/:id", (c) => S.deleteFeedback(c.db, c.params.id)],
  ["GET", "/reports/:type", (c) => S.report(c.db, c.params.type, c.query)],
];

/** Framework-neutral dispatcher. Returns { status, body }. */
export async function dispatch({ db, env, method, path, query, body, authorization }) {
  for (const [m, pattern, handler, status = 200, isPublic = false] of routes) {
    if (m !== method) continue;
    const names = [];
    const re = new RegExp("^" + pattern.replace(/:(\w+)/g, (_, n) => (names.push(n), "([^/]+)")) + "/?$");
    const match = re.exec(path);
    if (!match) continue;
    const params = Object.fromEntries(names.map((n, i) => [n, decodeURIComponent(match[i + 1])]));
    try {
      const user = isPublic ? null : await A.verifyRequest(db, authorization, env);
      const scoped = user ? tenantDb(db,user.business_id) : path.startsWith('/public/') ? await publicBusinessDb(db,query,body) : db;
      const data = await handler({ db:scoped, env, params, query: query || {}, body: body || {}, user });
      return { status, body: { success: true, data } };
    } catch (e) {
      return errorResponse(e);
    }
  }
  return { status: 404, body: { success: false, message: "Endpoint not found" } };
}

export function errorResponse(e) {
  if (e instanceof HttpError) return { status: e.status, body: { success: false, message: e.message, errors: e.details } };
  const code = e && (e.code || e.errno);
  if (code === "23503" || code === "ER_ROW_IS_REFERENCED_2" || code === "ER_NO_REFERENCED_ROW_2") return { status: 409, body: { success: false, message: "This record is linked to other records and cannot be changed this way." } };
  if (code === "23505" || code === "ER_DUP_ENTRY") return { status: 409, body: { success: false, message: "A record with these details already exists." } };
  if (code === "23514" || code === "ER_CHECK_CONSTRAINT_VIOLATED") return { status: 400, body: { success: false, message: "A value is outside the allowed range." } };
  console.error(e);
  return { status: 500, body: { success: false, message: "Unexpected server error. Please try again." } };
}
