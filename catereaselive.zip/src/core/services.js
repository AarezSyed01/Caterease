// Business logic for CaterEase.
// Every function receives a `db` adapter (MySQL in backend/, Lovable Cloud in the preview)
// with: all(table, whereEq), get(table, id), insert(table, row), update(table, id, row),
// remove(table, id), tx(fn).
import {
  HttpError, bad, notFound, conflict, toPaise, fromPaise, todayStr, str, bool, dateOnly, timeOnly,
  isValidDate, isValidTime, posInt, idParam, validate, like, paymentStatus, BOOKING_STATUSES,
  canTransition, calcTotal,
} from "./util.js";

/* ---------------- settings ---------------- */
export const DEFAULT_SETTINGS = {
  business_name: "CaterEase",
  business_phone: "",
  business_email: "",
  business_address: "",
  city: "", state: "", business_type: "", gst_number: "",
  currency_symbol: "₹",
  pricing_model: "per_person",
  contact_pattern: "^(\\+91[- ]?)?[6-9][0-9]{9}$",
  report_footer: "Computer-generated report — CaterEase",
};
export async function getSettings(db) {
  const rows = await db.all("settings");
  const s = { ...DEFAULT_SETTINGS };
  for (const r of rows) s[r.setting_key] = r.setting_value;
  return s;
}
export async function updateSettings(db, body) {
  const allowed = Object.keys(DEFAULT_SETTINGS);
  const errs = [];
  if (body.pricing_model && !["per_person", "fixed"].includes(body.pricing_model)) errs.push(["pricing_model", "Choose per person or fixed"]);
  if (body.contact_pattern) { try { new RegExp(body.contact_pattern); } catch { errs.push(["contact_pattern", "Invalid pattern"]); } }
  if (body.business_name !== undefined && !str(body.business_name)) errs.push(["business_name", "Required"]);
  validate(errs);
  const existing = await db.all("settings");
  for (const k of allowed) {
    if (body[k] === undefined) continue;
    const v = str(body[k]).slice(0, 500);
    if (existing.find((r) => r.setting_key === k)) await db.update("settings", k, { setting_value: v });
    else await db.insert("settings", { setting_key: k, setting_value: v });
  }
  return getSettings(db);
}

/* ---------------- business details (post-registration onboarding) ---------------- */
export async function saveBusinessDetails(db, body) {
  const data = Object.fromEntries(['business_name','mobile','address','city','state','business_type','gst_number'].map(k => [k, str(body[k])]));
  data.gst_number = data.gst_number.toUpperCase();
  validate([
    ...['business_name','mobile','address','city','state'].map(k => [k, !data[k] ? 'Required' : null]),
    ...[['business_name',100],['mobile',20],['address',255],['city',100],['state',100],['business_type',100]].map(([k,n]) => [k, data[k].length > n ? `Maximum ${n} characters` : null]),
    ['mobile', !/^(\+91[- ]?)?[6-9][0-9]{9}$/.test(data.mobile) ? 'Enter a valid Indian mobile number' : null],
    ['gst_number', data.gst_number && !/^[0-9A-Z]{15}$/.test(data.gst_number) ? 'Enter a 15-character GST number' : null],
  ]);
  const business = (await db.all('businesses'))[0];
  if (!business) throw new HttpError(404, 'Business not found');
  await db.update('businesses', business.business_id, {
    business_name: data.business_name, owner_name: business.owner_name, mobile: data.mobile,
    address: data.address, city: data.city, state: data.state,
    business_type: data.business_type || null, gst_number: data.gst_number || null,
  });
  const settings = { business_name: data.business_name, business_phone: data.mobile, business_address: data.address, city: data.city, state: data.state, business_type: data.business_type, gst_number: data.gst_number, details_complete: 'true' };
  const existing = await db.all('settings');
  for (const [k, v] of Object.entries(settings)) {
    if (existing.find((r) => r.setting_key === k)) await db.update('settings', k, { setting_value: v });
    else await db.insert('settings', { setting_key: k, setting_value: v });
  }
  return { saved: true, details_complete: true };
}

/* ---------------- normalisers ---------------- */
const nCustomer = (r) => r && { ...r, is_active: bool(r.is_active) };
const nEvent = (r) => r && { ...r, event_date: dateOnly(r.event_date), event_time: timeOnly(r.event_time) };
const nMenu = (r) => r && { ...r, price: Number(r.price), availability: bool(r.availability) };
const nStaff = (r) => r && { ...r, is_active: bool(r.is_active) };
const nBooking = (r) => r && { ...r, booking_date: dateOnly(r.booking_date), unit_price: Number(r.unit_price), total_amount: Number(r.total_amount) };
const nPayment = (r) => r && { ...r, payment_date: dateOnly(r.payment_date), total_amount: Number(r.total_amount), advance_payment: Number(r.advance_payment), remaining_balance: Number(r.remaining_balance) };

async function mustGet(db, table, id, label, norm = (x) => x) {
  const row = await db.get(table, idParam(id, label));
  if (!row) throw notFound(label);
  return norm(row);
}

/* ---------------- shared data loading ---------------- */
async function loadAll(db) {
  const [customers, events, menus, bookings, payments, guests, staff, assignments, feedback] = await Promise.all([
    db.all("customers"), db.all("events"), db.all("menus"), db.all("bookings"), db.all("payments"),
    db.all("guests"), db.all("staff"), db.all("staff_assignments"), db.all("feedback"),
  ]);
  const d = {
    customers: customers.map(nCustomer), events: events.map(nEvent), menus: menus.map(nMenu),
    bookings: bookings.map(nBooking), payments: payments.map(nPayment), guests, staff: staff.map(nStaff),
    assignments, feedback,
  };
  d.byId = (list, key) => new Map(d[list].map((r) => [Number(r[key]), r]));
  return d;
}

function paidMap(payments) {
  const m = new Map();
  for (const p of payments) m.set(Number(p.booking_id), (m.get(Number(p.booking_id)) || 0) + toPaise(p.advance_payment));
  return m;
}

function enrichBookings(d) {
  const cust = d.byId("customers", "customer_id");
  const ev = d.byId("events", "event_id");
  const paid = paidMap(d.payments);
  return d.bookings.map((b) => {
    const c = cust.get(Number(b.customer_id)) || {};
    const e = ev.get(Number(b.event_id)) || {};
    const totalP = toPaise(b.total_amount);
    const paidP = paid.get(Number(b.booking_id)) || 0;
    return {
      ...b,
      customer_name: c.name, contact_no: c.contact_no,
      event_type: e.event_type, event_date: e.event_date, event_time: e.event_time, venue: e.venue,
      amount_paid: fromPaise(paidP),
      balance: b.booking_status === "Cancelled" ? 0 : fromPaise(Math.max(0, totalP - paidP)),
      payment_status: paymentStatus(totalP, paidP, b.booking_status),
    };
  });
}

function inRange(date, from, to) {
  if (!date) return !from && !to;
  if (from && date < from) return false;
  if (to && date > to) return false;
  return true;
}

/* ---------------- customers ---------------- */
async function contactRule(db) {
  const s = await getSettings(db);
  try { return new RegExp(s.contact_pattern); } catch { return new RegExp(DEFAULT_SETTINGS.contact_pattern); }
}
async function customerInput(db, body) {
  const re = await contactRule(db);
  const name = str(body.name), contact_no = str(body.contact_no).replace(/\s+/g, ""), address = str(body.address);
  const email = str(body.email);
  validate([
    ["name", !name ? "Name is required" : name.length > 100 ? "Max 100 characters" : null],
    ["contact_no", !contact_no ? "Contact number is required" : !re.test(contact_no) ? "Enter a valid 10-digit mobile number" : null],
    ["address", address.length > 255 ? "Max 255 characters" : null],
    ["email", email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) ? "Invalid email" : null],
  ]);
  return { name, contact_no, address: address || null, email: email || null };
}
export async function listCustomers(db, q) {
  const [rows, bookings] = await Promise.all([db.all("customers"), db.all("bookings")]);
  let list = rows.map(nCustomer).map((c) => ({ ...c, booking_count: bookings.filter((b) => Number(b.customer_id) === Number(c.customer_id)).length }));
  if (q.q) list = list.filter((c) => like(c.name, q.q) || like(c.contact_no, q.q) || String(c.customer_id) === str(q.q));
  if (q.status === "active") list = list.filter((c) => c.is_active);
  if (q.status === "archived") list = list.filter((c) => !c.is_active);
  return list.sort((a, b) => b.customer_id - a.customer_id);
}
export async function getCustomer(db, id) {
  const c = await mustGet(db, "customers", id, "Customer", nCustomer);
  const d = await loadAll(db);
  const cid = Number(c.customer_id);
  return {
    ...c,
    events: d.events.filter((e) => Number(e.customer_id) === cid),
    bookings: enrichBookings(d).filter((b) => Number(b.customer_id) === cid),
    feedback: d.feedback.filter((f) => Number(f.customer_id) === cid),
  };
}
async function assertUniqueContact(db, contact_no, exceptId) {
  const dup = (await db.all("customers", { contact_no })).find((c) => Number(c.customer_id) !== Number(exceptId));
  if (dup) throw new HttpError(409, `Contact number already belongs to customer #${dup.customer_id} (${dup.name})`, { contact_no: "Already registered" });
}
export async function createCustomer(db, body) {
  const data = await customerInput(db, body);
  await assertUniqueContact(db, data.contact_no);
  return nCustomer(await db.insert("customers", data));
}
export async function updateCustomer(db, id, body) {
  await mustGet(db, "customers", id, "Customer");
  const data = await customerInput(db, body);
  await assertUniqueContact(db, data.contact_no, id);
  if (body.is_active !== undefined) data.is_active = bool(body.is_active);
  return nCustomer(await db.update("customers", idParam(id), data));
}
export async function deleteCustomer(db, id) {
  const c = await mustGet(db, "customers", id, "Customer");
  const [ev, bk, fb] = await Promise.all([db.all("events", { customer_id: c.customer_id }), db.all("bookings", { customer_id: c.customer_id }), db.all("feedback", { customer_id: c.customer_id })]);
  if (ev.length || bk.length || fb.length) {
    await db.update("customers", c.customer_id, { is_active: false });
    return { archived: true, message: "Customer has history, so the record was archived instead of deleted." };
  }
  await db.remove("customers", c.customer_id);
  return { deleted: true };
}

/* ---------------- events ---------------- */
async function eventInput(db, body) {
  const event_type = str(body.event_type), venue = str(body.venue), event_date = str(body.event_date), event_time = str(body.event_time).slice(0, 5);
  validate([
    ["customer_id", !Number(body.customer_id) ? "Select a customer" : null],
    ["event_type", !event_type ? "Event type is required" : event_type.length > 50 ? "Max 50 characters" : null],
    ["event_date", !isValidDate(event_date) ? "Enter a valid date" : null],
    ["event_time", !isValidTime(event_time) ? "Enter a valid time" : null],
    ["venue", !venue ? "Venue is required" : venue.length > 200 ? "Max 200 characters" : null],
  ]);
  const cust = await db.get("customers", Number(body.customer_id));
  if (!cust) throw bad("Selected customer does not exist", { customer_id: "Invalid customer" });
  return { customer_id: Number(body.customer_id), event_type, event_date, event_time, venue, notes: str(body.notes).slice(0, 500) || null };
}
async function eventConflicts(db, ev, exceptId) {
  const same = (await db.all("events")).map(nEvent).filter((e) => e.event_date === ev.event_date && Number(e.event_id) !== Number(exceptId));
  return same.filter((e) => like(e.venue, ev.venue) || like(ev.venue, e.venue)).map((e) => `Event #${e.event_id} (${e.event_type}) is also scheduled at this venue on ${e.event_date} ${e.event_time}`)
    .concat(same.length >= 3 ? [`${same.length} other events are already scheduled on ${ev.event_date}`] : []);
}
export async function listEvents(db, q) {
  const d = await loadAll(db);
  const cust = d.byId("customers", "customer_id");
  const bookings = enrichBookings(d);
  let list = d.events.map((e) => {
    const b = bookings.find((x) => Number(x.event_id) === Number(e.event_id) && x.booking_status !== "Cancelled") || bookings.find((x) => Number(x.event_id) === Number(e.event_id));
    return { ...e, customer_name: cust.get(Number(e.customer_id))?.name, booking_id: b?.booking_id ?? null, booking_status: b?.booking_status ?? null, guest_count: b?.guest_count ?? null,
      staff_count: d.assignments.filter((a) => Number(a.event_id) === Number(e.event_id)).length };
  });
  if (q.q) list = list.filter((e) => like(e.event_type, q.q) || like(e.venue, q.q) || like(e.customer_name, q.q) || String(e.event_id) === str(q.q));
  if (q.event_type) list = list.filter((e) => e.event_type === q.event_type);
  if (q.customer_id) list = list.filter((e) => Number(e.customer_id) === Number(q.customer_id));
  if (q.venue) list = list.filter((e) => like(e.venue, q.venue));
  if (q.from || q.to) list = list.filter((e) => inRange(e.event_date, q.from, q.to));
  if (q.upcoming) list = list.filter((e) => e.event_date >= todayStr());
  return list.sort((a, b) => (a.event_date + a.event_time).localeCompare(b.event_date + b.event_time));
}
export async function getEvent(db, id) {
  const e = await mustGet(db, "events", id, "Event", nEvent);
  const d = await loadAll(db);
  const staff = d.byId("staff", "staff_id");
  return {
    ...e,
    customer: d.customers.find((c) => Number(c.customer_id) === Number(e.customer_id)),
    bookings: enrichBookings(d).filter((b) => Number(b.event_id) === Number(e.event_id)),
    assignments: d.assignments.filter((a) => Number(a.event_id) === Number(e.event_id)).map((a) => ({ ...a, staff_name: staff.get(Number(a.staff_id))?.staff_name, role: staff.get(Number(a.staff_id))?.role })),
    warnings: await eventConflicts(db, e, e.event_id),
  };
}
export async function createEvent(db, body) {
  const data = await eventInput(db, body);
  const row = nEvent(await db.insert("events", data));
  return { ...row, warnings: await eventConflicts(db, row, row.event_id) };
}
export async function updateEvent(db, id, body) {
  await mustGet(db, "events", id, "Event");
  const data = await eventInput(db, body);
  const bks = await db.all("bookings", { event_id: idParam(id) });
  if (bks.some((b) => Number(b.customer_id) !== data.customer_id)) throw conflict("This event is booked for a different customer; the customer cannot be changed.");
  const row = nEvent(await db.update("events", idParam(id), data));
  return { ...row, warnings: await eventConflicts(db, row, row.event_id) };
}
export async function deleteEvent(db, id) {
  const e = await mustGet(db, "events", id, "Event");
  const [bk, as] = await Promise.all([db.all("bookings", { event_id: e.event_id }), db.all("staff_assignments", { event_id: e.event_id })]);
  if (bk.length) throw conflict("This event has bookings and cannot be deleted. Cancel the booking instead to keep history.");
  if (as.length) throw conflict("Remove the staff assignments for this event before deleting it.");
  await db.remove("events", e.event_id);
  return { deleted: true };
}

/* ---------------- menus ---------------- */
function menuInput(body) {
  const menu_name = str(body.menu_name), category = str(body.category), priceRaw = str(body.price);
  const price = Number(priceRaw);
  validate([
    ["menu_name", !menu_name ? "Menu name is required" : menu_name.length > 100 ? "Max 100 characters" : null],
    ["category", !category ? "Category is required" : null],
    ["price", priceRaw === "" || !Number.isFinite(price) || price < 0 ? "Enter a non-negative price" : !/^\d+(\.\d{1,2})?$/.test(priceRaw) ? "Max 2 decimal places" : price > 9999999999 ? "Too large" : null],
  ]);
  return { menu_name, category, price: fromPaise(toPaise(price)), availability: body.availability === undefined ? true : bool(body.availability), description: str(body.description).slice(0, 500) || null };
}
export async function listMenus(db, q) {
  let list = (await db.all("menus")).map(nMenu);
  if (q.q) list = list.filter((m) => like(m.menu_name, q.q) || like(m.category, q.q));
  if (q.category) list = list.filter((m) => m.category === q.category);
  if (q.availability === "available") list = list.filter((m) => m.availability);
  if (q.availability === "unavailable") list = list.filter((m) => !m.availability);
  return list.sort((a, b) => a.menu_name.localeCompare(b.menu_name));
}
export async function getMenu(db, id) {
  const m = await mustGet(db, "menus", id, "Menu", nMenu);
  const d = await loadAll(db);
  return { ...m, bookings: enrichBookings(d).filter((b) => Number(b.menu_id) === Number(m.menu_id)) };
}
export const createMenu = async (db, body) => nMenu(await db.insert("menus", menuInput(body)));
export async function updateMenu(db, id, body) {
  await mustGet(db, "menus", id, "Menu");
  return nMenu(await db.update("menus", idParam(id), menuInput(body)));
}
export async function deleteMenu(db, id) {
  const m = await mustGet(db, "menus", id, "Menu");
  if ((await db.all("bookings", { menu_id: m.menu_id })).length) {
    await db.update("menus", m.menu_id, { availability: false });
    return { archived: true, message: "Menu is used by bookings, so it was marked unavailable instead of deleted." };
  }
  await db.remove("menus", m.menu_id);
  return { deleted: true };
}

/* ---------------- bookings ---------------- */
export async function listBookings(db, q) {
  const d = await loadAll(db);
  let list = enrichBookings(d);
  if (q.q) list = list.filter((b) => String(b.booking_id) === str(q.q).replace(/^#/, "") || like(b.customer_name, q.q) || like(b.contact_no, q.q));
  if (q.status) list = list.filter((b) => b.booking_status === q.status);
  if (q.payment_status) list = list.filter((b) => b.payment_status === q.payment_status);
  if (q.customer_id) list = list.filter((b) => Number(b.customer_id) === Number(q.customer_id));
  if (q.event_from || q.event_to) list = list.filter((b) => inRange(b.event_date, q.event_from, q.event_to));
  if (q.booking_from || q.booking_to) list = list.filter((b) => inRange(b.booking_date, q.booking_from, q.booking_to));
  if (q.outstanding) list = list.filter((b) => b.balance > 0);
  return list.sort((a, b) => b.booking_id - a.booking_id);
}
export async function getBooking(db, id) {
  const b0 = await mustGet(db, "bookings", id, "Booking");
  const d = await loadAll(db);
  const b = enrichBookings(d).find((x) => Number(x.booking_id) === Number(b0.booking_id));
  const staff = d.byId("staff", "staff_id");
  return {
    ...b,
    customer: d.customers.find((c) => Number(c.customer_id) === Number(b.customer_id)),
    event: d.events.find((e) => Number(e.event_id) === Number(b.event_id)),
    menu: d.menus.find((m) => Number(m.menu_id) === Number(b.menu_id)),
    guest: d.guests.find((g) => Number(g.booking_id) === Number(b.booking_id)) || null,
    payments: d.payments.filter((p) => Number(p.booking_id) === Number(b.booking_id)).sort((x, y) => x.payment_id - y.payment_id),
    assignments: d.assignments.filter((a) => Number(a.event_id) === Number(b.event_id)).map((a) => ({ ...a, staff_name: staff.get(Number(a.staff_id))?.staff_name, role: staff.get(Number(a.staff_id))?.role })),
    feedback: d.feedback.find((f) => Number(f.booking_id) === Number(b.booking_id)) || null,
    allowed_statuses: BOOKING_STATUSES.filter((s) => canTransition(b.booking_status, s)),
  };
}

/** Booking creation: optional new customer + new event + booking + guest record, in one transaction. */
export async function createBooking(db, body, { source = "admin" } = {}) {
  const settings = await getSettings(db);
  const status = str(body.booking_status) || "Pending";
  const booking_date = str(body.booking_date) || todayStr();
  validate([
    ["menu_id", !Number(body.menu_id) ? "Select a menu/package" : null],
    ["guest_count", !(Number.isInteger(Number(body.guest_count)) && Number(body.guest_count) > 0) ? "Guest count must be a positive whole number" : Number(body.guest_count) > 100000 ? "Too many guests" : null],
    ["booking_date", !isValidDate(booking_date) ? "Enter a valid date" : null],
    ["booking_status", !["Pending", "Confirmed"].includes(status) ? "New bookings start as Pending or Confirmed" : null],
    ["customer_id", !Number(body.customer_id) && !body.new_customer ? "Select or create a customer" : null],
    ["event_id", !Number(body.event_id) && !body.new_event ? "Select or create an event" : null],
  ]);
  const request_key = str(body.request_key).slice(0, 64) || null;
  if (request_key) {
    const existing = await db.all("bookings", { request_key });
    if (existing.length) return { ...(await getBooking(db, existing[0].booking_id)), duplicate: true };
  }
  const menu = nMenu(await db.get("menus", Number(body.menu_id)));
  if (!menu) throw bad("Selected menu does not exist", { menu_id: "Invalid menu" });
  if (!menu.availability) throw bad("This menu is currently unavailable and cannot be booked", { menu_id: "Menu unavailable" });
  const guests = Number(body.guest_count);
  const custData = body.new_customer ? await customerInput(db, body.new_customer) : null;
  if (custData) {
    const dup = (await db.all("customers", { contact_no: custData.contact_no }))[0];
    if (dup && source !== "inquiry") throw new HttpError(409, `Contact number already belongs to customer #${dup.customer_id} (${dup.name}). Select the existing customer.`, { contact_no: "Already registered" });
  }

  const newId = await db.tx(async (t) => {
    let customer_id = Number(body.customer_id);
    if (custData) {
      const dup = (await t.all("customers", { contact_no: custData.contact_no }))[0];
      customer_id = dup ? Number(dup.customer_id) : Number((await t.insert("customers", custData)).customer_id);
    } else if (!(await t.get("customers", customer_id))) throw bad("Selected customer does not exist", { customer_id: "Invalid customer" });

    let event_id = Number(body.event_id);
    if (body.new_event) {
      const evData = await eventInput(t, { ...body.new_event, customer_id });
      event_id = Number((await t.insert("events", evData)).event_id);
    } else {
      const ev = await t.get("events", event_id);
      if (!ev) throw bad("Selected event does not exist", { event_id: "Invalid event" });
      if (Number(ev.customer_id) !== customer_id) throw bad("The selected event belongs to a different customer", { event_id: "Event belongs to another customer" });
      const active = (await t.all("bookings", { event_id })).filter((b) => b.booking_status !== "Cancelled");
      if (active.length) throw conflict(`Event already has active booking #${active[0].booking_id}`);
    }
    const unitP = toPaise(menu.price);
    const totalP = calcTotal(unitP, guests, settings.pricing_model);
    const booking = await t.insert("bookings", {
      customer_id, event_id, menu_id: menu.menu_id, booking_date, guest_count: guests,
      menu_name_snapshot: menu.menu_name, unit_price: fromPaise(unitP), pricing_model: settings.pricing_model,
      total_amount: fromPaise(totalP), booking_status: source === "inquiry" ? "Pending" : status, source,
      request_key, notes: str(body.notes).slice(0, 500) || null,
    });
    await t.insert("guests", { booking_id: booking.booking_id, guest_count: guests });
    return booking.booking_id;
  });
  return getBooking(db, newId);
}

export async function updateBooking(db, id, body) {
  const b = await mustGet(db, "bookings", id, "Booking", nBooking);
  if (["Completed", "Cancelled"].includes(b.booking_status)) throw conflict(`A ${b.booking_status.toLowerCase()} booking cannot be edited`);
  const booking_date = str(body.booking_date) || b.booking_date;
  validate([["booking_date", !isValidDate(booking_date) ? "Enter a valid date" : null]]);
  const patch = { booking_date, notes: body.notes !== undefined ? str(body.notes).slice(0, 500) || null : b.notes };
  // Changing the menu re-snapshots the current price; otherwise the agreed price is kept.
  if (body.menu_id && Number(body.menu_id) !== Number(b.menu_id)) {
    const m = nMenu(await db.get("menus", Number(body.menu_id)));
    if (!m) throw bad("Selected menu does not exist", { menu_id: "Invalid menu" });
    if (!m.availability) throw bad("This menu is unavailable", { menu_id: "Menu unavailable" });
    Object.assign(patch, { menu_id: m.menu_id, menu_name_snapshot: m.menu_name, unit_price: m.price });
  }
  const guests = body.guest_count !== undefined ? posInt(body.guest_count, "guest_count") : b.guest_count;
  const unitP = toPaise(patch.unit_price ?? b.unit_price);
  const totalP = calcTotal(unitP, guests, b.pricing_model);
  const paidP = (await db.all("payments", { booking_id: b.booking_id })).reduce((s, p) => s + toPaise(p.advance_payment), 0);
  if (totalP < paidP) throw conflict("The new total would be less than the amount already received");
  Object.assign(patch, { guest_count: guests, total_amount: fromPaise(totalP) });
  await db.tx(async (t) => {
    await t.update("bookings", b.booking_id, patch);
    await syncGuest(t, b.booking_id, guests);
  });
  return getBooking(db, b.booking_id);
}
async function syncGuest(t, booking_id, guest_count, remarks) {
  const g = (await t.all("guests", { booking_id }))[0];
  const row = { guest_count, ...(remarks !== undefined ? { remarks: str(remarks).slice(0, 255) || null } : {}) };
  if (g) await t.update("guests", g.guest_id, row);
  else await t.insert("guests", { booking_id, ...row });
}
export async function setBookingStatus(db, id, body) {
  const b = await mustGet(db, "bookings", id, "Booking", nBooking);
  const to = str(body.booking_status);
  if (!BOOKING_STATUSES.includes(to)) throw bad("Unknown status", { booking_status: "Unknown status" });
  if (!canTransition(b.booking_status, to)) throw conflict(`Cannot change status from ${b.booking_status} to ${to}`);
  await db.update("bookings", b.booking_id, { booking_status: to });
  return getBooking(db, b.booking_id);
}

/* ---------------- guests ---------------- */
export async function listGuests(db, q) {
  const list = await listBookings(db, { q: q.q, event_from: q.from, event_to: q.to, status: q.status });
  const guests = await db.all("guests");
  return list.map((b) => {
    const g = guests.find((x) => Number(x.booking_id) === Number(b.booking_id));
    return { booking_id: b.booking_id, guest_id: g?.guest_id ?? null, customer_name: b.customer_name, event_type: b.event_type, event_date: b.event_date, venue: b.venue,
      menu_name_snapshot: b.menu_name_snapshot, booking_status: b.booking_status, guest_count: b.guest_count, remarks: g?.remarks ?? "", updated_at: g?.updated_at ?? b.updated_at };
  });
}
export async function updateGuests(db, bookingId, body) {
  const b = await mustGet(db, "bookings", bookingId, "Booking", nBooking);
  if (["Completed", "Cancelled"].includes(b.booking_status)) throw conflict(`Guest count of a ${b.booking_status.toLowerCase()} booking cannot be changed`);
  const guests = posInt(body.guest_count, "guest_count");
  const totalP = calcTotal(toPaise(b.unit_price), guests, b.pricing_model);
  const paidP = (await db.all("payments", { booking_id: b.booking_id })).reduce((s, p) => s + toPaise(p.advance_payment), 0);
  if (totalP < paidP) throw conflict("The new total would be less than the amount already received");
  await db.tx(async (t) => {
    await t.update("bookings", b.booking_id, { guest_count: guests, total_amount: fromPaise(totalP) });
    await syncGuest(t, b.booking_id, guests, body.remarks);
  });
  return getBooking(db, b.booking_id);
}

/* ---------------- staff ---------------- */
async function staffInput(db, body) {
  const staff_name = str(body.staff_name), role = str(body.role), contact_no = str(body.contact_no).replace(/\s+/g, "");
  const re = await contactRule(db);
  validate([
    ["staff_name", !staff_name ? "Name is required" : staff_name.length > 100 ? "Max 100 characters" : null],
    ["role", !role ? "Role is required" : null],
    ["contact_no", contact_no && !re.test(contact_no) ? "Enter a valid mobile number" : null],
  ]);
  return { staff_name, role, contact_no: contact_no || null, is_active: body.is_active === undefined ? true : bool(body.is_active) };
}
export async function listStaff(db, q) {
  const [rows, as] = await Promise.all([db.all("staff"), db.all("staff_assignments")]);
  let list = rows.map(nStaff).map((s) => ({ ...s, assignment_count: as.filter((a) => Number(a.staff_id) === Number(s.staff_id)).length }));
  if (q.q) list = list.filter((s) => like(s.staff_name, q.q) || String(s.staff_id) === str(q.q) || like(s.contact_no, q.q));
  if (q.role) list = list.filter((s) => s.role === q.role);
  if (q.status === "active") list = list.filter((s) => s.is_active);
  if (q.status === "inactive") list = list.filter((s) => !s.is_active);
  return list.sort((a, b) => a.staff_name.localeCompare(b.staff_name));
}
export async function getStaff(db, id) {
  const s = await mustGet(db, "staff", id, "Staff member", nStaff);
  return { ...s, assignments: await listAssignments(db, { staff_id: s.staff_id }) };
}
export const createStaff = async (db, body) => nStaff(await db.insert("staff", await staffInput(db, body)));
export async function updateStaff(db, id, body) {
  await mustGet(db, "staff", id, "Staff member");
  return nStaff(await db.update("staff", idParam(id), await staffInput(db, body)));
}
export async function deleteStaff(db, id) {
  const s = await mustGet(db, "staff", id, "Staff member");
  if ((await db.all("staff_assignments", { staff_id: s.staff_id })).length) {
    await db.update("staff", s.staff_id, { is_active: false });
    return { archived: true, message: "Staff member has assignment history, so they were deactivated instead of deleted." };
  }
  await db.remove("staff", s.staff_id);
  return { deleted: true };
}

/* ---------------- staff assignments ---------------- */
export async function listAssignments(db, q) {
  const d = await loadAll(db);
  const staff = d.byId("staff", "staff_id"), ev = d.byId("events", "event_id"), cust = d.byId("customers", "customer_id");
  let list = d.assignments.map((a) => {
    const e = ev.get(Number(a.event_id)) || {}, s = staff.get(Number(a.staff_id)) || {};
    return { ...a, staff_name: s.staff_name, role: s.role, event_type: e.event_type, event_date: e.event_date, event_time: e.event_time, venue: e.venue, customer_name: cust.get(Number(e.customer_id))?.name };
  });
  if (q.staff_id) list = list.filter((a) => Number(a.staff_id) === Number(q.staff_id));
  if (q.event_id) list = list.filter((a) => Number(a.event_id) === Number(q.event_id));
  if (q.role) list = list.filter((a) => a.role === q.role);
  if (q.from || q.to) list = list.filter((a) => inRange(a.event_date, q.from, q.to));
  if (q.q) list = list.filter((a) => like(a.staff_name, q.q) || like(a.work_assigned, q.q) || like(a.event_type, q.q) || like(a.venue, q.q));
  return list.sort((a, b) => String(a.event_date).localeCompare(String(b.event_date)));
}
async function assignmentInput(db, body, exceptId) {
  const work_assigned = str(body.work_assigned);
  validate([
    ["event_id", !Number(body.event_id) ? "Select an event" : null],
    ["staff_id", !Number(body.staff_id) ? "Select a staff member" : null],
    ["work_assigned", !work_assigned ? "Describe the work assigned" : work_assigned.length > 255 ? "Max 255 characters" : null],
  ]);
  const [ev, st] = await Promise.all([db.get("events", Number(body.event_id)), db.get("staff", Number(body.staff_id))]);
  if (!ev) throw bad("Selected event does not exist", { event_id: "Invalid event" });
  if (!st) throw bad("Selected staff member does not exist", { staff_id: "Invalid staff" });
  if (!bool(st.is_active)) throw bad("This staff member is inactive and cannot receive new assignments", { staff_id: "Inactive staff" });
  const dup = (await db.all("staff_assignments", { event_id: Number(body.event_id), staff_id: Number(body.staff_id) }))
    .find((a) => Number(a.assignment_id) !== Number(exceptId) && a.work_assigned.toLowerCase() === work_assigned.toLowerCase());
  if (dup) throw conflict("This staff member already has this task for the event");
  return { event_id: Number(body.event_id), staff_id: Number(body.staff_id), work_assigned };
}
export const createAssignment = async (db, body) => db.insert("staff_assignments", await assignmentInput(db, body));
export async function updateAssignment(db, id, body) {
  await mustGet(db, "staff_assignments", id, "Assignment");
  return db.update("staff_assignments", idParam(id), await assignmentInput(db, body, id));
}
export async function deleteAssignment(db, id) {
  const a = await mustGet(db, "staff_assignments", id, "Assignment");
  await db.remove("staff_assignments", a.assignment_id);
  return { deleted: true };
}

/* ---------------- payments ---------------- */
export async function listPayments(db, q) {
  const d = await loadAll(db);
  const bookings = new Map(enrichBookings(d).map((b) => [Number(b.booking_id), b]));
  let list = d.payments.map((p) => {
    const b = bookings.get(Number(p.booking_id)) || {};
    return { ...p, customer_name: b.customer_name, event_type: b.event_type, event_date: b.event_date, booking_status: b.booking_status, booking_payment_status: b.payment_status, current_balance: b.balance };
  });
  if (q.q) { const t = str(q.q).replace(/^#/, ""); list = list.filter((p) => String(p.payment_id) === t || String(p.booking_id) === t || like(p.customer_name, q.q)); }
  if (q.booking_id) list = list.filter((p) => Number(p.booking_id) === Number(q.booking_id));
  if (q.payment_status) list = list.filter((p) => p.booking_payment_status === q.payment_status);
  if (q.from || q.to) list = list.filter((p) => inRange(p.payment_date, q.from, q.to));
  return list.sort((a, b) => b.payment_id - a.payment_id);
}
export async function getPayment(db, id) {
  const p = await mustGet(db, "payments", id, "Payment", nPayment);
  const b = await getBooking(db, p.booking_id);
  const settings = await getSettings(db);
  const before = b.payments.filter((x) => x.payment_id <= p.payment_id).reduce((s, x) => s + toPaise(x.advance_payment), 0);
  return { ...p, received_to_date: fromPaise(before), booking: { booking_id: b.booking_id, customer_name: b.customer_name, contact_no: b.contact_no, event_type: b.event_type, event_date: b.event_date, venue: b.venue, menu_name_snapshot: b.menu_name_snapshot, guest_count: b.guest_count, total_amount: b.total_amount, amount_paid: b.amount_paid, balance: b.balance, payment_status: b.payment_status }, business: settings };
}
export async function recordPayment(db, body) {
  const amountRaw = str(body.amount), amount = Number(amountRaw), payment_date = str(body.payment_date) || todayStr();
  const modes = ["Cash", "UPI", "Bank Transfer", "Cheque", "Card"];
  validate([
    ["booking_id", !Number(body.booking_id) ? "Select a booking" : null],
    ["amount", !Number.isFinite(amount) || amount <= 0 ? "Enter an amount greater than zero" : !/^\d+(\.\d{1,2})?$/.test(amountRaw) ? "Max 2 decimal places" : null],
    ["payment_date", !isValidDate(payment_date) ? "Enter a valid date" : payment_date > todayStr() ? "Payment date cannot be in the future" : null],
    ["payment_mode", body.payment_mode && !modes.includes(body.payment_mode) ? "Choose a valid mode" : null],
  ]);
  const id = await db.tx(async (t) => {
    const b = nBooking(await t.get("bookings", Number(body.booking_id), { lock: true }));
    if (!b) throw bad("Selected booking does not exist", { booking_id: "Invalid booking" });
    if (b.booking_status === "Cancelled") throw conflict("Payments cannot be recorded against a cancelled booking");
    const totalP = toPaise(b.total_amount);
    const paidP = (await t.all("payments", { booking_id: b.booking_id })).reduce((s, p) => s + toPaise(p.advance_payment), 0);
    const amtP = toPaise(amount);
    const outstanding = totalP - paidP;
    if (outstanding <= 0) throw conflict("This booking is already fully paid");
    if (amtP > outstanding) throw bad(`Amount exceeds the outstanding balance of ${fromPaise(outstanding).toFixed(2)}`, { amount: `Max ${fromPaise(outstanding).toFixed(2)}` });
    const remaining = outstanding - amtP;
    const row = await t.insert("payments", {
      booking_id: b.booking_id, total_amount: fromPaise(totalP), advance_payment: fromPaise(amtP), remaining_balance: fromPaise(remaining),
      payment_status: paymentStatus(totalP, paidP + amtP, b.booking_status), payment_date, payment_mode: body.payment_mode || "Cash",
      reference_note: str(body.reference_note).slice(0, 255) || null,
    });
    return row.payment_id;
  });
  return getPayment(db, id);
}

/* ---------------- feedback ---------------- */
export async function listFeedback(db, q) {
  const d = await loadAll(db);
  const cust = d.byId("customers", "customer_id"), bk = new Map(enrichBookings(d).map((b) => [Number(b.booking_id), b]));
  let list = d.feedback.map((f) => ({ ...f, rating: Number(f.rating), customer_name: cust.get(Number(f.customer_id))?.name, event_type: bk.get(Number(f.booking_id))?.event_type, event_date: bk.get(Number(f.booking_id))?.event_date }));
  if (q.rating) list = list.filter((f) => f.rating === Number(q.rating));
  if (q.booking_id) list = list.filter((f) => Number(f.booking_id) === Number(q.booking_id));
  if (q.q) list = list.filter((f) => like(f.customer_name, q.q) || like(f.comments, q.q) || String(f.booking_id) === str(q.q));
  return list.sort((a, b) => b.feedback_id - a.feedback_id);
}
async function feedbackInput(db, body, exceptId) {
  const rating = Number(body.rating), comments = str(body.comments);
  validate([
    ["booking_id", !Number(body.booking_id) ? "Select a booking" : null],
    ["rating", !Number.isInteger(rating) || rating < 1 || rating > 5 ? "Rating must be between 1 and 5" : null],
    ["comments", comments.length > 1000 ? "Max 1000 characters" : null],
  ]);
  const b = await db.get("bookings", Number(body.booking_id));
  if (!b) throw bad("Selected booking does not exist", { booking_id: "Invalid booking" });
  if (b.booking_status === "Cancelled") throw bad("Feedback cannot be recorded for a cancelled booking", { booking_id: "Cancelled booking" });
  const dup = (await db.all("feedback", { booking_id: b.booking_id })).find((f) => Number(f.feedback_id) !== Number(exceptId));
  if (dup) throw conflict(`Feedback already exists for booking #${b.booking_id}`);
  // The customer is always taken from the booking so feedback can never be attributed to someone else.
  return { booking_id: Number(b.booking_id), customer_id: Number(b.customer_id), rating, comments: comments || null };
}
export const createFeedback = async (db, body) => db.insert("feedback", await feedbackInput(db, body));
export async function updateFeedback(db, id, body) {
  await mustGet(db, "feedback", id, "Feedback");
  return db.update("feedback", idParam(id), await feedbackInput(db, body, id));
}
export async function deleteFeedback(db, id) {
  const f = await mustGet(db, "feedback", id, "Feedback");
  await db.remove("feedback", f.feedback_id);
  return { deleted: true };
}

/* ---------------- dashboard ---------------- */
function monthKeys(n) {
  const [y, m] = todayStr().split("-").map(Number);
  const out = [];
  for (let i = n - 1; i >= 0; i--) { const d = new Date(Date.UTC(y, m - 1 - i, 1)); out.push(d.toISOString().slice(0, 7)); }
  return out;
}
export function financials(d) {
  const bookings = enrichBookings(d);
  const active = bookings.filter((b) => b.booking_status !== "Cancelled");
  const value = active.reduce((s, b) => s + toPaise(b.total_amount), 0);
  const collected = d.payments.reduce((s, p) => s + toPaise(p.advance_payment), 0);
  const outstanding = active.reduce((s, b) => s + toPaise(b.balance), 0);
  return { bookings, active, value: fromPaise(value), collected: fromPaise(collected), outstanding: fromPaise(outstanding) };
}
export async function dashboard(db) {
  const d = await loadAll(db);
  const today = todayStr();
  const f = financials(d);
  const months = monthKeys(12);
  const statusDist = Object.fromEntries(BOOKING_STATUSES.map((s) => [s, f.bookings.filter((b) => b.booking_status === s).length]));
  const payDist = {};
  for (const b of f.active) payDist[b.payment_status] = (payDist[b.payment_status] || 0) + 1;
  const upcoming = f.bookings.filter((b) => b.event_date >= today && b.booking_status !== "Cancelled").sort((a, b) => (a.event_date + a.event_time).localeCompare(b.event_date + b.event_time));
  const in7 = new Date(today + "T00:00:00Z"); in7.setUTCDate(in7.getUTCDate() + 7);
  return {
    today,
    cards: {
      total_customers: d.customers.length,
      total_events: d.events.length,
      total_bookings: d.bookings.length,
      upcoming_events: d.events.filter((e) => e.event_date >= today).length,
      total_booking_value: f.value,
      amount_collected: f.collected,
      outstanding_balance: f.outstanding,
      completed_bookings: statusDist.Completed,
    },
    charts: {
      months,
      monthly_bookings: months.map((m) => f.bookings.filter((b) => String(b.booking_date).startsWith(m)).length),
      monthly_collections: months.map((m) => fromPaise(d.payments.filter((p) => String(p.payment_date).startsWith(m)).reduce((s, p) => s + toPaise(p.advance_payment), 0))),
      status_distribution: statusDist,
      payment_distribution: payDist,
    },
    upcoming: upcoming.slice(0, 8),
    recent_bookings: [...f.bookings].sort((a, b) => b.booking_id - a.booking_id).slice(0, 6),
    pending_payments: f.active.filter((b) => b.balance > 0).sort((a, b) => b.balance - a.balance).slice(0, 6),
    notifications: {
      pending_bookings: statusDist.Pending,
      events_next_7_days: upcoming.filter((b) => b.event_date <= in7.toISOString().slice(0, 10)).length,
      unpaid_bookings: f.active.filter((b) => b.payment_status === "Unpaid").length,
      new_inquiries: f.bookings.filter((b) => b.source === "inquiry" && b.booking_status === "Pending").length,
    },
  };
}

/* ---------------- global search ---------------- */
export async function search(db, q) {
  const t = str(q.q);
  if (t.length < 2) return [];
  const d = await loadAll(db);
  const out = [];
  d.customers.filter((c) => like(c.name, t) || like(c.contact_no, t)).slice(0, 5).forEach((c) => out.push({ type: "Customer", label: `${c.name} · ${c.contact_no}`, href: `#/customers/${c.customer_id}` }));
  enrichBookings(d).filter((b) => String(b.booking_id) === t.replace(/^#/, "") || like(b.customer_name, t)).slice(0, 5).forEach((b) => out.push({ type: "Booking", label: `#${b.booking_id} · ${b.customer_name} · ${b.event_type}`, href: `#/bookings/${b.booking_id}` }));
  d.events.filter((e) => like(e.venue, t) || like(e.event_type, t)).slice(0, 5).forEach((e) => out.push({ type: "Event", label: `${e.event_type} · ${e.event_date} · ${e.venue}`, href: `#/events/${e.event_id}` }));
  d.menus.filter((m) => like(m.menu_name, t)).slice(0, 3).forEach((m) => out.push({ type: "Menu", label: m.menu_name, href: `#/menus/${m.menu_id}` }));
  d.staff.filter((s) => like(s.staff_name, t)).slice(0, 3).forEach((s) => out.push({ type: "Staff", label: `${s.staff_name} · ${s.role}`, href: `#/staff/${s.staff_id}` }));
  return out;
}

/* ---------------- reports ---------------- */
export async function report(db, type, q) {
  const d = await loadAll(db);
  const f = financials(d);
  const staff = d.byId("staff", "staff_id");
  const filt = (b) =>
    (!q.status || b.booking_status === q.status) &&
    (!q.payment_status || b.payment_status === q.payment_status) &&
    (!q.event_type || b.event_type === q.event_type) &&
    (!q.customer_id || Number(b.customer_id) === Number(q.customer_id)) &&
    (!q.menu_id || Number(b.menu_id) === Number(q.menu_id));
  const sum = (rows, k) => fromPaise(rows.reduce((s, r) => s + toPaise(r[k]), 0));
  const bookings = f.bookings.filter(filt);
  const byEventDate = bookings.filter((b) => inRange(b.event_date, q.from, q.to));

  switch (type) {
    case "booking": {
      const rows = byEventDate.sort((a, b) => a.booking_id - b.booking_id);
      return { title: "Booking Report", date_basis: "Event date",
        columns: [["booking_id", "Booking ID"], ["customer_name", "Customer"], ["event_type", "Event"], ["menu_name_snapshot", "Menu / Package"], ["booking_date", "Booking Date"], ["event_date", "Event Date"], ["guest_count", "Guests"], ["total_amount", "Total (₹)", "money"], ["booking_status", "Status"]],
        rows, summary: [["Bookings", rows.length], ["Total guests", rows.reduce((s, r) => s + r.guest_count, 0)], ["Booking value excl. cancelled (₹)", sum(rows.filter((r) => r.booking_status !== "Cancelled"), "total_amount"), "money"]] };
    }
    case "order": {
      const rows0 = byEventDate.filter((b) => b.booking_status !== "Cancelled");
      const groups = new Map();
      for (const b of rows0) {
        const g = groups.get(b.menu_id) || { menu_id: b.menu_id, menu_name: b.menu_name_snapshot, category: d.menus.find((m) => Number(m.menu_id) === Number(b.menu_id))?.category, bookings: 0, guests: 0, value: 0, booking_ids: [] };
        g.bookings++; g.guests += b.guest_count; g.value += toPaise(b.total_amount); g.booking_ids.push("#" + b.booking_id);
        groups.set(b.menu_id, g);
      }
      const rows = [...groups.values()].map((g) => ({ ...g, value: fromPaise(g.value), booking_ids: g.booking_ids.join(", ") })).sort((a, b) => b.value - a.value);
      return { title: "Order Report (Menu / Package Summary)", date_basis: "Event date",
        columns: [["menu_name", "Menu / Package"], ["category", "Category"], ["bookings", "Bookings"], ["guests", "Total Guests"], ["value", "Booking Value (₹)", "money"], ["booking_ids", "Booking IDs"]],
        rows, summary: [["Menus ordered", rows.length], ["Total guests", rows.reduce((s, r) => s + r.guests, 0)], ["Booking value (₹)", sum(rows, "value"), "money"]] };
    }
    case "payment": {
      const bmap = new Map(bookings.map((b) => [Number(b.booking_id), b]));
      const rows = d.payments.filter((p) => bmap.has(Number(p.booking_id)) && inRange(p.payment_date, q.from, q.to))
        .map((p) => { const b = bmap.get(Number(p.booking_id)); return { ...p, customer_name: b.customer_name, booking_total: b.total_amount, current_balance: b.balance, booking_payment_status: b.payment_status }; })
        .sort((a, b) => a.payment_id - b.payment_id);
      return { title: "Payment Report", date_basis: "Payment date",
        columns: [["payment_id", "Payment ID"], ["booking_id", "Booking ID"], ["customer_name", "Customer"], ["booking_total", "Booking Total (₹)", "money"], ["advance_payment", "Received (₹)", "money"], ["remaining_balance", "Balance After (₹)", "money"], ["current_balance", "Current Outstanding (₹)", "money"], ["booking_payment_status", "Payment Status"], ["payment_date", "Payment Date"], ["payment_mode", "Mode"]],
        rows, summary: [["Receipts", rows.length], ["Amount received (₹)", sum(rows, "advance_payment"), "money"]] };
    }
    case "revenue": {
      const months = new Set();
      const active = bookings.filter((b) => b.booking_status !== "Cancelled" && inRange(b.booking_date, q.from, q.to));
      const pays = d.payments.filter((p) => bookings.some((b) => Number(b.booking_id) === Number(p.booking_id)) && inRange(p.payment_date, q.from, q.to));
      active.forEach((b) => months.add(String(b.booking_date).slice(0, 7)));
      pays.forEach((p) => months.add(String(p.payment_date).slice(0, 7)));
      const rows = [...months].sort().map((m) => {
        const bm = active.filter((b) => String(b.booking_date).startsWith(m));
        return { month: m, bookings: bm.length, booked_value: sum(bm, "total_amount"), collected: sum(pays.filter((p) => String(p.payment_date).startsWith(m)), "advance_payment") };
      });
      const outstanding = sum(bookings.filter((b) => b.booking_status !== "Cancelled"), "balance");
      return { title: "Revenue Report", date_basis: "Booking date (booked value) / payment date (collected)",
        columns: [["month", "Month"], ["bookings", "New Bookings"], ["booked_value", "Booked Value (₹)", "money"], ["collected", "Collected (₹)", "money"]],
        rows, summary: [["Booked value (₹)", sum(rows, "booked_value"), "money"], ["Collected revenue (₹)", sum(rows, "collected"), "money"], ["Current outstanding balance (₹)", outstanding, "money"]] };
    }
    case "customer": {
      const rows = d.customers.filter((c) => !q.customer_id || Number(c.customer_id) === Number(q.customer_id)).map((c) => {
        const cb = bookings.filter((b) => Number(b.customer_id) === Number(c.customer_id) && inRange(b.booking_date, q.from, q.to));
        const act = cb.filter((b) => b.booking_status !== "Cancelled");
        return { customer_id: c.customer_id, name: c.name, contact_no: c.contact_no, address: c.address, bookings: cb.length, booked_value: sum(act, "total_amount"), paid: sum(act, "amount_paid"), balance: sum(act, "balance") };
      }).filter((r) => (!q.status && !q.payment_status && !q.event_type && !q.menu_id && !q.from && !q.to) || r.bookings > 0);
      return { title: "Customer Report", date_basis: "Booking date",
        columns: [["customer_id", "ID"], ["name", "Customer"], ["contact_no", "Contact"], ["address", "Address"], ["bookings", "Bookings"], ["booked_value", "Booked (₹)", "money"], ["paid", "Paid (₹)", "money"], ["balance", "Balance (₹)", "money"]],
        rows, summary: [["Customers", rows.length], ["Booked value (₹)", sum(rows, "booked_value"), "money"], ["Outstanding (₹)", sum(rows, "balance"), "money"]] };
    }
    case "event": {
      const cust = d.byId("customers", "customer_id");
      const rows = d.events.filter((e) => inRange(e.event_date, q.from, q.to) && (!q.event_type || e.event_type === q.event_type) && (!q.customer_id || Number(e.customer_id) === Number(q.customer_id)))
        .map((e) => {
          const b = f.bookings.find((x) => Number(x.event_id) === Number(e.event_id) && x.booking_status !== "Cancelled") || f.bookings.find((x) => Number(x.event_id) === Number(e.event_id));
          return { event_id: e.event_id, event_type: e.event_type, event_date: e.event_date, event_time: e.event_time, venue: e.venue, customer_name: cust.get(Number(e.customer_id))?.name,
            guest_count: b?.guest_count ?? "", booking_status: b?.booking_status ?? "Not booked", payment_status: b?.payment_status ?? "", menu_id: b?.menu_id,
            staff: d.assignments.filter((a) => Number(a.event_id) === Number(e.event_id)).map((a) => staff.get(Number(a.staff_id))?.staff_name).join(", ") };
        })
        .filter((r) => (!q.status || r.booking_status === q.status) && (!q.payment_status || r.payment_status === q.payment_status) && (!q.menu_id || Number(r.menu_id) === Number(q.menu_id)))
        .sort((a, b) => (a.event_date + a.event_time).localeCompare(b.event_date + b.event_time));
      return { title: "Event Report", date_basis: "Event date",
        columns: [["event_id", "Event ID"], ["event_type", "Type"], ["event_date", "Date"], ["event_time", "Time"], ["venue", "Venue"], ["customer_name", "Customer"], ["guest_count", "Guests"], ["booking_status", "Booking Status"], ["staff", "Assigned Staff"]],
        rows, summary: [["Events", rows.length], ["Expected guests", rows.reduce((s, r) => s + (Number(r.guest_count) || 0), 0)]] };
    }
    default:
      throw notFound("Report type");
  }
}

/* ---------------- public (customer-facing) ---------------- */
export async function publicMenus(db) {
  return (await db.all("menus")).map(nMenu).filter((m) => m.availability).map(({ menu_id, menu_name, category, price, description }) => ({ menu_id, menu_name, category, price, description }));
}
export async function publicInfo(db) {
  const s = await getSettings(db);
  return { business_name: s.business_name, business_phone: s.business_phone, business_email: s.business_email, business_address: s.business_address, pricing_model: s.pricing_model, menus: await publicMenus(db) };
}
export async function submitInquiry(db, body) {
  if (str(body.website)) throw bad("Submission rejected"); // honeypot field
  const ev = body.event || {};
  if (str(ev.event_date) && isValidDate(str(ev.event_date)) && str(ev.event_date) < todayStr()) throw bad("Event date must be in the future", { event_date: "Must be a future date" });
  const b = await createBooking(db, {
    new_customer: body.customer || {}, new_event: ev, menu_id: body.menu_id, guest_count: body.guest_count,
    booking_date: todayStr(), booking_status: "Pending", notes: str(body.notes) ? `Customer inquiry: ${str(body.notes)}` : "Customer inquiry", request_key: body.request_key,
  }, { source: "inquiry" });
  return { reference: b.booking_id, status: b.booking_status, estimated_total: b.total_amount, message: "Your inquiry has been received. It is not yet a confirmed booking — our manager will contact you to confirm." };
}
/** Customers look up their own booking by booking ID + registered contact number only. */
export async function publicBookingStatus(db, body) {
  const id = Number(body.booking_id), contact = str(body.contact_no).replace(/\s+/g, "");
  if (!id || !contact) throw bad("Booking ID and contact number are required");
  const b0 = await db.get("bookings", id);
  const c = b0 && (await db.get("customers", Number(b0.customer_id)));
  if (!b0 || !c || c.contact_no.replace(/\s+/g, "") !== contact) throw notFound("Booking with these details");
  const b = await getBooking(db, id);
  return {
    booking_id: b.booking_id, customer_name: b.customer_name, event_type: b.event_type, event_date: b.event_date, event_time: b.event_time, venue: b.venue,
    menu: b.menu_name_snapshot, guest_count: b.guest_count, total_amount: b.total_amount, amount_paid: b.amount_paid, balance: b.balance,
    booking_status: b.booking_status, payment_status: b.payment_status, confirmed: ["Confirmed", "In Progress", "Completed"].includes(b.booking_status),
    payments: b.payments.map((p) => ({ payment_id: p.payment_id, payment_date: p.payment_date, amount: p.advance_payment, payment_mode: p.payment_mode, remaining_balance: p.remaining_balance })),
  };
}
