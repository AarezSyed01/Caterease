// Framework-free, tenant-bound adapter. Scope is derived from verified membership, never form data.
import { HttpError, PK } from './util.js';

export const LEGACY_BUSINESS = '00000000-0000-4000-8000-000000000001';
const tables = new Set(['users','customers','events','menus','bookings','guests','staff','staff_assignments','payments','feedback','settings','business_roles','businesses']);
export function tenantDb(db, businessId) {
  if (!businessId) throw new HttpError(403, 'No business is associated with this account');
  const table = (t) => { if (!tables.has(t)) throw new HttpError(403, 'Table is outside business scope'); return t === 'settings' ? 'business_settings' : t; };
  const scope = (where = {}) => ({ ...where, business_id: businessId });
  const scoped = {
    businessId,
    async all(t, where = {}) { return db.all(table(t), scope(where)); },
    async get(t, id) {
      const rows = await scoped.all(t, { [t === 'settings' ? 'setting_key' : PK[t]]: id });
      return rows[0] || null;
    },
    async insert(t, row) { return db.insert(table(t), scope(row)); },
    async update(t, id, row) {
      const existing = await scoped.get(t,id);
      if (!existing) throw new HttpError(404, 'Record not found');
      const { business_id: ignored, ...safe } = row;
      return db.update(table(t), t === 'settings' ? existing.setting_id : id, safe, { business_id: businessId });
    },
    async remove(t,id) {
      const existing = await scoped.get(t,id);
      if (!existing) throw new HttpError(404, 'Record not found');
      return db.remove(table(t),t === 'settings' ? existing.setting_id : id,{ business_id: businessId });
    },
    async tx(fn) { return db.tx((t) => fn(tenantDb(t,businessId))); },
    ...(db.createManager ? {createManager:(details,hash) => db.createManager(details,hash,businessId)} : {}),
  };
  return scoped;
}

export async function publicBusinessDb(db, query = {}, body = {}) {
  const id = query.business_id || body.business_id || LEGACY_BUSINESS;
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id))) throw new HttpError(400,'Invalid business link');
  if (!(await db.get('businesses',id))) throw new HttpError(404,'Business not found');
  return tenantDb(db,id);
}