// Shared helpers used by both the Express/MySQL backend and the preview backend.

export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export const bad = (msg, details) => new HttpError(400, msg, details);
export const notFound = (what) => new HttpError(404, `${what} not found`);
export const conflict = (msg) => new HttpError(409, msg);

// Money is handled in integer paise to avoid floating-point errors.
export const toPaise = (v) => Math.round(Number(v || 0) * 100);
export const fromPaise = (p) => Math.round(p) / 100;

export const PK = {
  businesses: "business_id",
  business_roles: "role_id",
  business_settings: "setting_id",
  users: "user_id",
  customers: "customer_id",
  events: "event_id",
  menus: "menu_id",
  bookings: "booking_id",
  guests: "guest_id",
  staff: "staff_id",
  staff_assignments: "assignment_id",
  payments: "payment_id",
  feedback: "feedback_id",
  settings: "setting_key",
};

export function todayStr() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
}

export const str = (v) => (v === undefined || v === null ? "" : String(v).trim());
export const bool = (v) => v === true || v === 1 || v === "1" || v === "true";
export const dateOnly = (v) => (v ? String(v).slice(0, 10) : v);
export const timeOnly = (v) => (v ? String(v).slice(0, 5) : v);

export function isValidDate(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s || "")) return false;
  const d = new Date(s + "T00:00:00Z");
  return !isNaN(d) && d.toISOString().slice(0, 10) === s;
}
export function isValidTime(s) {
  return /^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(s || "");
}
export function posInt(v, field) {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw bad(`${field} must be a positive whole number`, { [field]: "Must be a positive whole number" });
  return n;
}
export function idParam(v, field = "id") {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw bad(`Invalid ${field}`);
  return n;
}

/** Collect field errors and throw a single 400 if any. */
export function validate(rules) {
  const errors = {};
  for (const [field, msg] of rules) if (msg) errors[field] = msg;
  if (Object.keys(errors).length) throw bad("Please correct the highlighted fields", errors);
}

export function like(hay, needle) {
  return String(hay ?? "").toLowerCase().includes(String(needle).toLowerCase());
}

export function paymentStatus(totalP, paidP, bookingStatus) {
  if (bookingStatus === "Cancelled" && paidP === 0) return "Cancelled";
  if (paidP <= 0) return "Unpaid";
  if (paidP < totalP) return "Partially Paid";
  return "Paid";
}

export const BOOKING_STATUSES = ["Pending", "Confirmed", "In Progress", "Completed", "Cancelled"];
export const TRANSITIONS = {
  Pending: ["Confirmed", "Cancelled"],
  Confirmed: ["In Progress", "Cancelled", "Pending"],
  "In Progress": ["Completed", "Cancelled"],
  Completed: [],
  Cancelled: [],
};
export function canTransition(from, to) {
  return from === to || (TRANSITIONS[from] || []).includes(to);
}

export function calcTotal(unitPriceP, guests, model) {
  return model === "fixed" ? unitPriceP : unitPriceP * guests;
}
