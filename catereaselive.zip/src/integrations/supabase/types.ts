export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          booking_date: string
          booking_id: number
          booking_status: string
          business_id: string
          created_at: string
          customer_id: number
          event_id: number
          guest_count: number
          menu_id: number
          menu_name_snapshot: string
          notes: string | null
          pricing_model: string
          request_key: string | null
          source: string
          total_amount: number
          unit_price: number
          updated_at: string
        }
        Insert: {
          booking_date: string
          booking_id?: number
          booking_status?: string
          business_id?: string
          created_at?: string
          customer_id: number
          event_id: number
          guest_count: number
          menu_id: number
          menu_name_snapshot: string
          notes?: string | null
          pricing_model?: string
          request_key?: string | null
          source?: string
          total_amount: number
          unit_price: number
          updated_at?: string
        }
        Update: {
          booking_date?: string
          booking_id?: number
          booking_status?: string
          business_id?: string
          created_at?: string
          customer_id?: number
          event_id?: number
          guest_count?: number
          menu_id?: number
          menu_name_snapshot?: string
          notes?: string | null
          pricing_model?: string
          request_key?: string | null
          source?: string
          total_amount?: number
          unit_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "bookings_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
          {
            foreignKeyName: "bookings_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["event_id"]
          },
          {
            foreignKeyName: "bookings_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["menu_id"]
          },
          {
            foreignKeyName: "bookings_tenant_customer_fk"
            columns: ["business_id", "customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["business_id", "customer_id"]
          },
          {
            foreignKeyName: "bookings_tenant_event_fk"
            columns: ["business_id", "event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["business_id", "event_id"]
          },
          {
            foreignKeyName: "bookings_tenant_menu_fk"
            columns: ["business_id", "menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["business_id", "menu_id"]
          },
        ]
      }
      business_roles: {
        Row: {
          business_id: string
          created_at: string
          role: string
          role_id: number
          updated_at: string
          user_id: number
        }
        Insert: {
          business_id: string
          created_at?: string
          role: string
          role_id?: number
          updated_at?: string
          user_id: number
        }
        Update: {
          business_id?: string
          created_at?: string
          role?: string
          role_id?: number
          updated_at?: string
          user_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "business_roles_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "business_roles_business_id_user_id_fkey"
            columns: ["business_id", "user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["business_id", "user_id"]
          },
        ]
      }
      business_settings: {
        Row: {
          business_id: string
          setting_id: number
          setting_key: string
          setting_value: string
          updated_at: string
        }
        Insert: {
          business_id: string
          setting_id?: number
          setting_key: string
          setting_value: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          setting_id?: number
          setting_key?: string
          setting_value?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_settings_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
        ]
      }
      businesses: {
        Row: {
          address: string
          business_id: string
          business_name: string
          business_type: string | null
          city: string
          created_at: string
          email: string | null
          gst_number: string | null
          mobile: string
          owner_name: string
          state: string
          updated_at: string
        }
        Insert: {
          address?: string
          business_id?: string
          business_name: string
          business_type?: string | null
          city?: string
          created_at?: string
          email?: string | null
          gst_number?: string | null
          mobile?: string
          owner_name: string
          state?: string
          updated_at?: string
        }
        Update: {
          address?: string
          business_id?: string
          business_name?: string
          business_type?: string | null
          city?: string
          created_at?: string
          email?: string | null
          gst_number?: string | null
          mobile?: string
          owner_name?: string
          state?: string
          updated_at?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          address: string | null
          business_id: string
          contact_no: string
          created_at: string
          customer_id: number
          email: string | null
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          business_id?: string
          contact_no: string
          created_at?: string
          customer_id?: number
          email?: string | null
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          business_id?: string
          contact_no?: string
          created_at?: string
          customer_id?: number
          email?: string | null
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customers_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
        ]
      }
      events: {
        Row: {
          business_id: string
          created_at: string
          customer_id: number
          event_date: string
          event_id: number
          event_time: string
          event_type: string
          notes: string | null
          updated_at: string
          venue: string
        }
        Insert: {
          business_id?: string
          created_at?: string
          customer_id: number
          event_date: string
          event_id?: number
          event_time: string
          event_type: string
          notes?: string | null
          updated_at?: string
          venue: string
        }
        Update: {
          business_id?: string
          created_at?: string
          customer_id?: number
          event_date?: string
          event_id?: number
          event_time?: string
          event_type?: string
          notes?: string | null
          updated_at?: string
          venue?: string
        }
        Relationships: [
          {
            foreignKeyName: "events_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "events_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
          {
            foreignKeyName: "events_tenant_customer_fk"
            columns: ["business_id", "customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["business_id", "customer_id"]
          },
        ]
      }
      feedback: {
        Row: {
          booking_id: number
          business_id: string
          comments: string | null
          created_at: string
          customer_id: number
          feedback_id: number
          rating: number
          updated_at: string
        }
        Insert: {
          booking_id: number
          business_id?: string
          comments?: string | null
          created_at?: string
          customer_id: number
          feedback_id?: number
          rating: number
          updated_at?: string
        }
        Update: {
          booking_id?: number
          business_id?: string
          comments?: string | null
          created_at?: string
          customer_id?: number
          feedback_id?: number
          rating?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "feedback_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["booking_id"]
          },
          {
            foreignKeyName: "feedback_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "feedback_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
          {
            foreignKeyName: "feedback_tenant_booking_fk"
            columns: ["business_id", "booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["business_id", "booking_id"]
          },
          {
            foreignKeyName: "feedback_tenant_customer_fk"
            columns: ["business_id", "customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["business_id", "customer_id"]
          },
        ]
      }
      guests: {
        Row: {
          booking_id: number
          business_id: string
          created_at: string
          guest_count: number
          guest_id: number
          remarks: string | null
          updated_at: string
        }
        Insert: {
          booking_id: number
          business_id?: string
          created_at?: string
          guest_count: number
          guest_id?: number
          remarks?: string | null
          updated_at?: string
        }
        Update: {
          booking_id?: number
          business_id?: string
          created_at?: string
          guest_count?: number
          guest_id?: number
          remarks?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "guests_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["booking_id"]
          },
          {
            foreignKeyName: "guests_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "guests_tenant_booking_fk"
            columns: ["business_id", "booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["business_id", "booking_id"]
          },
        ]
      }
      menus: {
        Row: {
          availability: boolean
          business_id: string
          category: string
          created_at: string
          description: string | null
          menu_id: number
          menu_name: string
          price: number
          updated_at: string
        }
        Insert: {
          availability?: boolean
          business_id?: string
          category: string
          created_at?: string
          description?: string | null
          menu_id?: number
          menu_name: string
          price: number
          updated_at?: string
        }
        Update: {
          availability?: boolean
          business_id?: string
          category?: string
          created_at?: string
          description?: string | null
          menu_id?: number
          menu_name?: string
          price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "menus_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
        ]
      }
      payments: {
        Row: {
          advance_payment: number
          booking_id: number
          business_id: string
          created_at: string
          payment_date: string
          payment_id: number
          payment_mode: string
          payment_status: string
          reference_note: string | null
          remaining_balance: number
          total_amount: number
          updated_at: string
        }
        Insert: {
          advance_payment: number
          booking_id: number
          business_id?: string
          created_at?: string
          payment_date: string
          payment_id?: number
          payment_mode?: string
          payment_status: string
          reference_note?: string | null
          remaining_balance: number
          total_amount: number
          updated_at?: string
        }
        Update: {
          advance_payment?: number
          booking_id?: number
          business_id?: string
          created_at?: string
          payment_date?: string
          payment_id?: number
          payment_mode?: string
          payment_status?: string
          reference_note?: string | null
          remaining_balance?: number
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["booking_id"]
          },
          {
            foreignKeyName: "payments_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "payments_tenant_booking_fk"
            columns: ["business_id", "booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["business_id", "booking_id"]
          },
        ]
      }
      settings: {
        Row: {
          setting_key: string
          setting_value: string
          updated_at: string
        }
        Insert: {
          setting_key: string
          setting_value: string
          updated_at?: string
        }
        Update: {
          setting_key?: string
          setting_value?: string
          updated_at?: string
        }
        Relationships: []
      }
      staff: {
        Row: {
          business_id: string
          contact_no: string | null
          created_at: string
          is_active: boolean
          role: string
          staff_id: number
          staff_name: string
          updated_at: string
        }
        Insert: {
          business_id?: string
          contact_no?: string | null
          created_at?: string
          is_active?: boolean
          role: string
          staff_id?: number
          staff_name: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          contact_no?: string | null
          created_at?: string
          is_active?: boolean
          role?: string
          staff_id?: number
          staff_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
        ]
      }
      staff_assignments: {
        Row: {
          assignment_id: number
          business_id: string
          created_at: string
          event_id: number
          staff_id: number
          updated_at: string
          work_assigned: string
        }
        Insert: {
          assignment_id?: number
          business_id?: string
          created_at?: string
          event_id: number
          staff_id: number
          updated_at?: string
          work_assigned: string
        }
        Update: {
          assignment_id?: number
          business_id?: string
          created_at?: string
          event_id?: number
          staff_id?: number
          updated_at?: string
          work_assigned?: string
        }
        Relationships: [
          {
            foreignKeyName: "assignments_tenant_event_fk"
            columns: ["business_id", "event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["business_id", "event_id"]
          },
          {
            foreignKeyName: "assignments_tenant_staff_fk"
            columns: ["business_id", "staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["business_id", "staff_id"]
          },
          {
            foreignKeyName: "staff_assignments_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
          {
            foreignKeyName: "staff_assignments_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["event_id"]
          },
          {
            foreignKeyName: "staff_assignments_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["staff_id"]
          },
        ]
      }
      users: {
        Row: {
          business_id: string
          created_at: string
          email: string | null
          full_name: string
          password_hash: string
          role: string
          updated_at: string
          user_id: number
          username: string
        }
        Insert: {
          business_id?: string
          created_at?: string
          email?: string | null
          full_name: string
          password_hash: string
          role?: string
          updated_at?: string
          user_id?: number
          username: string
        }
        Update: {
          business_id?: string
          created_at?: string
          email?: string | null
          full_name?: string
          password_hash?: string
          role?: string
          updated_at?: string
          user_id?: number
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "users_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["business_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_catering_manager: {
        Args: { details: Json; hashed_password: string; tenant: string }
        Returns: Json
      }
      register_catering_business: {
        Args: { details: Json; hashed_password: string }
        Returns: Json
      }
      setup_catering_admin: {
        Args: { details: Json; hashed_password: string }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
