// Preview database adapter: implements the same small interface as backend/src/config/mysqlAdapter.js
// on top of Lovable Cloud. Only used on the server.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
// @ts-ignore plain JS shared module
import { PK } from "@/core/util.js";

type Row = Record<string, any>;
const sb = supabaseAdmin as any;
const pk = (t: string) => {
  const value = (PK as Record<string, string>)[t];
  if (!value) throw new Error('Unknown table');
  return value;
};

function fail(error: any): never {
  const e: any = new Error(error.message);
  e.code = error.code;
  throw e;
}

export const cloudDb = {
  async all(table: string, where: Row = {}) {
    const out: Row[] = [];
    for (let from = 0; ; from += 1000) {
      let q = sb.from(table).select("*").order(pk(table), { ascending: true }).range(from, from + 999);
      for (const [k, v] of Object.entries(where)) q = q.eq(k, v);
      const { data, error } = await q;
      if (error) fail(error);
      out.push(...data);
      if (data.length < 1000) return out;
    }
  },
  async get(table: string, id: any) {
    const { data, error } = await sb.from(table).select("*").eq(pk(table), id).maybeSingle();
    if (error) fail(error);
    return data;
  },
  async insert(table: string, row: Row) {
    const { data, error } = await sb.from(table).insert(row).select("*").single();
    if (error) fail(error);
    return data;
  },
  async update(table: string, id: any, row: Row, where: Row = {}) {
    let q = sb.from(table).update({ ...row, updated_at: new Date().toISOString() }).eq(pk(table), id);
    for (const [k,v] of Object.entries(where)) q = q.eq(k,v);
    const { data, error } = await q.select("*").single();
    if (error) fail(error);
    return data;
  },
  async remove(table: string, id: any, where: Row = {}) {
    let q = sb.from(table).delete().eq(pk(table), id);
    for (const [k,v] of Object.entries(where)) q = q.eq(k,v);
    const { error } = await q;
    if (error) fail(error);
  },
  // The preview runs each step sequentially; the MySQL version wraps this in a real transaction.
  async tx<T>(fn: (t: any) => Promise<T>) {
    return fn(cloudDb);
  },
  // Account, business, role and settings are committed atomically by PostgreSQL.
  async registerBusiness(details: Row, hashedPassword: string) {
    const {data,error} = await sb.rpc('register_catering_business',{details,hashed_password:hashedPassword});
    if (error) fail(error);
    return data;
  },
  async setupAdmin(details: Row, hashedPassword: string) {
    const {data,error} = await sb.rpc('setup_catering_admin',{details,hashed_password:hashedPassword});
    if (error) fail(error);
    return data;
  },
  async createManager(details: Row, hashedPassword: string, tenant: string) {
    const {data,error} = await sb.rpc('create_catering_manager',{details,hashed_password:hashedPassword,tenant});
    if (error) fail(error);
    return data;
  },
};
