import { createFileRoute } from "@tanstack/react-router";

// Preview REST API. Mirrors the Express API in the downloadable project.
// Protected endpoints verify the signed bearer token inside the shared dispatcher.
async function handle({ request, params }: { request: Request; params: { _splat?: string } }) {
  // @ts-ignore plain JS shared module
  const { dispatch } = await import("@/core/routes.js");
  const { cloudDb } = await import("@/lib/cloud-db.server");
  const url = new URL(request.url);
  let body: unknown = {};
  if (!["GET", "HEAD"].includes(request.method)) {
    try { body = await request.json(); } catch { body = {}; }
  }
  const res = await dispatch({
    db: cloudDb,
    env: { JWT_SECRET: process.env["JWT_SECRET"], ADMIN_SETUP_KEY: process.env["ADMIN_SETUP_KEY"] },
    method: request.method,
    path: "/" + (params._splat || ""),
    query: Object.fromEntries(url.searchParams),
    body,
    authorization: request.headers.get("authorization"),
  });
  return Response.json(res.body, { status: res.status, headers: { "cache-control": "no-store" } });
}

export const Route = createFileRoute("/api/public/$")({
  server: {
    handlers: { GET: handle, POST: handle, PUT: handle, PATCH: handle, DELETE: handle },
  },
});
