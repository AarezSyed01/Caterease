import { createFileRoute, redirect } from "@tanstack/react-router";

// The manager application is a vanilla HTML/Bootstrap app served from /app/.
export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ href: "/app/index.html" });
  },
  head: () => ({
    meta: [
      { title: "CaterEase" },
      { name: "description", content: "Manage catering customers, events, menus, bookings, staff, payments and reports." },
      { property: "og:title", content: "CaterEase" },
      { property: "og:description", content: "Manage catering customers, events, menus, bookings, staff, payments and reports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => null,
});
