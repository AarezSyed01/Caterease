// @vitest-environment node
// @ts-nocheck
import { describe,it,expect } from 'vitest';
import bcrypt from 'bcryptjs';
import { memoryDb } from '@/core/memoryDb.js';
import { tenantDb,LEGACY_BUSINESS } from '@/core/tenant.js';
import { dispatch } from '@/core/routes.js';
import * as A from '@/core/auth.js';
import * as S from '@/core/services.js';
import { PK } from '@/core/util.js';

const env = {JWT_SECRET:'test-only-secret-32-characters-long'};
const details = (email='owner@example.test') => ({full_name:'Test Owner',email,password:'SecurePass123',confirm_password:'SecurePass123'});
const bizDetails = (over={}) => ({business_name:'Test Catering',mobile:'9876543210',address:'Market Road',city:'Latur',state:'Maharashtra',business_type:'',gst_number:'',...over});
const request = (db,auth,method,path,body={}) => dispatch({db,env,authorization:auth ? 'Bearer '+auth.token : null,method,path,body});

describe('independent catering business registration',() => {
  it('registers an owner with account only, then completes business details before the dashboard',async () => {
    const db=memoryDb(); const account=await A.registerBusiness(db,details(),env);
    expect(account.user.role).toBe('admin');
    expect(account.user.details_complete).toBe(false);
    expect(await bcrypt.compare('SecurePass123',db.tables.users[0].password_hash)).toBe(true);
    expect(db.tables.users[0].password_hash).not.toBe('SecurePass123');
    expect(db.tables.business_roles[0].role).toBe('owner');
    const saved=await request(db,account,'PUT','/business/details',bizDetails());
    expect(saved.status).toBe(200);
    expect(db.tables.businesses[0]).toMatchObject({city:'Latur',state:'Maharashtra',business_name:'Test Catering'});
    const login=await A.login(db,{email:'OWNER@EXAMPLE.TEST',password:'SecurePass123'},env);
    expect(login.user.business_id).toBe(account.user.business_id);
    expect(login.user.details_complete).toBe(true);
  });
  it('duplicate email registration is rejected without another business',async () => {
    const db=memoryDb(); await A.registerBusiness(db,details(),env);
    await expect(A.registerBusiness(db,details('OWNER@EXAMPLE.TEST'),env)).rejects.toThrow(/already registered/);
    expect(db.tables.businesses).toHaveLength(1);
  });
  it.each([['email','invalid'],['password','weak'],['confirm_password','different'],['full_name','']])('rejects invalid or missing %s before saving anything',async (field,value) => {
    const db=memoryDb(); await expect(A.registerBusiness(db,{...details(),[field]:value},env)).rejects.toThrow();
    expect(db.tables.businesses).toHaveLength(0); expect(db.tables.users).toHaveLength(0);
  });
  it.each([['business_name',''],['city',''],['state',''],['address',''],['mobile','123']])('rejects invalid or missing business detail %s',async (field,value) => {
    const db=memoryDb(); const account=await A.registerBusiness(db,details(),env);
    const res=await request(db,account,'PUT','/business/details',bizDetails({[field]:value}));
    expect(res.status).toBe(400);
    expect(db.tables.businesses[0].business_name).not.toBe('Test Catering');
  });
  it('business details of one business cannot be changed through another business session',async () => {
    const db=memoryDb(); const a=await A.registerBusiness(db,details('a@example.test'),env),b=await A.registerBusiness(db,details('b@example.test'),env);
    await request(db,a,'PUT','/business/details',bizDetails());
    await request(db,b,'PUT','/business/details',bizDetails({business_name:'Business B'}));
    expect(db.tables.businesses.find(x=>x.business_id===a.user.business_id).business_name).toBe('Test Catering');
    expect(db.tables.businesses.find(x=>x.business_id===b.user.business_id).business_name).toBe('Business B');
  });
  it('public registration ignores submitted platform role and business identity',async () => {
    const db=memoryDb(); const u=await A.registerBusiness(db,{...details(),role:'platform_admin',business_id:LEGACY_BUSINESS},env);
    expect(u.user.business_id).not.toBe(LEGACY_BUSINESS); expect(db.tables.business_roles[0].role).toBe('owner');
  });
  it('legacy administrator retains username login and original business records',async () => {
    const db=memoryDb({users:[{user_id:2,username:'admin',password_hash:await bcrypt.hash('LegacyPass123',10),full_name:'Original Admin',role:'manager',business_id:LEGACY_BUSINESS}],business_roles:[{user_id:2,business_id:LEGACY_BUSINESS,role:'admin'}],customers:[{customer_id:1,name:'Original customer',business_id:LEGACY_BUSINESS}]});
    const a=await A.login(db,{username:'admin',password:'LegacyPass123'},env);
    expect(a.user.role).toBe('admin'); expect((await request(db,a,'GET','/customers')).body.data[0].name).toBe('Original customer');
  });
});

describe('tenant security boundaries',() => {
  it.each(['customers','events','menus','bookings','guests','staff','staff_assignments','payments','feedback','users','settings','business_roles'])('isolates read/create/update/delete for %s',async table => {
    const db=memoryDb(); const stored=table==='settings'?'business_settings':table;
    const id=PK[stored]; const row=await db.insert(stored,{[id]:1,...(table==='settings'?{setting_key:'business_name'}:{}),business_id:'B',name:'Private B'});
    const a=tenantDb(db,'A'),b=tenantDb(db,'B'); const key=table==='settings'?'business_name':row[id];
    expect(await a.all(table,{business_id:'B'})).toEqual([]); expect(await a.get(table,key)).toBeNull();
    await expect(a.update(table,key,{name:'Stolen'})).rejects.toThrow(); await expect(a.remove(table,key)).rejects.toThrow();
    expect((await b.get(table,key)).name).toBe('Private B');
    const created=await a.insert(table,{business_id:'B',name:'Own A',...(table==='settings'?{setting_key:'other'}:{})});
    expect(created.business_id).toBe('A');
  });
  it('two businesses have separate dashboards, reports, settings and manager accounts',async () => {
    const db=memoryDb(); const a=await A.registerBusiness(db,details('a@example.test'),env),b=await A.registerBusiness(db,details('b@example.test'),env);
    await request(db,b,'PUT','/business/details',bizDetails({business_name:'Business B'}));
    await request(db,a,'POST','/customers',{name:'A customer',contact_no:'9876543210'});
    await request(db,b,'POST','/customers',{name:'B customer',contact_no:'9876543210'});
    const menu=await request(db,a,'POST','/menus',{menu_name:'A meal',category:'Vegetarian',price:400,availability:true});
    expect((await request(db,b,'GET','/menus')).body.data).toHaveLength(0);
    expect((await request(db,b,'PUT','/menus/'+menu.body.data.menu_id,{menu_name:'Attack',category:'Vegetarian',price:1,availability:true})).status).toBe(404);
    expect((await request(db,b,'GET','/settings')).body.data.business_name).toBe('Business B');
    expect((await request(db,b,'GET','/users')).body.data).toHaveLength(1);
    expect((await request(db,b,'GET','/dashboard')).body.data.cards.total_customers).toBe(1);
    const report=await S.report(tenantDb(db,b.user.business_id),'customer',{});
    expect(JSON.stringify(report)).toContain('B customer'); expect(JSON.stringify(report)).not.toContain('A customer');
  });
  it('verified role membership overrides forged stored account role and managers cannot create accounts',async () => {
    const db=memoryDb(); const a=await A.registerBusiness(db,details(),env);
    const created=await request(db,a,'POST','/users',{username:'staff',full_name:'Staff',email:'staff@example.test',password:'StaffPass123',role:'admin'});
    expect(created.body.data.role).toBe('manager');
    const staff=await A.login(db,{email:'staff@example.test',password:'StaffPass123'},env);
    await db.update('users',staff.user.user_id,{role:'admin'});
    expect((await request(db,staff,'PUT','/settings',{business_name:'Attack'})).status).toBe(403);
    expect((await request(db,staff,'POST','/users',{username:'attacker',full_name:'Attacker',password:'Attack123'})).status).toBe(403);
  });
  it('unauthenticated clients cannot read protected modules',async () => {
    const db=memoryDb();
    for (const path of ['/customers','/events','/menus','/bookings','/guests','/staff','/assignments','/payments','/feedback','/reports/customers','/dashboard','/settings','/users']) expect((await request(db,null,'GET',path)).status).toBe(401);
  });
  it('public business menus and booking status never return another business records',async () => {
    const db=memoryDb(); const a=await A.registerBusiness(db,details('a@example.test'),env),b=await A.registerBusiness(db,details('b@example.test'),env);
    const ad=tenantDb(db,a.user.business_id),bd=tenantDb(db,b.user.business_id);
    const customer=await ad.insert('customers',{name:'Private A',contact_no:'9876543210'});
    await ad.insert('bookings',{customer_id:customer.customer_id});
    await ad.insert('menus',{menu_name:'Private A menu',availability:true,price:400});
    await bd.insert('menus',{menu_name:'Public B menu',availability:true,price:300});
    const info=await dispatch({db,env,method:'GET',path:'/public/info',query:{business_id:b.user.business_id}});
    expect(info.body.data.menus.map(m=>m.menu_name)).toEqual(['Public B menu']);
    const status=await dispatch({db,env,method:'POST',path:'/public/booking-status',query:{business_id:b.user.business_id},body:{booking_id:1,contact_no:'9876543210'}});
    expect(status.status).toBe(404);
  });
});