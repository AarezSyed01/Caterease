// @ts-nocheck
import { describe, it, expect } from "vitest";
import { memoryDb } from "@/core/memoryDb.js";
import * as S from "@/core/services.js";

const seed = () => memoryDb({
  settings: [{ setting_key: "pricing_model", setting_value: "per_person" }],
  customers: [{ customer_id: 1, name: "Test Customer", contact_no: "9876543210", is_active: true }],
  menus: [{ menu_id: 1, menu_name: "Veg Thali", category: "Vegetarian", price: 450, availability: true }, { menu_id: 2, menu_name: "Old Menu", category: "Other", price: 100, availability: false }],
  events: [{ event_id: 1, customer_id: 1, event_type: "Wedding", event_date: "2030-01-10", event_time: "19:00", venue: "Hall A" }],
});
const book = (db, extra = {}) => S.createBooking(db, { customer_id: 1, event_id: 1, menu_id: 1, guest_count: 100, booking_date: "2026-10-01", ...extra });

describe("catering business rules", () => {
  it("per-person total is menu price times guests", async () => {
    expect((await book(seed())).total_amount).toBe(45000);
  });
  it("unavailable menus cannot be booked", async () => {
    await expect(book(seed(), { menu_id: 2 })).rejects.toThrow(/unavailable/);
  });
  it("guest count must be a positive whole number", async () => {
    await expect(book(seed(), { guest_count: 0 })).rejects.toThrow();
    await expect(book(seed(), { guest_count: 2.5 })).rejects.toThrow();
  });
  it("menu price changes do not alter existing booking totals", async () => {
    const db = seed(); const b = await book(db);
    await S.updateMenu(db, 1, { menu_name: "Veg Thali", category: "Vegetarian", price: "999", availability: true });
    expect((await S.getBooking(db, b.booking_id)).total_amount).toBe(45000);
  });
  it("same request key does not create a duplicate booking", async () => {
    const db = seed(); await book(db, { request_key: "k1" }); const again = await book(db, { request_key: "k1" });
    expect(again.duplicate).toBe(true); expect(db.tables.bookings.length).toBe(1);
  });
  it("payments update balance and status; overpayment is rejected", async () => {
    const db = seed(); const b = await book(db);
    const p1 = await S.recordPayment(db, { booking_id: b.booking_id, amount: "20000", payment_date: "2026-10-02" });
    expect(p1.remaining_balance).toBe(25000); expect(p1.booking.payment_status).toBe("Partially Paid");
    await expect(S.recordPayment(db, { booking_id: b.booking_id, amount: "25000.01", payment_date: "2026-10-02" })).rejects.toThrow(/exceeds/);
    const p2 = await S.recordPayment(db, { booking_id: b.booking_id, amount: "25000", payment_date: "2026-10-03" });
    expect(p2.booking.payment_status).toBe("Paid"); expect(p2.booking.balance).toBe(0);
  });
  it("invalid status transitions are blocked", async () => {
    const db = seed(); const b = await book(db);
    await expect(S.setBookingStatus(db, b.booking_id, { booking_status: "Completed" })).rejects.toThrow(/Cannot change/);
  });
  it("guest count update keeps booking and guest record in sync", async () => {
    const db = seed(); const b = await book(db);
    const r = await S.updateGuests(db, b.booking_id, { guest_count: 120 });
    expect(r.total_amount).toBe(54000); expect(db.tables.guests[0].guest_count).toBe(120);
  });
  it("ratings must be between 1 and 5", async () => {
    const db = seed(); const b = await book(db);
    await expect(S.createFeedback(db, { booking_id: b.booking_id, rating: 6 })).rejects.toThrow();
  });
  it("dashboard collected never counts booking value as revenue", async () => {
    const db = seed(); const b = await book(db);
    await S.recordPayment(db, { booking_id: b.booking_id, amount: "1000", payment_date: "2026-10-02" });
    const d = await S.dashboard(db);
    expect(d.cards.total_booking_value).toBe(45000); expect(d.cards.amount_collected).toBe(1000); expect(d.cards.outstanding_balance).toBe(44000);
  });
});
